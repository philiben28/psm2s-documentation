# DOCUMENTATION TECHNIQUE – PSM2S V2

> Dernière mise à jour : 06/06/2026

---

## 1. Informations générales

| Élément | Valeur |
|---|---|
| Application | PSM2S Sécurité V2 |
| Framework | Django 6.0.5 / Python 3.13 |
| URL production | https://psm2s.pbci-conseils.fr |
| Hébergeur | O2Switch |
| Répertoire prod | /home/roda4402/psm2s_v2 |
| Répertoire dev | C:\Users\Philippe\PSM2S_V2_DEV |
| Dépôt GitHub | https://github.com/philiben28/psm2s-securite (branche main) |
| Base de données | SQLite (local) — SQLite (prod) |

---

## 2. Architecture du projet

```
PSM2S_V2_DEV/
├── config/
│   ├── settings.py       ← configuration principale
│   ├── urls.py           ← routage racine
│   ├── wsgi.py
│   └── asgi.py
├── registre/             ← application principale
│   ├── models.py         ← tous les modèles
│   ├── views.py          ← toutes les vues
│   ├── urls.py           ← routage registre
│   ├── forms.py          ← formulaires Django
│   ├── admin.py          ← interface /admin/
│   ├── permissions.py    ← décorateurs d'accès
│   ├── migrations/       ← migrations 0001 à 0014
│   └── management/
│       └── commands/
│           ├── envoyer_alertes.py      ← alertes email échéances
│           └── charger_duerp_master.py ← charge 44 catégories DUERP
├── Templates/            ← templates HTML (hors app Django standard)
│   ├── base.html
│   ├── accueil.html
│   ├── registration/
│   └── registre/         ← tous les templates métier
├── media/                ← fichiers uploadés (non versionnés)
│   ├── signatures/       ← signatures utilisateurs scannées
│   ├── signatures/duerp/ ← copies signatures sur DUERP
│   └── signatures/accessibilite/
├── staticfiles/          ← fichiers statiques générés (non versionnés)
├── passenger_wsgi.py     ← point d'entrée O2Switch
├── manage.py
└── requirements.txt
```

---

## 3. Workflow de développement et déploiement

### Ancien workflow (ABANDONNÉ)
~~FileZilla → FTP vers O2Switch~~ — ne plus utiliser.

### Nouveau workflow (GIT)

```
PC local  →  git push  →  GitHub  →  git pull  →  O2Switch
```

**Script de push local** : `git_push.ps1` dans PSM2S_V2_DEV  
Lance `git push origin main` en demandant le token GitHub (ghp_...).

**Commandes O2Switch complètes :**
```bash
source /home/roda4402/virtualenv/psm2s_v2/3.9/bin/activate
cd /home/roda4402/psm2s_v2
git pull origin main
python manage.py migrate          # seulement si nouvelles migrations
# python manage.py collectstatic  # si fichiers statiques modifiés
```

**Redémarrage** : O2Switch → Setup Python App → Restart  
(nécessaire si settings.py ou passenger_wsgi.py modifiés)

---

## 4. Configuration

### settings.py — points importants

```python
DEBUG = False   # prod — True en local pour servir les media
ALLOWED_HOSTS = ['psm2s.pbci-conseils.fr', 'www.psm2s.pbci-conseils.fr']
# En local : ajouter '127.0.0.1', 'localhost'

SECRET_KEY = os.environ.get('DJANGO_SECRET_KEY', '...')  # via passenger_wsgi.py

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

TEMPLATES = [{'DIRS': [BASE_DIR / 'Templates'], ...}]
```

### Sécurité en place
- `SECRET_KEY` externalisée via variable d'environnement dans `passenger_wsgi.py`
- `ALLOWED_HOSTS` restreint
- `SECURE_CONTENT_TYPE_NOSNIFF = True`
- `X_FRAME_OPTIONS = 'DENY'`
- `SECURE_REFERRER_POLICY = "same-origin"`

---

## 5. Migrations

| N° | Nom | Contenu |
|---|---|---|
| 0001 | initial | Modèles de base |
| 0002 | contact_email | Champs contact établissement |
| 0003 | realisation_controle | Réalisations de contrôle |
| 0004 | piecejointe_ticket | Pièces jointes tickets |
| 0005 | periodicite | Périodicités personnalisables |
| 0006 | typecontrole_periodicite_fk | Lien TypeControle ↔ Périodicité |
| 0007 | contrat | Contrats prestataires |
| 0008 | commission | Commissions de sécurité |
| 0009 | carnet_eau | Carnet sanitaire eau |
| 0010 | duerp | DUERP, UnitesTravail, Checklist, ActionDUERP |
| 0011 | accessibilite | RegistreAccessibilite, grille 10×4, actions, formations |
| 0012 | signature | Champ signature (ImageField) sur Utilisateur |
| 0013 | signatures_documents | Champs signature sur DUERP et RegistreAccessibilite |
| 0014 | droitsignature | Modèle DroitSignature |

### ⚠️ IMPORTANT — Bug RenameIndex
Chaque nouvelle migration générée par Django contient des opérations `RenameIndex` parasites qui font planter `migrate` sur SQLite. **Toujours les supprimer manuellement** avant de lancer `migrate`.

Repérer et supprimer les lignes du type :
```python
migrations.RenameIndex(
    model_name='...',
    new_name='...',
    old_name='...',
),
```

---

## 6. Modèles principaux

### Utilisateur (AbstractUser)
- `role` : admin, responsable_securite, directeur, factotum, prestataire
- `signature` : ImageField (scan de signature, upload_to='signatures/')

### Etablissement
- `code`, `nom`, `adresse`, `ville`, `categorie` (ERP), `type_erp`, `actif`

### EtablissementUtilisateur
- Rattachement M2M entre Utilisateur et Etablissement
- `principal` : BooleanField (établissement principal de l'utilisateur)
- Géré via Administration → Utilisateurs → Modifier

### DroitSignature
- `utilisateur` × `etablissement` (null = tous) × `document`
- Documents : duerp, accessibilite, intervention, contrat
- Méthode clé : `DroitSignature.peut_signer(user, etab, document)` → bool
- Géré via Administration → Droits de signature

### DUERP
- Un par établissement par année
- 7 unités de travail, 44 catégories, 142 sources de danger (chargées via `charger_duerp_master`)
- `signature_directeur`, `nom_directeur`, `date_signature_directeur`
- `signature_responsable`, `nom_responsable`, `date_signature_responsable`

### RegistreAccessibilite (OneToOne avec Etablissement)
- Grille 10 zones × 4 handicaps (moteur, visuel, auditif, mental)
- Actions, formations, pièces administratives
- Mêmes champs signature que DUERP

---

## 7. Modules fonctionnels

| Module | URL | Description |
|---|---|---|
| Dashboard | / | Vue globale par établissement |
| Établissements | /etablissement/nouveau/ | Gestion des sites |
| Contrôles réglementaires | /controles/ | Suivi des obligations |
| Tickets travaux | /tickets/ | Kanban des actions |
| Interventions | /interventions/ | Bons d'intervention |
| Contrats prestataires | /etablissement/.../contrat/ | Suivi contrats |
| Commissions de sécurité | /etablissement/.../commission/ | Visites et prescriptions |
| Carnet sanitaire eau | /etablissement/.../eau/ | Analyses et réseaux |
| DUERP | /duerp/ | Document unique annuel |
| Registre Accessibilité | /etablissement/.../accessibilite/ | Grille PMR |
| Mon profil | /mon-profil/ | Upload signature scannée |
| Administration | /administration/ | Utilisateurs, groupes, droits |
| Droits de signature | /administration/droits-signature/ | Habilitations par document |

---

## 8. Système de signatures

1. L'utilisateur uploade sa signature scannée via **Mon profil** (stockée dans `media/signatures/`)
2. Les droits de signature sont configurés dans **Administration → Droits de signature** (`DroitSignature`)
3. Sur un DUERP ou Registre d'Accessibilité, le bouton "Signer" n'apparaît que si `DroitSignature.peut_signer()` renvoie True
4. La signature est **copiée et stockée définitivement** sur le document (champ `signature_directeur` ou `signature_responsable`)
5. La signature reste visible à l'impression même si l'utilisateur change ou supprime sa signature de profil

---

## 9. Alertes email

Commande : `python manage.py envoyer_alertes`  
Envoie des emails aux responsables pour les contrôles dont l'échéance approche.  
À planifier via cron O2Switch ou manuellement via /alertes/lancer/.

---

## 10. Procédures de maintenance

### Ajouter un utilisateur
Administration → Utilisateurs → Nouvel utilisateur  
Puis cocher ses établissements et définir l'établissement principal.

### Configurer les droits de signature
Administration → Droits de signature → Ajouter  
Sélectionner l'utilisateur, cocher les établissements (ou "Tous"), cocher les documents.

### Charger le référentiel DUERP
```bash
python manage.py charger_duerp_master
```
Charge 44 catégories et 142 sources de danger. Idempotent (safe à relancer).

### Retour arrière
1. Sur O2Switch : `git log --oneline` pour identifier le commit cible
2. `git checkout <commit_hash>` ou `git revert`
3. `python manage.py migrate` si nécessaire
4. Restart application O2Switch

---

## 11. Roadmap

| Statut | Module |
|---|---|
| ✅ | DUERP complet |
| ✅ | Registre d'Accessibilité |
| ✅ | Signature électronique (scan) |
| ✅ | Droits de signature granulaires |
| ✅ | Rattachement utilisateurs / établissements |
| 🔲 | Signature sur interventions (factotum) |
| 🔲 | Veille réglementaire (à spécifier avec Guillaume) |
| 🔲 | Application mobile / PWA |
| 🔲 | Sauvegardes automatiques |
| 🔲 | Préproduction |
| 🔲 | Commercialisation |

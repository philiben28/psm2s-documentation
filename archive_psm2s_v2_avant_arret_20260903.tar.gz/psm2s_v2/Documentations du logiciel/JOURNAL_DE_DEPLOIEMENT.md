# JOURNAL DE DÉPLOIEMENT – PSM2S V2

## Projet
PSM2S Sécurité V2

## Serveur
/home/roda4402/psm2s_v2

## URL
https://psm2s.pbci-conseils.fr

---

## 05/06/2026 – Sécurisation initiale

### Objectif
Sécurisation des paramètres Django et mise en place du workflow Git.

### Modifications
- SECURE_CONTENT_TYPE_NOSNIFF, X_FRAME_OPTIONS, SECURE_REFERRER_POLICY
- SECRET_KEY externalisée via passenger_wsgi.py
- ALLOWED_HOSTS restreint
- Remplacement FileZilla par Git (GitHub → O2Switch)
- Script git_push.ps1 créé pour le push local

### Commits notables
- 62f833b Ajout SECURE_CONTENT_TYPE_NOSNIFF
- ca45f0a Ajout X_FRAME_OPTIONS DENY
- d83a1ad Ajout SECURE_REFERRER_POLICY
- 0b472fa SECRET_KEY via variable environnement
- 41f5b20 Restriction ALLOWED_HOSTS V2

### Résultat
✅ Application opérationnelle. Workflow Git validé.

---

## 06/06/2026 – DUERP, Accessibilité, Signatures, Droits

### Objectif
Développement de 4 nouveaux modules majeurs.

### Migrations appliquées
- 0010_duerp : Document Unique d'Évaluation des Risques Professionnels
- 0011_accessibilite : Registre Public d'Accessibilité
- 0012_signature : Champ signature (ImageField) sur Utilisateur
- 0013_signatures_documents : Signatures permanentes sur DUERP et Accessibilité
- 0014_droitsignature : Habilitations de signature par utilisateur/établissement/document

### Fichiers modifiés principaux
- registre/models.py (ajout DUERP, RegistreAccessibilite, DroitSignature, EtablissementUtilisateur)
- registre/views.py (vues DUERP, accessibilité, signature, droits, profil, rattachements)
- registre/urls.py (nouvelles routes)
- Templates/registre/ (duerp_detail, duerp_imprimer, accessibilite_detail, accessibilite_imprimer, droits_signature, mon_profil, admin_utilisateur_form)
- Templates/base.html (lien Mon profil dans sidebar)
- Templates/registre/administration.html (carte Droits de signature)

### Points techniques importants
- Bug RenameIndex : supprimer manuellement les opérations RenameIndex de chaque migration avant migrate
- Signatures permanentes : copiées sur le document, indépendantes du profil utilisateur
- DroitSignature.peut_signer() : Q(etablissement=etab) | Q(etablissement__isnull=True)
- DEBUG=True obligatoire en local pour servir les fichiers media

### Déploiement O2Switch
- git pull origin main ✅
- python manage.py migrate (0010 à 0014) ✅
- Correction branche : git branch -m master main + set-upstream

### Résultat
✅ Tous les modules fonctionnels en production.

---

## Modèle d'intervention (à copier pour chaque déploiement futur)

```
## JJ/MM/AAAA – [Titre de l'intervention]

### Objectif
...

### Migrations appliquées
- XXXX_nom : description

### Fichiers modifiés principaux
- ...

### Points techniques importants
- ...

### Déploiement O2Switch
- git pull origin main ✅ / ❌
- python manage.py migrate ✅ / ❌ / non nécessaire
- Restart application ✅ / ❌ / non nécessaire

### Résultat
✅ Succès / ❌ Échec — [notes]
```

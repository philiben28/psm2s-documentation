# MÉMO — POINTS À VÉRIFIER AVANT CODAGE
## Prochaine session de conception avec Guillaume

> À préparer avant la réunion de la semaine prochaine.

---

## 1. Dashboard — Cartes établissements par profil

**Principe validé :**
- Toutes les cartes établissements visibles sur le dashboard
- Seules les cartes de ses établissements sont cliquables pour un directeur
- Les autres cartes sont grisées avec un cadenas (comme dans SharePoint)

**Questions à clarifier :**
- Un directeur rattaché à plusieurs établissements voit-il toutes ses cartes actives ?
- Le DG voit-il tout comme un admin ou a-t-il un profil spécifique ?
- Un directeur adjoint a-t-il le même accès qu'un directeur ?

---

## 2. Filtrage des vues par établissement

**Ce qui est déjà fait :**
- ✅ Dashboard filtré par établissement pour directeur et factotum

**Ce qui reste à faire :**
- 🔲 Vue Contrôles — filtrer par établissements rattachés
- 🔲 Vue Tickets — filtrer par établissements rattachés
- 🔲 Vue Interventions — filtrer par établissements rattachés
- 🔲 Vérifier toutes les autres vues liste

---

## 3. Profils utilisateurs et niveaux d'accès

**Profils existants :**
- `admin` → tout, partout
- `responsable_securite` → tout, partout
- `directeur` → ses établissements uniquement
- `factotum` → ses établissements, accès à définir
- `prestataire` → tickets qui lui sont assignés uniquement

**Questions à clarifier avec Guillaume et RH PEP28 :**
- Le DG a-t-il un profil propre ou est-il `admin` ?
- Le directeur adjoint = directeur ou profil distinct ?
- Quels modules un factotum niveau 1 peut-il voir/modifier ?

---

## 4. Grille de niveaux Factotum

**Principe proposé :**
Une grille d'habilitation progressive, gérée par le directeur ou responsable sécurité.

**Niveaux envisagés (à valider) :**
| Niveau | Droits |
|---|---|
| 1 | Consultation uniquement |
| 2 | Saisir interventions et tickets |
| 3 | Signer les interventions |
| 4 | Accès complet factotum |

**Points à vérifier AVANT de coder :**
- ✅ Légalité : habilitation informatique = pratique courante, non discriminante
- ❓ Valider avec le service RH des PEP28 que cette grille est praticable terrain
- ❓ Le turnover élevé des factotums : la grille doit être simple à gérer
- ❓ Qui peut modifier le niveau d'un factotum ? (directeur seul ? + responsable sécurité ?)
- ❓ Combien de niveaux sont vraiment utiles ? (trop fin = jamais utilisé)

---

## 5. Registre de Sécurité — Architecture par bâtiment

**Fondement réglementaire (à utiliser dans l'argumentaire de vente) :**
L'article R.123-51 du Code de la construction et de l'habitation impose un registre de sécurité à tout ERP.
La réglementation précise :
> *"Lorsqu'un établissement comprend plusieurs bâtiments isolés, la détermination de la catégorie et l'application des règles se font séparément pour chaque bâtiment."*

**Conséquence directe sur PSM2S :**
- **1 bâtiment ERP = 1 registre de sécurité obligatoire**
- Un établissement avec 3 bâtiments ERP actifs = 3 registres distincts
- Chaque registre contient : contrôles/vérifications propres au bâtiment, dates de travaux, consignes d'évacuation

**Ce qui reste au niveau établissement** (Code du Travail, pas CCH) :
- DUERP, Registre Accessibilité, Tickets travaux, Interventions, Commissions, Contrats

**Architecture cible :**
- Ajouter un modèle `Batiment` rattaché à `Etablissement`
- Chaque bâtiment a son propre registre de sécurité PDF
- Les contrôles réglementaires se rattachent au bâtiment concerné
- **Impact tarifaire direct** : 4€/mois par bâtiment ERP actif (registre facturable)

**Références :**
- [Article R123-51 — Légifrance](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039040918)
- [Registre de sécurité ERP — mon-erp.fr](https://mon-erp.fr/registre-de-securite/)

**Questions à clarifier avec Guillaume :**
- Un contrôle réglementaire (ex. vérification électrique) est-il toujours rattaché à un bâtiment précis ?
- Quel contenu apparaît dans le registre par bâtiment vs. niveau établissement ?
- Format final : vue web imprimable PDF ou page interactive ?

---

## 6. Commercialisation — Points à finaliser

**Modèle tarifaire validé :**
- 40€/mois par établissement (part fixe)
- 4€/mois par registre de sécurité / bâtiment ERP actif
- Engagement 36 ou 48 mois
- Phase pilote 3 mois sur 1-2 sites volontaires (pas de sans-engagement)

**Questions à clarifier :**
- Confirmer les 3 directeurs volontaires pour la phase pilote
- Définir contractuellement ce qu'est un "registre facturable" (bâtiment ERP ouvert et actif)
- Remise pour engagement 48 mois vs 36 mois ?
- Conditions de sortie anticipée ?
- Qui signe le contrat côté PEP28 ?

---

## 7. Prochaines étapes techniques (après réunion)

1. Dashboard — cartes grisées pour établissements non rattachés
2. Filtrage Contrôles / Tickets / Interventions par établissement
3. Grille niveaux factotum (après validation RH)
4. Refonte Registre de Sécurité
5. Signature sur les interventions (factotum)
6. Veille réglementaire (après spécification avec Guillaume)

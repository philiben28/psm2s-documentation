# MÉMO COMMANDES – PSM2S V2

> Toutes les commandes PowerShell et SSH utiles au quotidien.

---

## PowerShell — Répertoire de travail

Toujours se placer dans le bon dossier en premier :
```powershell
cd C:\Users\Philippe\PSM2S_V2_DEV
```

---

## Serveur local

### Lancer le serveur de développement
```powershell
python manage.py runserver
```
Puis ouvrir : http://127.0.0.1:8000

### Arrêter le serveur
```
Ctrl + C
```

---

## Git — Sauvegarde et publication

### Sauvegarder et envoyer vers GitHub
```powershell
git add -A
git commit -m "Description de ce qui a été fait"
.\git_push.ps1
```
Le script `git_push.ps1` demande le token GitHub (`ghp_...`).

### Voir l'état des fichiers modifiés
```powershell
git status
```

### Voir l'historique des commits
```powershell
git log --oneline
```

---

## Django — Commandes utiles

### Vérifier que le projet est sain (0 erreur)
```powershell
python manage.py check
```

### Créer une nouvelle migration après modification des modèles
```powershell
python manage.py makemigrations
```
⚠️ Ouvrir le fichier de migration créé et **supprimer les lignes RenameIndex** avant d'appliquer.

### Appliquer les migrations
```powershell
python manage.py migrate
```

### Revenir à une migration précédente (si problème)
```powershell
python manage.py migrate registre 0012
```
(remplacer 0012 par le numéro voulu)

### Charger le référentiel DUERP
```powershell
python manage.py charger_duerp_master
```

### Envoyer les alertes email manuellement
```powershell
python manage.py envoyer_alertes
```

### Ouvrir le shell Django (pour tester du code)
```powershell
python manage.py shell
```

---

## O2Switch — Connexion SSH

Se connecter via le terminal SSH O2Switch (panneau cPanel).

### Activer l'environnement virtuel (toujours en premier)
```bash
source /home/roda4402/virtualenv/psm2s_v2/3.9/bin/activate
```

### Se placer dans le projet
```bash
cd /home/roda4402/psm2s_v2
```

### Récupérer les dernières modifications depuis GitHub
```bash
git pull origin main
```

### Appliquer les migrations en production
```bash
python manage.py migrate
```

### Vérifier les migrations appliquées
```bash
python manage.py showmigrations registre
```

### ⚠️ Migration RenameIndex en production — solution rapide
Si `migrate` échoue avec `no such index`, c'est une migration parasite RenameIndex.
Ne pas essayer de modifier le fichier en SSH. Utiliser `--fake` à la place :
```bash
python manage.py migrate registre 0015 --fake
```
(remplacer 0015 par le numéro de la migration en échec)
`--fake` marque la migration comme appliquée sans toucher à la base de données.

---

## Séquence complète de déploiement

### 1. Sur le PC (PowerShell)
```powershell
cd C:\Users\Philippe\PSM2S_V2_DEV
git add -A
git commit -m "Description"
.\git_push.ps1
```

### 2. Sur O2Switch (SSH)
```bash
source /home/roda4402/virtualenv/psm2s_v2/3.9/bin/activate
cd /home/roda4402/psm2s_v2
git pull origin main
python manage.py migrate        # seulement si nouvelles migrations
```

### 3. Redémarrage (si settings.py modifié)
O2Switch → cPanel → Setup Python App → Restart

---

## Rappels importants

- Les **données** (établissements, utilisateurs, DUERP...) ne passent pas via Git — à saisir directement en prod.
- Le **code** (fichiers .py, templates, migrations) voyage via Git.
- `DEBUG = True` en local pour afficher les images/signatures — `False` en prod.
- Chaque nouvelle migration contient des **RenameIndex à supprimer** avant `migrate`.

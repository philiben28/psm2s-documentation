#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  SAUVEGARDE AUTOMATIQUE – PSM2S V2
#  À exécuter via cron job O2Switch (chaque nuit)
# ─────────────────────────────────────────────────────────────

PROJECT_DIR="/home/roda4402/psm2s_v2"
BACKUP_DIR="/home/roda4402/psm2s_v2/backups"
DB_FILE="$PROJECT_DIR/db.sqlite3"
DATE=$(date +"%Y-%m-%d_%H-%M")
BACKUP_FILE="$BACKUP_DIR/db_$DATE.sqlite3"

# Créer le dossier backups s'il n'existe pas
mkdir -p "$BACKUP_DIR"

# Copier la base de données
cp "$DB_FILE" "$BACKUP_FILE"

# Supprimer les sauvegardes de plus de 7 jours
find "$BACKUP_DIR" -name "db_*.sqlite3" -mtime +7 -delete

echo "[$DATE] Sauvegarde OK : $BACKUP_FILE"

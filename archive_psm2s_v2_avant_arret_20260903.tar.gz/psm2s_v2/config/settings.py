"""
Paramètres Django pour le projet Registre de Sécurité PSM2S
"""

from pathlib import Path
import os

# Répertoire racine du projet
BASE_DIR = Path(__file__).resolve().parent.parent

# ─────────────────────────────────────────────
#  SÉCURITÉ
# ─────────────────────────────────────────────

SECRET_KEY = os.getenv('DJANGO_SECRET_KEY', 'django-insecure-remplacer-cette-cle-en-production')

DEBUG = True  # Passer à False en production réelle

ALLOWED_HOSTS = [
    'psm2s.pbci-conseils.fr',
    'www.psm2s.pbci-conseils.fr',
    '127.0.0.1',
    'localhost',
]

SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = 'DENY'
SECURE_REFERRER_POLICY = "same-origin"

# ─────────────────────────────────────────────
#  APPLICATIONS INSTALLÉES
# ─────────────────────────────────────────────

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'registre',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'config.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [
            BASE_DIR / 'templates',   # dossier templates/ (minuscules)
            BASE_DIR / 'Templates',   # dossier Templates/ (majuscule — compatibilité)
        ],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'config.wsgi.application'

# ─────────────────────────────────────────────
#  BASE DE DONNÉES
# ─────────────────────────────────────────────

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# ─────────────────────────────────────────────
#  MODÈLE UTILISATEUR PERSONNALISÉ
# ─────────────────────────────────────────────

AUTH_USER_MODEL = 'registre.Utilisateur'

# Page de connexion PSM2S
LOGIN_URL = '/connexion/'
LOGIN_REDIRECT_URL = '/'

# ─────────────────────────────────────────────
#  MOT DE PASSE
# ─────────────────────────────────────────────

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# ─────────────────────────────────────────────
#  LANGUE ET FUSEAU HORAIRE
# ─────────────────────────────────────────────

LANGUAGE_CODE = 'fr-fr'
TIME_ZONE     = 'Europe/Paris'
USE_I18N      = True
USE_TZ        = True

# ─────────────────────────────────────────────
#  FICHIERS STATIQUES ET MÉDIAS
# ─────────────────────────────────────────────

STATIC_URL  = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL   = '/media/'
MEDIA_ROOT  = BASE_DIR / 'media'

DATA_UPLOAD_MAX_MEMORY_SIZE = 20 * 1024 * 1024  # 20 Mo

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# URL de base du site (utilisée dans les emails d'alerte)
BASE_URL = 'https://psm2s.pbci-conseils.fr'

# Nom de l'organisation affiché dans le tableau de bord
NOM_ORGANISATION = 'Patrimoine ADPEP28'

# ─────────────────────────────────────────────
#  EMAILS — SMTP O2switch
# ─────────────────────────────────────────────

EMAIL_BACKEND        = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST           = 'localhost'
EMAIL_PORT           = 25
EMAIL_USE_TLS        = False
EMAIL_HOST_USER      = ''
EMAIL_HOST_PASSWORD  = ''
DEFAULT_FROM_EMAIL   = 'psm2s@pbci-conseils.fr'

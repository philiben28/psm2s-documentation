"""
Supprime les classes DUERP en double dans models.py.
Garde uniquement la premiere occurrence de chaque classe.
"""

fichier = "registre/models.py"

with open(fichier, encoding="utf-8") as f:
    lignes = f.readlines()

classes_vues = set()
classes_duerp = {
    "class DUERP(",
    "class UniteTravail(",
    "class CategorieRisque(",
    "class SourceDanger(",
    "class EvaluationRisque(",
    "class PlanActionDUERP(",
}

# Trouver la ligne de debut du doublon
debut_doublon = None
for i, ligne in enumerate(lignes):
    stripped = ligne.strip()
    for cls in classes_duerp:
        if stripped.startswith(cls):
            if cls in classes_vues:
                # Deuxieme occurrence : c'est ici que commence le doublon
                debut_doublon = i
                break
            else:
                classes_vues.add(cls)
    if debut_doublon is not None:
        break

if debut_doublon is not None:
    print(f"Doublon trouve a la ligne {debut_doublon + 1}. Suppression...")
    lignes_propres = lignes[:debut_doublon]
    with open(fichier, "w", encoding="utf-8") as f:
        f.writelines(lignes_propres)
    print(f"OK - fichier reduit de {len(lignes)} a {len(lignes_propres)} lignes.")
else:
    print("Aucun doublon trouve.")

# ============================================================
# PSM2S V2 - Push vers GitHub (version corrigée)
# ============================================================

$GITHUB_USER = "philiben28"
$GITHUB_REPO = "psm2s-securite"

# Lecture du token en clair (plus fiable)
$token = Read-Host "Collez votre token GitHub (ghp_...)"
$token = $token.Trim()

# Configuration des credentials Git (Windows Credential Manager)
git config credential.helper manager-core

# URL avec token
$remoteUrl = "https://" + $token + "@github.com/" + $GITHUB_USER + "/" + $GITHUB_REPO + ".git"
git remote set-url origin $remoteUrl

Write-Host "=== Push vers GitHub ===" -ForegroundColor Cyan
git push -u origin main --force

if ($LASTEXITCODE -eq 0) {
    Write-Host "=== SUCCES ===" -ForegroundColor Green
    Write-Host "https://github.com/$GITHUB_USER/$GITHUB_REPO" -ForegroundColor Yellow
} else {
    Write-Host "=== ERREUR - verifiez votre token ===" -ForegroundColor Red
}

# Nettoyage : URL sans token
git remote set-url origin "https://github.com/$GITHUB_USER/$GITHUB_REPO.git"
Write-Host "Token retire de la config." -ForegroundColor Gray

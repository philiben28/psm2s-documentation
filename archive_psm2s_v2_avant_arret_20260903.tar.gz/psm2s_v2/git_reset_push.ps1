# ============================================================
# PSM2S V2 - Réinitialisation Git et push vers GitHub
# À exécuter depuis : C:\Users\Philippe\PSM2S_V2_DEV
# ============================================================

# --- CONFIGURATION ---
$GITHUB_USER  = "philiben28"
$GITHUB_REPO  = "psm2s-securite"
$GIT_NAME     = "Philippe Bénard"
$GIT_EMAIL    = "philiben28@gmail.com"

# Demande du token GitHub (ne s'affiche pas à l'écran)
$tokenSecure = Read-Host "Collez votre GitHub Personal Access Token" -AsSecureString
$token = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
    [Runtime.InteropServices.Marshal]::SecureStringToBSTR($tokenSecure)
)

Write-Host ""
Write-Host "=== Etape 1/6 : Suppression du .git corrompu ===" -ForegroundColor Cyan
Remove-Item -Recurse -Force ".git" -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force ".git_backup" -ErrorAction SilentlyContinue
Write-Host "OK" -ForegroundColor Green

Write-Host "=== Etape 2/6 : Initialisation Git ===" -ForegroundColor Cyan
git init
git config user.name  $GIT_NAME
git config user.email $GIT_EMAIL
Write-Host "OK" -ForegroundColor Green

Write-Host "=== Etape 3/6 : Ajout du remote GitHub ===" -ForegroundColor Cyan
$remoteUrl = "https://$token@github.com/$GITHUB_USER/$GITHUB_REPO.git"
git remote add origin $remoteUrl
Write-Host "OK" -ForegroundColor Green

Write-Host "=== Etape 4/6 : Indexation des fichiers ===" -ForegroundColor Cyan
git add .
git status
Write-Host "OK" -ForegroundColor Green

Write-Host "=== Etape 5/6 : Commit initial ===" -ForegroundColor Cyan
git commit -m "chore: réinitialisation dépôt - état complet PSM2S V2 au 05/06/2026"
Write-Host "OK" -ForegroundColor Green

Write-Host "=== Etape 6/6 : Push vers GitHub (force) ===" -ForegroundColor Cyan
git branch -M main
git push -u origin main --force
Write-Host ""
if ($LASTEXITCODE -eq 0) {
    Write-Host "=== SUCCES : Code poussé sur GitHub ===" -ForegroundColor Green
    Write-Host "Dépôt : https://github.com/$GITHUB_USER/$GITHUB_REPO" -ForegroundColor Yellow
} else {
    Write-Host "=== ERREUR lors du push - vérifiez votre token ===" -ForegroundColor Red
}

# Nettoyage : remplacer l'URL avec token par une URL propre
git remote set-url origin "https://github.com/$GITHUB_USER/$GITHUB_REPO.git"
Write-Host "Token retiré de la config Git locale." -ForegroundColor Gray

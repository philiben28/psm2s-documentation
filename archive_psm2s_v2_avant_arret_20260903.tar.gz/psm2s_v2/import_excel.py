"""
Script d'importation du tableau de bord Excel vers la base de données Django.
À placer à la racine du projet psm2s_securite/ et lancer avec :
    python import_excel.py

Nécessite : pip install openpyxl
"""

import os
import sys
import django
from datetime import datetime

# ── Configuration Django ──────────────────────────────────────────────────────
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
django.setup()

# ── Import des modèles ────────────────────────────────────────────────────────
from registre.models import Etablissement, TypeControle, ControleEtablissement

import openpyxl

# ── Chemin vers le fichier Excel ──────────────────────────────────────────────
FICHIER_EXCEL = 'Tableau de bord securite PSM2S.xlsx'

# ── Onglets à ignorer (pas des établissements) ────────────────────────────────
ONGLETS_A_IGNORER = ['tableau de bord sécurité 2026']

# ── Correspondance statut Excel → statut Django ───────────────────────────────
def detecter_statut(valeur):
    if valeur is None or valeur == 0:
        return 'a_faire'
    if valeur == 'X':
        return 'pas_obligation'
    if valeur == 'NC':
        return 'a_faire'
    if isinstance(valeur, datetime):
        return 'fait'
    if isinstance(valeur, str) and valeur.strip().lower() in ('présent', 'present'):
        return 'fait'
    if isinstance(valeur, (int, float)) and valeur > 0:
        return 'fait'
    return 'a_faire'

# ── Extraire la date si c'est un datetime ────────────────────────────────────
def extraire_date(valeur):
    if isinstance(valeur, datetime):
        return valeur.date()
    return None

# ── Liste des types de contrôles à créer ─────────────────────────────────────
TYPES_CONTROLES = [
    # (nom, type_action, categorie, periodicite)
    ('Commission de sécurité', 'PV', 'incendie', 'ponctuel'),
    ('Triennale', 'contrôle', 'incendie', 'triennal'),
    ('Alarme incendie', 'entretien', 'incendie', 'annuel'),
    ('Extincteurs', 'entretien', 'incendie', 'annuel'),
    ('Désenfumage', 'entretien', 'incendie', 'annuel'),
    ('Exercices incendie', '1', 'exercice', 'annee_scolaire'),
    ('Exercices incendie', '2', 'exercice', 'annee_scolaire'),
    ('Exercices PPMS', '1', 'exercice', 'annee_scolaire'),
    ('Exercices PPMS', '2', 'exercice', 'annee_scolaire'),
    ("Calage des dates d'exercices", 'date butoir fin Août', 'exercice', 'annuel'),
    ('Électricité', 'vérification', 'electricite', 'annuel'),
    ('Blocs de secours', 'vérification', 'electricite', 'mensuel'),
    ('Ascenseur', 'entretien', 'ascenseur', 'annuel'),
    ('Ascenseur', 'vérification', 'ascenseur', 'annuel'),
    ('Quinquennale', 'contrôle', 'incendie', 'quinquennal'),
    ('Élévateur', 'entretien', 'ascenseur', 'annuel'),
    ('Élévateur', 'vérification', 'ascenseur', 'annuel'),
    ('Portail', 'vérification', 'autre', 'annuel'),
    ('Groupe électrogène', 'entretien', 'electricite', 'annuel'),
    ('Jeux extérieur', 'vérification', 'autre', 'annuel'),
    ("Mur d'escalade", 'vérification', 'autre', 'annuel'),
    ('Chaufferie', 'ramonage', 'gaz', 'annuel'),
    ('Disconnecteur', 'vérification', 'gaz', 'annuel'),
    ('Gaz', 'vérification', 'gaz', 'annuel'),
    ('CTA', 'entretien', 'autre', 'annuel'),
    ('CTA', 'vérification', 'autre', 'annuel'),
    ("Plans d'intervention", '', 'document', 'annuel'),
    ('Plans des abords extérieur', '', 'document', 'annuel'),
    ('Personnel SST', 'formation', 'formation', 'annuel'),
    ('Personnel EPI', 'formation', 'formation', 'annuel'),
    ('Manipulation SSI', 'formation', 'formation', 'annuel'),
    ('Personnel habilité ELEC', 'formation', 'formation', 'annuel'),
    ('Diag accessibilité handicapés', '', 'accessibilite', 'ponctuel'),
    ('Diag technique amiante et plombs', 'tous les 3ans si présence', 'autre', 'triennal'),
    ('Procédures de coupures GAZ', '', 'document', 'annuel'),
    ('Procédures de coupures ELEC', '', 'document', 'annuel'),
    ('Procédures de coupures EAU', '', 'document', 'annuel'),
    ("Procédures évacuation incendie", '', 'document', 'annuel'),
    ('Procédures ouverture portail', '', 'document', 'annuel'),
    ("Procédures accès aux bâtiments", '', 'document', 'annuel'),
    ('Plan Bleu', 'mise à jour', 'document', 'annuel'),
    ('DUERP', 'mise à jour', 'document', 'annuel'),
    ('Carnet sanitaire EAU', 'contrôle T°', 'sanitaire', 'mensuel'),
    ('Carnet sanitaire EAU', 'légionelles', 'sanitaire', 'annuel'),
]

# ── Correspondance nom de ligne Excel → TypeControle ─────────────────────────
CORRESPONDANCE = {
    ('Commission de sécurité', 'PV'):                    ('Commission de sécurité', 'PV'),
    ('Triennale', 'contrôle'):                           ('Triennale', 'contrôle'),
    ('alarme incendie', 'entretien'):                    ('Alarme incendie', 'entretien'),
    ('Alarme incendie', 'entretien'):                    ('Alarme incendie', 'entretien'),
    ('alarme incendie', 'vérification'):                 ('Alarme incendie', 'entretien'),
    ('Extinteurs', 'entretien'):                         ('Extincteurs', 'entretien'),
    ('Extincteurs', 'entretien'):                        ('Extincteurs', 'entretien'),
    ('Désenfumage', 'entretien'):                        ('Désenfumage', 'entretien'),
    ('Exercices incendie', '1'):                         ('Exercices incendie', '1'),
    ('Exercices incendie', 1):                           ('Exercices incendie', '1'),
    ('Exercices incendie', '2'):                         ('Exercices incendie', '2'),
    ('Exercices incendie', 2):                           ('Exercices incendie', '2'),
    ('Exercices PPMS', '1'):                             ('Exercices PPMS', '1'),
    ('Exercices PPMS', 1):                               ('Exercices PPMS', '1'),
    ('Exercices PPMS', '2'):                             ('Exercices PPMS', '2'),
    ('Exercices PPMS', 2):                               ('Exercices PPMS', '2'),
    ("calage des dates d'exercices de l'année scolaire", 'date butoir fin Août'): ("Calage des dates d'exercices", 'date butoir fin Août'),
    ('Électricité', 'vérification'):                     ('Électricité', 'vérification'),
    ('blocs de secours (internat mensuel)', 'vérification'): ('Blocs de secours', 'vérification'),
    ('Ascenseur', 'entretien'):                          ('Ascenseur', 'entretien'),
    ('Ascenseur', 'vérification'):                       ('Ascenseur', 'vérification'),
    ('Quinquenale', 'contrôle'):                         ('Quinquennale', 'contrôle'),
    ('Élévateur', 'entretien'):                          ('Élévateur', 'entretien'),
    ('Élévateur', 'vérification'):                       ('Élévateur', 'vérification'),
    ('Portail', 'vérification'):                         ('Portail', 'vérification'),
    ('Groupe électrogène', 'entretien'):                 ('Groupe électrogène', 'entretien'),
    ('Jeux exterieur', 'vérification'):                  ('Jeux extérieur', 'vérification'),
    ("Mur d'escalade", 'vérification'):                  ("Mur d'escalade", 'vérification'),
    ('Chaufferie', 'ramonage'):                          ('Chaufferie', 'ramonage'),
    ('Disconnecteur', 'vérification'):                   ('Disconnecteur', 'vérification'),
    ('Gaz', 'vérification'):                             ('Gaz', 'vérification'),
    ('CTA', 'entretien'):                                ('CTA', 'entretien'),
    ('CTA', 'vérification'):                             ('CTA', 'vérification'),
    ("Plans d'intervention", None):                      ("Plans d'intervention", ''),
    ("Plans d'intervention", ''):                        ("Plans d'intervention", ''),
    ('Plans des abords extérieur (point de rassemblement et circulation)', None): ('Plans des abords extérieur', ''),
    ('Personnel SST', 'formation'):                      ('Personnel SST', 'formation'),
    ('Personnel EPI', 'formation'):                      ('Personnel EPI', 'formation'),
    ('Manipulation SSI', 'formation'):                   ('Manipulation SSI', 'formation'),
    ('Personnel habilité ELEC', 'formation'):            ('Personnel habilité ELEC', 'formation'),
    ('Diag accessibilité handicapes', None):             ('Diag accessibilité handicapés', ''),
    ('Diag accessibilité handicapes', ''):               ('Diag accessibilité handicapés', ''),
    ('Diag technique amiante et plombs', 'tous les 3ans si présence'): ('Diag technique amiante et plombs', 'tous les 3ans si présence'),
    ('Procédures de coupures GAZ', None):                ('Procédures de coupures GAZ', ''),
    ('Procédures de coupures ELEC', None):               ('Procédures de coupures ELEC', ''),
    ('Procédures de coupures EAU', None):                ('Procédures de coupures EAU', ''),
    ("Procédures évacuation incendie", None):            ("Procédures évacuation incendie", ''),
    ('Procédures ouverture portail', None):              ('Procédures ouverture portail', ''),
    ("Procédures accès aux bâtiments", None):            ("Procédures accès aux bâtiments", ''),
    ('Plan Bleu', 'mise à jour'):                        ('Plan Bleu', 'mise à jour'),
    ('DUERP', 'mise à jour'):                            ('DUERP', 'mise à jour'),
    ('carnet sanitaire EAU', 'contrôle T°'):             ('Carnet sanitaire EAU', 'contrôle T°'),
    ('carnet sanitaire EAU', 'legionelles'):             ('Carnet sanitaire EAU', 'légionelles'),
    ('Avis préliminaire de la commision de sécurité', 'PV'): ('Commission de sécurité', 'PV'),
}


def creer_types_controles():
    """Crée tous les types de contrôles en base."""
    print("\n── Création des types de contrôles ──")
    crees = 0
    for nom, type_action, categorie, periodicite in TYPES_CONTROLES:
        tc, created = TypeControle.objects.get_or_create(
            nom=nom,
            type_action=type_action,
            defaults={
                'categorie':   categorie,
                'periodicite': periodicite,
                'obligatoire': True,
            }
        )
        if created:
            crees += 1
            print(f"  ✅ Créé : {nom} / {type_action}")
    print(f"  → {crees} types de contrôles créés.")


def creer_etablissements(wb):
    """Crée les établissements depuis les noms d'onglets."""
    print("\n── Création des établissements ──")
    crees = 0
    for sheet_name in wb.sheetnames:
        if sheet_name in ONGLETS_A_IGNORER:
            continue
        etab, created = Etablissement.objects.get_or_create(
            code=sheet_name,
            defaults={
                'nom':                     sheet_name,
                'obligation_reglementaire': sheet_name != 'PIPSP habitat inclusif',
                'actif':                   True,
            }
        )
        if created:
            crees += 1
            print(f"  ✅ Créé : {sheet_name}")
    print(f"  → {crees} établissements créés.")


def importer_controles(wb):
    """Importe les contrôles depuis chaque onglet."""
    print("\n── Importation des contrôles ──")
    total = 0
    erreurs = 0

    for sheet_name in wb.sheetnames:
        if sheet_name in ONGLETS_A_IGNORER:
            continue

        try:
            etab = Etablissement.objects.get(code=sheet_name)
        except Etablissement.DoesNotExist:
            print(f"  ⚠ Établissement non trouvé : {sheet_name}")
            continue

        ws = wb[sheet_name]
        objet_courant = None

        for row in ws.iter_rows(values_only=True):
            objet    = row[0]
            action   = row[1]
            valeur   = row[2]
            remarque = row[3]
            direction = row[4]

            # Mémoriser l'objet courant si la cellule n'est pas vide
            if objet and isinstance(objet, str) and objet not in (
                'Objet', 'FAIT', 'A REFAIRE', 'A FAIRE', 'REMARQUE', 'X  Pas d\'obligation'
            ):
                objet_courant = objet

            # Ignorer les lignes sans action ni valeur utile
            if not objet_courant or action is None and valeur is None:
                continue

            # Ignorer les lignes de légende
            if objet in ('FAIT', 'A REFAIRE', 'A FAIRE', 'REMARQUE', 'X  Pas d\'obligation'):
                continue

            # Chercher la correspondance
            cle = (objet_courant if objet else objet_courant, action)
            if cle not in CORRESPONDANCE:
                continue

            nom_tc, action_tc = CORRESPONDANCE[cle]

            try:
                tc = TypeControle.objects.get(nom=nom_tc, type_action=action_tc)
            except TypeControle.DoesNotExist:
                erreurs += 1
                continue

            statut        = detecter_statut(valeur)
            date_real     = extraire_date(valeur)
            remarques_resp = str(remarque) if remarque else ''
            remarques_dir  = str(direction) if direction else ''

            # Cas spécial : "X Pas d'obligation"
            if isinstance(valeur, str) and 'Pas d\'obligation' in valeur:
                statut = 'pas_obligation'

            controle, created = ControleEtablissement.objects.get_or_create(
                etablissement=etab,
                type_controle=tc,
                defaults={
                    'statut':               statut,
                    'date_realisation':     date_real,
                    'remarques_responsable': remarques_resp,
                    'remarques_direction':  remarques_dir,
                }
            )

            if not created:
                # Mettre à jour si déjà existant
                controle.statut = statut
                if date_real:
                    controle.date_realisation = date_real
                if remarques_resp:
                    controle.remarques_responsable = remarques_resp
                if remarques_dir:
                    controle.remarques_direction = remarques_dir
                controle.save()

            total += 1

        print(f"  ✅ {sheet_name} : {total} contrôles importés")
        total = 0

    if erreurs:
        print(f"\n  ⚠ {erreurs} lignes non reconnues (normal pour les lignes de titre/légende)")


def main():
    print("╔══════════════════════════════════════════════╗")
    print("║   Import Excel → Base de données PSM2S       ║")
    print("╚══════════════════════════════════════════════╝")

    # Vérifier que le fichier Excel existe
    if not os.path.exists(FICHIER_EXCEL):
        print(f"\n❌ Fichier non trouvé : {FICHIER_EXCEL}")
        print("   Placez le fichier Excel à la racine du projet.")
        sys.exit(1)

    print(f"\n📂 Lecture de : {FICHIER_EXCEL}")
    wb = openpyxl.load_workbook(FICHIER_EXCEL, read_only=True, data_only=True)

    creer_types_controles()
    creer_etablissements(wb)
    importer_controles(wb)

    print("\n✅ Import terminé avec succès !")
    print("   Connectez-vous sur /admin/ pour vérifier vos données.")


if __name__ == '__main__':
    main()
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils import timezone
from .models import (
    Utilisateur, Etablissement, EtablissementUtilisateur,
    TypeControle, ControleEtablissement, Document,
    TicketTravaux, Intervention,
    DUERP, UniteTravail, CategorieRisque, SourceDanger,
    EvaluationRisque, PlanActionDUERP,
    RegistreAccessibilite, EvaluationZone, FormationPersonnel,
    PieceAdministrative, ActionMiseConformite,
    DroitSignature,
)


# ─────────────────────────────────────────────
#  UTILISATEURS
# ─────────────────────────────────────────────

@admin.register(Utilisateur)
class UtilisateurAdmin(UserAdmin):
    list_display  = ('username', 'get_full_name', 'email', 'role', 'is_active')
    list_filter   = ('role', 'is_active')
    search_fields = ('username', 'first_name', 'last_name', 'email')
    ordering      = ('last_name', 'first_name')

    fieldsets = UserAdmin.fieldsets + (
        ("Role dans l'application", {
            'fields': ('role',)
        }),
    )


# ─────────────────────────────────────────────
#  ETABLISSEMENTS
# ─────────────────────────────────────────────

class EtablissementUtilisateurInline(admin.TabularInline):
    model               = EtablissementUtilisateur
    extra               = 1
    verbose_name        = "Utilisateur rattache"
    verbose_name_plural = "Utilisateurs rattaches"


@admin.register(Etablissement)
class EtablissementAdmin(admin.ModelAdmin):
    list_display  = ('code', 'nom', 'type_erp', 'categorie', 'ville', 'obligation_reglementaire', 'actif')
    list_filter   = ('type_erp', 'categorie', 'obligation_reglementaire', 'actif')
    search_fields = ('nom', 'code', 'ville')
    ordering      = ('nom',)
    inlines       = [EtablissementUtilisateurInline]

    fieldsets = (
        ('Identification', {
            'fields': ('nom', 'code', 'actif')
        }),
        ('Reglementation ERP', {
            'fields': ('type_erp', 'categorie', 'obligation_reglementaire')
        }),
        ('Localisation', {
            'fields': ('adresse', 'ville')
        }),
        ('Notes', {
            'fields': ('note',),
            'classes': ('collapse',)
        }),
    )


# ─────────────────────────────────────────────
#  TYPES DE CONTROLES
# ─────────────────────────────────────────────

@admin.register(TypeControle)
class TypeControleAdmin(admin.ModelAdmin):
    list_display  = ('nom', 'type_action', 'categorie', 'periodicite', 'obligatoire')
    list_filter   = ('categorie', 'periodicite', 'obligatoire')
    search_fields = ('nom', 'type_action')
    ordering      = ('categorie', 'nom')

    fieldsets = (
        ('Identification', {
            'fields': ('nom', 'type_action', 'categorie')
        }),
        ('Reglementation', {
            'fields': ('periodicite', 'obligatoire', 'description')
        }),
    )


# ─────────────────────────────────────────────
#  REGISTRE : CONTROLES PAR ETABLISSEMENT
# ─────────────────────────────────────────────

class DocumentInline(admin.TabularInline):
    model               = Document
    extra               = 1
    fields              = ('type_doc', 'nom_fichier', 'fichier', 'note')
    verbose_name        = "Document joint"
    verbose_name_plural = "Documents joints"


class TicketTravauxInline(admin.TabularInline):
    model               = TicketTravaux
    extra               = 0
    fields              = ('titre', 'priorite', 'statut', 'responsable', 'date_cible')
    readonly_fields     = ('statut',)
    verbose_name        = "Ticket travaux lie"
    verbose_name_plural = "Tickets travaux lies"
    show_change_link    = True


@admin.register(ControleEtablissement)
class ControleEtablissementAdmin(admin.ModelAdmin):
    list_display  = (
        'etablissement', 'type_controle',
        'statut', 'priorite',
        'date_realisation', 'prochaine_echeance',
        'retard', 'mis_a_jour_par'
    )
    list_filter   = (
        'statut', 'priorite',
        'etablissement', 'type_controle__categorie'
    )
    search_fields = (
        'etablissement__nom', 'etablissement__code',
        'type_controle__nom',
        'remarques_responsable', 'remarques_direction'
    )
    ordering      = ('etablissement', 'type_controle__categorie')
    date_hierarchy = 'date_realisation'
    inlines       = [DocumentInline, TicketTravauxInline]

    fieldsets = (
        ('Identification', {
            'fields': ('etablissement', 'type_controle')
        }),
        ('Etat du controle', {
            'fields': ('statut', 'priorite', 'date_realisation', 'prochaine_echeance')
        }),
        ('Remarques', {
            'fields': ('remarques_responsable', 'remarques_direction'),
        }),
        ('Tracabilite', {
            'fields': ('mis_a_jour_par',),
            'classes': ('collapse',)
        }),
    )

    readonly_fields = ('date_mise_a_jour', 'date_creation')

    def save_model(self, request, obj, form, change):
        obj.mis_a_jour_par = request.user
        super().save_model(request, obj, form, change)

    @admin.display(description='En retard ?')
    def retard(self, obj):
        if obj.est_en_retard:
            return 'En retard'
        return 'OK'


# ─────────────────────────────────────────────
#  DOCUMENTS
# ─────────────────────────────────────────────

@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display    = ('nom_fichier', 'type_doc', 'controle', 'date_depot', 'depose_par')
    list_filter     = ('type_doc',)
    search_fields   = ('nom_fichier', 'controle__etablissement__nom', 'note')
    ordering        = ('-date_depot',)
    readonly_fields = ('date_depot',)

    fieldsets = (
        ('Fichier', {
            'fields': ('nom_fichier', 'fichier', 'type_doc', 'note')
        }),
        ('Rattachement', {
            'fields': ('controle', 'depose_par')
        }),
        ('Tracabilite', {
            'fields': ('date_depot',),
            'classes': ('collapse',)
        }),
    )


# ─────────────────────────────────────────────
#  TICKETS TRAVAUX
# ─────────────────────────────────────────────

class InterventionInline(admin.TabularInline):
    model               = Intervention
    extra               = 1
    fields              = ('date_intervention', 'prestataire', 'realise_en_interne', 'statut', 'montant')
    verbose_name        = "Intervention"
    verbose_name_plural = "Interventions"


@admin.register(TicketTravaux)
class TicketTravauxAdmin(admin.ModelAdmin):
    list_display  = (
        'priorite', 'titre', 'etablissement',
        'statut', 'responsable',
        'date_cible', 'delai',
        'cout_estime', 'cout_reel'
    )
    list_filter   = ('statut', 'priorite', 'etablissement')
    search_fields = ('titre', 'description', 'etablissement__nom', 'etablissement__code')
    ordering      = ('-date_creation',)
    date_hierarchy = 'date_creation'
    inlines       = [InterventionInline]

    fieldsets = (
        ('Identification', {
            'fields': ('etablissement', 'controle', 'titre', 'description')
        }),
        ('Priorisation et planning', {
            'fields': ('priorite', 'statut', 'responsable', 'date_cible')
        }),
        ('Budget', {
            'fields': ('cout_estime', 'cout_reel'),
        }),
        ('Tracabilite', {
            'fields': ('cree_par', 'date_creation', 'date_cloture'),
            'classes': ('collapse',)
        }),
    )

    readonly_fields = ('date_creation', 'date_cloture')

    def save_model(self, request, obj, form, change):
        if not obj.pk:
            obj.cree_par = request.user
        super().save_model(request, obj, form, change)

    @admin.display(description='Delai')
    def delai(self, obj):
        if obj.statut == 'cloture':
            return 'Cloture'
        if obj.date_cible and obj.date_cible < timezone.now().date():
            return 'En retard'
        if obj.date_cible:
            delta = (obj.date_cible - timezone.now().date()).days
            return 'J-' + str(delta)
        return '-'


# ─────────────────────────────────────────────
#  INTERVENTIONS
# ─────────────────────────────────────────────

@admin.register(Intervention)
class InterventionAdmin(admin.ModelAdmin):
    list_display  = ('ticket', 'date_intervention', 'prestataire', 'statut', 'montant')
    list_filter   = ('statut', 'realise_en_interne')
    search_fields = ('prestataire', 'description', 'ticket__titre')
    ordering      = ('-date_intervention',)

    fieldsets = (
        ('Ticket concerne', {
            'fields': ('ticket',)
        }),
        ('Intervention', {
            'fields': (
                'date_intervention', 'prestataire',
                'realise_en_interne', 'statut',
                'description', 'montant'
            )
        }),
        ('Tracabilite', {
            'fields': ('saisie_par',),
            'classes': ('collapse',)
        }),
    )

    def save_model(self, request, obj, form, change):
        if not obj.pk:
            obj.saisie_par = request.user
        super().save_model(request, obj, form, change)


# ─────────────────────────────────────────────
#  MODULE DUERP
# ─────────────────────────────────────────────

class SourceDangerInline(admin.TabularInline):
    model  = SourceDanger
    extra  = 1
    fields = ('description', 'risque_potentiel', 'ordre')


@admin.register(CategorieRisque)
class CategorieRisqueAdmin(admin.ModelAdmin):
    list_display  = ('nom', 'type_unite', 'ordre')
    list_filter   = ('type_unite',)
    ordering      = ('type_unite', 'ordre')
    inlines       = [SourceDangerInline]


@admin.register(SourceDanger)
class SourceDangerAdmin(admin.ModelAdmin):
    list_display  = ('description', 'categorie', 'ordre')
    list_filter   = ('categorie__type_unite',)
    search_fields = ('description',)


class UniteTravailInline(admin.TabularInline):
    model  = UniteTravail
    extra  = 1
    fields = ('type_unite', 'nom_custom', 'ordre')


class PlanActionInline(admin.TabularInline):
    model  = PlanActionDUERP
    extra  = 0
    fields = ('description_action', 'responsable', 'delai', 'avancement', 'ticket')


@admin.register(DUERP)
class DUERPAdmin(admin.ModelAdmin):
    list_display  = ('etablissement', 'annee', 'statut', 'signataire', 'date_creation')
    list_filter   = ('statut', 'annee', 'etablissement')
    search_fields = ('etablissement__nom', 'signataire')
    ordering      = ('-annee', 'etablissement')
    inlines       = [UniteTravailInline, PlanActionInline]


@admin.register(EvaluationRisque)
class EvaluationRisqueAdmin(admin.ModelAdmin):
    list_display  = ('unite_travail', 'source_danger', 'present', 'niveau')
    list_filter   = ('present', 'niveau', 'unite_travail__duerp__etablissement')
    search_fields = ('observation', 'source_danger__description')


@admin.register(PlanActionDUERP)
class PlanActionDUERPAdmin(admin.ModelAdmin):
    list_display  = ('duerp', 'description_action', 'responsable', 'delai', 'avancement')
    list_filter   = ('avancement', 'duerp__etablissement')
    search_fields = ('description_action', 'responsable')


# ─────────────────────────────────────────────
#  MODULE ACCESSIBILITÉ
# ─────────────────────────────────────────────

class EvaluationZoneInline(admin.TabularInline):
    model  = EvaluationZone
    extra  = 0
    fields = ('zone', 'statut_moteur', 'statut_visuel', 'statut_auditif', 'statut_mental', 'observation')


class FormationInline(admin.TabularInline):
    model  = FormationPersonnel
    extra  = 1
    fields = ('type_formation', 'intitule', 'date_formation', 'nb_personnes')


class PieceAdminInline(admin.TabularInline):
    model  = PieceAdministrative
    extra  = 1
    fields = ('type_piece', 'intitule', 'date_document', 'fichier')


class ActionConformiteInline(admin.TabularInline):
    model  = ActionMiseConformite
    extra  = 0
    fields = ('description', 'responsable', 'delai_prevu', 'avancement', 'ticket')


@admin.register(RegistreAccessibilite)
class RegistreAccessibiliteAdmin(admin.ModelAdmin):
    list_display  = ('etablissement', 'statut', 'date_mise_a_jour')
    list_filter   = ('statut',)
    search_fields = ('etablissement__nom',)
    inlines       = [EvaluationZoneInline, FormationInline, PieceAdminInline, ActionConformiteInline]


# ─────────────────────────────────────────────
#  DROITS DE SIGNATURE
# ─────────────────────────────────────────────

class DroitSignatureInline(admin.TabularInline):
    model  = DroitSignature
    extra  = 1
    fields = ('etablissement', 'document')


@admin.register(DroitSignature)
class DroitSignatureAdmin(admin.ModelAdmin):
    list_display  = ('utilisateur', 'etablissement', 'get_document_display')
    list_filter   = ('document', 'etablissement')
    search_fields = ('utilisateur__first_name', 'utilisateur__last_name')

    def get_document_display(self, obj):
        return obj.get_document_display()
    get_document_display.short_description = 'Document'


# ─────────────────────────────────────────────
#  PERSONNALISATION DU SITE ADMIN
# ─────────────────────────────────────────────

admin.site.site_header = "Registre de securite PSM2S"
admin.site.site_title  = "Registre Securite"
admin.site.index_title = "Tableau de bord administration"
from django import forms
from django.contrib.auth.models import Group
from .models import (
    TicketTravaux, Etablissement, Batiment, Document, ControleEtablissement,
    TypeControle, Intervention, RealisationControle, PieceJointeTicket,
    Periodicite, Contrat, VisiteCommission, Prescription, ActionPrescription,
    ReseauEau, PointPrelevement, AnalyseEau,
)
from django.contrib.auth import get_user_model
import datetime


class RealisationControleForm(forms.ModelForm):
    class Meta:
        model = RealisationControle
        fields = ['date_realisation', 'statut', 'organisme', 'remarques', 'document', 'nom_document']
        widgets = {
            'date_realisation': forms.DateInput(format='%Y-%m-%d', attrs={
                'class': 'form-input',
                'type': 'date',
            }),
            'statut': forms.Select(attrs={
                'class': 'form-select',
            }),
            'organisme': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Ex : SOCOTEC, Apave, prestataire interne…',
            }),
            'remarques': forms.Textarea(attrs={
                'class': 'form-input',
                'rows': 3,
                'placeholder': 'Observations, réserves, recommandations…',
            }),
            'document': forms.FileInput(attrs={
                'class': 'form-input',
            }),
            'nom_document': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Ex : Rapport SOCOTEC extincteurs 2026',
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['date_realisation'].initial = datetime.date.today()
        self.fields['statut'].initial = 'fait'
        self.fields['document'].required = False
        self.fields['nom_document'].required = False


class TicketTravauxForm(forms.ModelForm):
    class Meta:
        model = TicketTravaux
        fields = [
            'etablissement',
            'titre',
            'priorite',
            'statut',
            'date_cible',
            'responsable',
        ]
        widgets = {
            'etablissement': forms.Select(attrs={
                'class': 'form-select',
            }),
            'titre': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Décrivez brièvement le travail à réaliser…',
            }),
            'priorite': forms.Select(attrs={
                'class': 'form-select',
            }),
            'statut': forms.Select(attrs={
                'class': 'form-select',
            }),
            'date_cible': forms.DateInput(format='%Y-%m-%d', attrs={
                'class': 'form-input',
                'type': 'date',
            }),
            'responsable': forms.Select(attrs={
                'class': 'form-select',
            }),
        }
        labels = {
            'etablissement': 'Établissement',
            'titre': 'Intitulé du ticket',
            'priorite': 'Priorité',
            'statut': 'Statut initial',
            'date_cible': 'Date cible (optionnel)',
            'responsable': 'Chargé de travaux (optionnel)',
        }

    def __init__(self, *args, **kwargs):
        etab_pk = kwargs.pop('etab_pk', None)
        super().__init__(*args, **kwargs)
        # Champs non obligatoires
        self.fields['date_cible'].required = False
        self.fields['responsable'].required = False
        # Filtre établissements actifs seulement
        self.fields['etablissement'].queryset = Etablissement.objects.filter(actif=True).order_by('nom')
        # Pré-sélection établissement si fourni
        if etab_pk:
            try:
                self.fields['etablissement'].initial = etab_pk
            except Exception:
                pass


class DocumentForm(forms.ModelForm):
    class Meta:
        model = Document
        fields = ['controle', 'type_doc', 'nom_fichier', 'fichier']
        widgets = {
            'controle': forms.Select(attrs={'class': 'form-select'}),
            'type_doc': forms.Select(attrs={'class': 'form-select'}),
            'nom_fichier': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Ex : Rapport vérification électrique 2024…',
            }),
            'fichier': forms.ClearableFileInput(attrs={'class': 'form-input'}),
        }
        labels = {
            'controle': 'Contrôle associé',
            'type_doc': 'Type de document',
            'nom_fichier': 'Nom du document',
            'fichier': 'Fichier (PDF, Word…)',
        }

    def __init__(self, *args, **kwargs):
        etab_pk = kwargs.pop('etab_pk', None)
        super().__init__(*args, **kwargs)
        if etab_pk:
            self.fields['controle'].queryset = (
                ControleEtablissement.objects
                .filter(etablissement__pk=etab_pk)
                .select_related('type_controle')
                .order_by('type_controle__categorie', 'type_controle__nom')
            )


class ControleEtablissementForm(forms.ModelForm):
    class Meta:
        model = ControleEtablissement
        fields = ['type_controle', 'batiment', 'statut', 'priorite', 'date_realisation', 'prochaine_echeance', 'remarques_responsable', 'remarques_direction']
        widgets = {
            'type_controle':        forms.Select(attrs={'class': 'form-select'}),
            'batiment':             forms.Select(attrs={'class': 'form-select'}),
            'statut':               forms.Select(attrs={'class': 'form-select'}),
            'priorite':             forms.Select(attrs={'class': 'form-select'}),
            'date_realisation':     forms.DateInput(format='%Y-%m-%d', attrs={'class': 'form-input', 'type': 'date'}),
            'prochaine_echeance':   forms.DateInput(format='%Y-%m-%d', attrs={'class': 'form-input', 'type': 'date'}),
            'remarques_responsable': forms.Textarea(attrs={'class': 'form-input', 'rows': 2}),
            'remarques_direction':   forms.Textarea(attrs={'class': 'form-input', 'rows': 2}),
        }
        labels = {
            'type_controle':        'Type de contrôle',
            'batiment':             'Bâtiment concerné (optionnel)',
            'statut':               'Statut',
            'priorite':             'Priorité',
            'date_realisation':     'Date de dernière réalisation',
            'prochaine_echeance':   'Prochaine échéance',
            'remarques_responsable': 'Remarques responsable sécurité',
            'remarques_direction':   'Commentaire direction',
        }

    def __init__(self, *args, **kwargs):
        etab_pk = kwargs.pop('etab_pk', None)
        super().__init__(*args, **kwargs)
        self.fields['date_realisation'].required = False
        self.fields['prochaine_echeance'].required = False
        self.fields['priorite'].required = False
        self.fields['batiment'].required = False
        self.fields['remarques_responsable'].required = False
        self.fields['remarques_direction'].required = False
        # Filtrer les bâtiments de l'établissement courant
        if etab_pk:
            self.fields['batiment'].queryset = Batiment.objects.filter(
                etablissement_id=etab_pk, actif=True
            ).order_by('nom')
        else:
            self.fields['batiment'].queryset = Batiment.objects.none()
        self.fields['batiment'].empty_label = '— Établissement entier —'


class EtablissementForm(forms.ModelForm):
    class Meta:
        model = Etablissement
        fields = ['nom', 'code', 'adresse', 'ville', 'type_erp', 'categorie',
                  'contact_nom', 'contact_telephone', 'contact_email', 'actif']
        widgets = {
            'nom':               forms.TextInput(attrs={'class': 'form-input'}),
            'code':              forms.TextInput(attrs={'class': 'form-input'}),
            'adresse':           forms.TextInput(attrs={'class': 'form-input'}),
            'ville':             forms.TextInput(attrs={'class': 'form-input'}),
            'type_erp':          forms.Select(attrs={'class': 'form-select'}),
            'categorie':         forms.Select(attrs={'class': 'form-select'}),
            'contact_nom':       forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : Marie Dupont'}),
            'contact_telephone': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : 06 12 34 56 78'}),
            'contact_email':     forms.EmailInput(attrs={'class': 'form-input', 'placeholder': 'Ex : m.dupont@adpep28.fr'}),
            'actif':             forms.CheckboxInput(),
        }
        labels = {
            'nom':               "Nom de l'établissement",
            'code':              'Code court',
            'adresse':           'Adresse',
            'ville':             'Ville',
            'type_erp':          'Type ERP',
            'categorie':         'Catégorie',
            'contact_nom':       'Contact sur place',
            'contact_telephone': 'Téléphone',
            'contact_email':     'Email du contact',
            'actif':             'Établissement actif',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for f in ['adresse', 'ville', 'type_erp', 'categorie',
                  'contact_nom', 'contact_telephone', 'contact_email']:
            if f in self.fields:
                self.fields[f].required = False


# ── Formulaire Groupe ──────────────────────────────────────────────────────
class GroupeForm(forms.ModelForm):
    class Meta:
        model = Group
        fields = ['name']
        widgets = {'name': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : Chargé de sécurité…'})}
        labels = {'name': 'Nom du groupe'}


# ── Formulaire Utilisateur ─────────────────────────────────────────────────
class UtilisateurForm(forms.ModelForm):
    password1 = forms.CharField(
        label='Mot de passe', required=False,
        widget=forms.PasswordInput(attrs={'class': 'form-input', 'autocomplete': 'new-password'}),
        help_text='Laisser vide pour conserver le mot de passe actuel (modification uniquement).'
    )
    password2 = forms.CharField(
        label='Confirmer le mot de passe', required=False,
        widget=forms.PasswordInput(attrs={'class': 'form-input'})
    )

    class Meta:
        model = get_user_model()
        fields = ['username', 'first_name', 'last_name', 'email', 'role', 'groups', 'is_active']
        widgets = {
            'username':   forms.TextInput(attrs={'class': 'form-input'}),
            'first_name': forms.TextInput(attrs={'class': 'form-input'}),
            'last_name':  forms.TextInput(attrs={'class': 'form-input'}),
            'email':      forms.EmailInput(attrs={'class': 'form-input'}),
            'role':       forms.Select(attrs={'class': 'form-select'}),
            'groups':     forms.CheckboxSelectMultiple(),
            'is_active':  forms.CheckboxInput(),
        }
        labels = {
            'username':   'Identifiant de connexion',
            'first_name': 'Prénom',
            'last_name':  'Nom',
            'email':      'Adresse e-mail',
            'role':       'Rôle',
            'groups':     'Groupes',
            'is_active':  'Compte actif',
        }

    def __init__(self, *args, **kwargs):
        directeur = kwargs.pop('directeur', False)
        super().__init__(*args, **kwargs)
        for f in ['first_name', 'last_name', 'groups']:
            if f in self.fields:
                self.fields[f].required = False
        if 'role' in self.fields:
            self.fields['role'].required = False
            if directeur:
                # Un directeur ne peut créer/modifier que des factotums et prestataires
                self.fields['role'].choices = [
                    ('factotum', 'Factotum'),
                    ('prestataire', 'Prestataire'),
                ]

    def clean(self):
        cleaned = super().clean()
        p1 = cleaned.get('password1')
        p2 = cleaned.get('password2')
        if p1 or p2:
            if p1 != p2:
                raise forms.ValidationError('Les mots de passe ne correspondent pas.')
        return cleaned

    def save(self, commit=True):
        user = super().save(commit=False)
        p1 = self.cleaned_data.get('password1')
        if p1:
            user.set_password(p1)
        # Tous les utilisateurs PSM2S doivent pouvoir se connecter via /admin/login/
        user.is_staff = True
        if commit:
            user.save()
            self.save_m2m()
        return user


# ── Formulaire Intervention (création) ───────────────────────────────────
class InterventionForm(forms.ModelForm):
    class Meta:
        model = Intervention
        fields = ['ticket', 'date_intervention', 'prestataire', 'realise_en_interne',
                  'description', 'statut', 'montant']
        widgets = {
            'ticket':            forms.Select(attrs={'class': 'form-select'}),
            'date_intervention': forms.DateInput(format='%Y-%m-%d', attrs={'class': 'form-input', 'type': 'date'}),
            'prestataire':       forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : EUROFEU, SOCOTEC…'}),
            'realise_en_interne':forms.CheckboxInput(),
            'description':       forms.Textarea(attrs={'class': 'form-input', 'rows': 3, 'placeholder': 'Description des travaux…'}),
            'statut':            forms.Select(attrs={'class': 'form-select'}),
            'montant':           forms.NumberInput(attrs={'class': 'form-input', 'step': '0.01', 'placeholder': '0.00'}),
        }
        labels = {
            'ticket':            'Ticket concerné',
            'date_intervention': "Date d'intervention",
            'prestataire':       'Prestataire',
            'realise_en_interne':'Réalisé en interne (factotum)',
            'description':       'Description des travaux',
            'statut':            'Statut',
            'montant':           'Montant (€)',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['prestataire'].required = False
        self.fields['montant'].required = False
        self.fields['ticket'].queryset = TicketTravaux.objects.exclude(
            statut='cloture'
        ).select_related('etablissement').order_by('etablissement__nom', '-date_creation')


# ── Formulaire Intervention (modification) ───────────────────────────────
class InterventionEditForm(forms.ModelForm):
    """Formulaire de modification sans le champ ticket (déjà fixé à la création)."""
    class Meta:
        model = Intervention
        fields = ['date_intervention', 'prestataire', 'realise_en_interne',
                  'description', 'statut', 'montant']
        widgets = {
            'date_intervention': forms.DateInput(format='%Y-%m-%d', attrs={'class': 'form-input', 'type': 'date'}),
            'prestataire':       forms.TextInput(attrs={'class': 'form-input'}),
            'realise_en_interne':forms.CheckboxInput(),
            'description':       forms.Textarea(attrs={'class': 'form-input', 'rows': 3}),
            'statut':            forms.Select(attrs={'class': 'form-select'}),
            'montant':           forms.NumberInput(attrs={'class': 'form-input', 'step': '0.01'}),
        }
        labels = {
            'date_intervention': "Date d'intervention",
            'prestataire':       'Prestataire',
            'realise_en_interne':'Réalisé en interne',
            'description':       'Description des travaux',
            'statut':            'Statut',
            'montant':           'Montant (€)',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['prestataire'].required = False
        self.fields['montant'].required = False


# ── Formulaire Type de contrôle ────────────────────────────────────────────
class TypeControleForm(forms.ModelForm):
    class Meta:
        model = TypeControle
        fields = ['nom', 'categorie', 'periodicite', 'description'] if hasattr(TypeControle, 'description') else ['nom', 'categorie', 'periodicite']
        widgets = {
            'nom':         forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : Vérification électrique…'}),
            'categorie':   forms.Select(attrs={'class': 'form-select'}),
            'periodicite': forms.Select(attrs={'class': 'form-select'}),
        }
        labels = {
            'nom':         'Nom du contrôle',
            'categorie':   'Catégorie',
            'periodicite': 'Périodicité',
            'description': 'Description (optionnel)',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if 'description' in self.fields:
            self.fields['description'].required = False
            self.fields['description'].widget = forms.Textarea(attrs={'class': 'form-input', 'rows': 3})
        # Limiter aux périodicités actives, triées par nb_jours
        if 'periodicite' in self.fields:
            self.fields['periodicite'].queryset = Periodicite.objects.filter(actif=True).order_by('nb_jours')
            self.fields['periodicite'].required = False
            self.fields['periodicite'].empty_label = '— Sélectionner une périodicité —'


# ── Formulaire Périodicité ─────────────────────────────────────────────────
class PeriodiciteForm(forms.ModelForm):
    class Meta:
        model = Periodicite
        fields = ['code', 'libelle', 'nb_jours', 'actif']
        widgets = {
            'code':     forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Ex : bimensuel',
            }),
            'libelle':  forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Ex : Bimensuel (tous les 2 mois)',
            }),
            'nb_jours': forms.NumberInput(attrs={
                'class': 'form-input',
                'min': '0',
                'placeholder': 'Ex : 60',
            }),
            'actif':    forms.CheckboxInput(),
        }
        labels = {
            'code':     'Code interne (slug)',
            'libelle':  'Libellé affiché',
            'nb_jours': 'Nombre de jours (0 = ponctuel)',
            'actif':    'Actif',
        }
        help_texts = {
            'nb_jours': 'Utilisé pour calculer automatiquement la prochaine échéance. Mettre 0 pour les contrôles ponctuels.',
        }


# ── Formulaire Contrat prestataire ────────────────────────────────────────
class ContratForm(forms.ModelForm):
    class Meta:
        model = Contrat
        fields = ['type_controle', 'prestataire', 'numero', 'date_debut', 'date_fin', 'montant', 'document', 'notes']
        widgets = {
            'type_controle': forms.Select(attrs={'class': 'form-select'}),
            'prestataire':   forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : SOCOTEC, EUROFEU…'}),
            'numero':        forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : CT-2024-0042'}),
            'date_debut':    forms.DateInput(format='%Y-%m-%d', attrs={'class': 'form-input', 'type': 'date'}),
            'date_fin':      forms.DateInput(format='%Y-%m-%d', attrs={'class': 'form-input', 'type': 'date'}),
            'montant':       forms.NumberInput(attrs={'class': 'form-input', 'placeholder': 'Ex : 1200.00', 'step': '0.01'}),
            'document':      forms.ClearableFileInput(attrs={'class': 'form-input'}),
            'notes':         forms.Textarea(attrs={'class': 'form-input', 'rows': 2}),
        }
        labels = {
            'type_controle': 'Type de contrôle concerné',
            'prestataire':   'Prestataire',
            'numero':        'Numéro de contrat',
            'date_debut':    'Date de début',
            'date_fin':      'Date de fin / échéance',
            'montant':       'Montant annuel (€)',
            'document':      'Document PDF',
            'notes':         'Notes',
        }

    def __init__(self, *args, etab_pk=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['type_controle'].required = False
        self.fields['numero'].required = False
        self.fields['date_debut'].required = False
        self.fields['date_fin'].required = False
        self.fields['montant'].required = False
        self.fields['document'].required = False
        self.fields['notes'].required = False
        if etab_pk:
            # Limiter les types de contrôle à ceux déjà rattachés à l'établissement
            self.fields['type_controle'].queryset = TypeControle.objects.filter(
                controles__etablissement_id=etab_pk
            ).distinct().order_by('categorie', 'nom')



# ── Formulaires Commission de sécurité ────────────────────────────────────

class VisiteCommissionForm(forms.ModelForm):
    class Meta:
        model = VisiteCommission
        fields = ['date_visite', 'date_pv', 'document_pv', 'observations']
        widgets = {
            'date_visite':   forms.DateInput(format='%Y-%m-%d', attrs={'class': 'form-input', 'type': 'date'}),
            'date_pv':       forms.DateInput(format='%Y-%m-%d', attrs={'class': 'form-input', 'type': 'date'}),
            'document_pv':   forms.ClearableFileInput(attrs={'class': 'form-input'}),
            'observations':  forms.Textarea(attrs={'class': 'form-input', 'rows': 2}),
        }
        labels = {
            'date_visite':  'Date de la visite',
            'date_pv':      'Date de réception du PV',
            'document_pv':  'PV de la commission (PDF)',
            'observations': 'Observations générales',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['date_pv'].required = False
        self.fields['document_pv'].required = False
        self.fields['observations'].required = False


class PrescriptionForm(forms.ModelForm):
    class Meta:
        model = Prescription
        fields = ['numero', 'description', 'delai', 'statut', 'ticket']
        widgets = {
            'numero':      forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : 1, 2a, 3…'}),
            'description': forms.Textarea(attrs={'class': 'form-input', 'rows': 3}),
            'delai':       forms.DateInput(format='%Y-%m-%d', attrs={'class': 'form-input', 'type': 'date'}),
            'statut':      forms.Select(attrs={'class': 'form-select'}),
            'ticket':      forms.Select(attrs={'class': 'form-select'}),
        }
        labels = {
            'numero':      'N° prescription',
            'description': 'Description de la non-conformité',
            'delai':       'Délai imposé',
            'statut':      'Statut',
            'ticket':      'Ticket travaux associé (optionnel)',
        }

    def __init__(self, *args, etab_pk=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['numero'].required = False
        self.fields['delai'].required = False
        self.fields['ticket'].required = False
        if etab_pk:
            self.fields['ticket'].queryset = TicketTravaux.objects.filter(
                etablissement_id=etab_pk
            ).order_by('-date_creation')
        else:
            self.fields['ticket'].queryset = TicketTravaux.objects.none()


class ActionPrescriptionForm(forms.ModelForm):
    class Meta:
        model = ActionPrescription
        fields = ['type_action', 'date', 'note', 'document']
        widgets = {
            'type_action': forms.Select(attrs={'class': 'form-select'}),
            'date':        forms.DateInput(format='%Y-%m-%d', attrs={'class': 'form-input', 'type': 'date'}),
            'note':        forms.Textarea(attrs={'class': 'form-input', 'rows': 2}),
            'document':    forms.ClearableFileInput(attrs={'class': 'form-input'}),
        }
        labels = {
            'type_action': "Type d'action",
            'date':        'Date',
            'note':        'Note / détail',
            'document':    'Document joint (facture, photo, devis…)',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['note'].required = False
        self.fields['document'].required = False


class PieceJointeTicketForm(forms.ModelForm):
    class Meta:
        model = PieceJointeTicket
        fields = ['type_piece', 'nom_fichier', 'fichier', 'note']
        widgets = {
            'type_piece':  forms.Select(attrs={'class': 'form-select'}),
            'nom_fichier': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : Devis plomberie 2026'}),
            'fichier':     forms.ClearableFileInput(attrs={'class': 'form-input'}),
            'note':        forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Note optionnelle'}),
        }
        labels = {
            'type_piece':  'Type',
            'nom_fichier': 'Nom du fichier',
            'fichier':     'Fichier',
            'note':        'Note',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['nom_fichier'].required = False
        self.fields['note'].required = False


# ── Formulaires Carnet sanitaire eau ──────────────────────────────────────

class ReseauEauForm(forms.ModelForm):
    class Meta:
        model = ReseauEau
        fields = ['type_reseau', 'description', 'actif']
        widgets = {
            'type_reseau':  forms.Select(attrs={'class': 'form-select'}),
            'description':  forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : Reseau ECS batiment principal'}),
            'actif':        forms.CheckboxInput(),
        }
        labels = {
            'type_reseau': 'Type de reseau',
            'description': 'Description',
            'actif':       'Actif',
        }


class PointPrelevementForm(forms.ModelForm):
    class Meta:
        model = PointPrelevement
        fields = ['nom', 'localisation']
        widgets = {
            'nom':          forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : Douche RDC, Robinet cuisine'}),
            'localisation': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : Couloir RDC aile ouest'}),
        }
        labels = {
            'nom':          'Nom du point',
            'localisation': 'Localisation',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['localisation'].required = False


class AnalyseEauForm(forms.ModelForm):
    class Meta:
        model = AnalyseEau
        fields = ['point', 'date_analyse', 'parametre', 'valeur', 'observations', 'laboratoire', 'document']
        widgets = {
            'point':        forms.Select(attrs={'class': 'form-select'}),
            'date_analyse': forms.DateInput(format='%Y-%m-%d', attrs={'class': 'form-input', 'type': 'date'}),
            'parametre':    forms.Select(attrs={'class': 'form-select'}),
            'valeur':       forms.NumberInput(attrs={'class': 'form-input', 'step': '0.001', 'placeholder': '0.00'}),
            'observations': forms.Textarea(attrs={'class': 'form-input', 'rows': 2}),
            'laboratoire':  forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ex : Eurofins, Veolia...'}),
            'document':     forms.ClearableFileInput(attrs={'class': 'form-input'}),
        }
        labels = {
            'point':        'Point de prelevement',
            'date_analyse': 'Date',
            'parametre':    'Parametre analyse',
            'valeur':       'Valeur mesuree',
            'observations': 'Observations',
            'laboratoire':  'Laboratoire / Prestataire',
            'document':     'Rapport (PDF)',
        }

    def __init__(self, *args, etab_pk=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['observations'].required = False
        self.fields['laboratoire'].required = False
        self.fields['document'].required = False
        if etab_pk:
            self.fields['point'].queryset = PointPrelevement.objects.filter(
                reseau__etablissement_id=etab_pk, actif=True
            ).select_related('reseau').order_by('reseau__type_reseau', 'nom')

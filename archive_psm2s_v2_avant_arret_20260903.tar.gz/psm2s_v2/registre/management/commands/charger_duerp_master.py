"""
Commande Django : charger_duerp_master
Pré-remplit les tables CategorieRisque et SourceDanger
à partir des documents DUERP de référence (Guillaume / NLR).

Usage :
    python manage.py charger_duerp_master
    python manage.py charger_duerp_master --reset   (efface et recharge)
"""

from django.core.management.base import BaseCommand
from registre.models import CategorieRisque, SourceDanger


# ─────────────────────────────────────────────────────────────────────
#  DONNÉES MASTER – extraites des 9 documents DUERP de référence
#  Structure : { 'type_unite': [ ('Catégorie', [ ('Source', 'Risque'), ... ]) ] }
# ─────────────────────────────────────────────────────────────────────

MASTER_DATA = {

    # ── TERTIAIRE / BUREAUTIQUE ──────────────────────────────────────
    'tertiaire_bureautique': [
        ('Implantation et aménagement du poste de travail', [
            ('Mobilier inadapté à la morphologie (chaise, bureau)', 'Troubles musculo-squelettiques / troubles visuels / fatigue'),
            ('Position de l\'écran inadaptée (axe, hauteur, profondeur)', 'Troubles musculo-squelettiques / troubles visuels'),
            ('Pas d\'appui pour les poignets et avant-bras', 'Troubles musculo-squelettiques'),
            ('Taille de l\'écran inadaptée au travail', 'Troubles visuels / fatigue'),
            ('Souris éloignée du clavier', 'Troubles musculo-squelettiques'),
            ('Manque de matériel spécifique (porte-document, tapis de souris…)', 'Troubles musculo-squelettiques'),
        ]),
        ('Postures', [
            ('Travail statique prolongé, peu de déplacements', 'Troubles musculo-squelettiques / troubles veineux'),
            ('Mauvaise position des membres inférieurs (jambes croisées, dans le vide)', 'Troubles musculo-squelettiques'),
            ('Mauvaise conception du poste (encombrement sous le bureau)', 'Troubles musculo-squelettiques'),
        ]),
        ('Contraintes visuelles', [
            ('Travail prolongé sur écran (absence de pause visuelle)', 'Troubles visuels / maux de tête / syndrome de l\'oeil sec'),
            ('Zones de reflets et/ou zones éblouissantes', 'Troubles visuels'),
            ('Éclairage insuffisant ou inadapté', 'Troubles visuels / fatigue'),
        ]),
        ('Accès au poste de travail', [
            ('Présence de fils électriques dans le passage', 'Chute de plain-pied / heurt'),
            ('Encombrement du poste de travail', 'Chute de plain-pied / heurt'),
            ('Sol inégal ou irrégulier', 'Chute de plain-pied'),
        ]),
        ('Déplacements', [
            ('Déplacements routiers et/ou à pied', 'Accident de la route / accident de la voie publique'),
            ('Circulation d\'engins', 'Collision / écrasement'),
            ('Zone commune piétons / véhicules', 'Collision / heurt / chute'),
            ('Sol glissant (eau, verglas, feuilles…)', 'Chute de plain-pied'),
        ]),
        ('Divers', [
            ('Port de charges (cartons de fournitures, archives)', 'Dorsalgie'),
            ('Utilisation d\'outils (ciseaux, cutters)', 'Coupure / brûlure'),
            ('Utilisation de dispositifs mobiles (marche-pied, escabeau)', 'Chute de personne'),
            ('Produits chimiques (produits d\'entretien)', 'Irritation / brûlure / intoxication'),
        ]),
        ('Risques psychosociaux', [
            ('Facteurs liés à la tâche', 'Stress chronique / fatigue / troubles du sommeil'),
            ('L\'organisation du travail', 'Stress chronique'),
            ('Relations de travail', 'Stress chronique / conflit'),
            ('L\'environnement physique', 'Inconfort / stress'),
        ]),
        ('Risque d\'agression', [
            ('Contact avec le public', 'Agression verbale / agression physique'),
            ('Présence d\'argent liquide ou d\'objets convoités', 'Agression / vol'),
            ('Absence de dispositif de protection / dissuasion', 'Agression'),
        ]),
        ('Organisation des secours', [
            ('Absence de trousse de secours', 'Retard dans les secours'),
            ('Numéros d\'urgence non affichés / pas de plan d\'évacuation', 'Difficulté en cas d\'urgence'),
            ('Absence de Sauveteurs Secouristes du Travail', 'Retard dans les secours'),
        ]),
    ],

    # ── MAINTENANCE & ENTRETIEN ──────────────────────────────────────
    'maintenance_entretien': [
        ('Circulation des piétons', [
            ('Zone commune piétons / véhicules (livraison, parking)', 'Collision / heurt / chute de plain-pied'),
            ('Sol glissant (eau, huile, verglas, feuilles)', 'Chute de plain-pied'),
            ('Sol inégal ou irrégulier (escaliers, trous, bosses)', 'Chute de plain-pied'),
            ('Manque d\'éclairage (intérieur, extérieur)', 'Chute / heurt'),
            ('Passages encombrés / parties saillantes', 'Heurt / chute'),
        ]),
        ('Déplacements routiers', [
            ('Trajets effectués de nuit', 'Accident de la route'),
            ('Utilisation de téléphones portables au volant', 'Accident de la route'),
            ('Pas de dispositif d\'arrimage des charges', 'Chute de charge / accident'),
            ('Manque d\'entretien des véhicules', 'Accident de la route'),
        ]),
        ('Travail en hauteur', [
            ('Absence de protection anti-chute fixe (garde-corps, rampe)', 'Chute de personne'),
            ('Utilisation de dispositif mobile (échafaudage, escabeau, échelle)', 'Chute de personne'),
            ('Dispositif mobile en mauvais état ou non adapté', 'Chute de personne'),
            ('Pas d\'équipement de protection individuelle (casque, harnais)', 'Chute de personne'),
        ]),
        ('Postures et manutentions', [
            ('Port de charges lourdes', 'Dorsalgie / troubles musculo-squelettiques'),
            ('Charges difficiles à manutentionner', 'Dorsalgie / écrasement'),
            ('Gestes répétitifs', 'Troubles musculo-squelettiques'),
            ('Position prolongée (debout, à genoux)', 'Troubles musculo-squelettiques'),
        ]),
        ('Utilisation de machines et outils', [
            ('Utilisation de machines (scie, perceuse…)', 'Coupure / écrasement / projection'),
            ('Utilisation d\'outils manuels', 'Coupure / contusion'),
            ('Équipements non vérifiés périodiquement', 'Accident / blessure'),
        ]),
        ('Risques chimiques', [
            ('Utilisation de produits d\'entretien / chimiques', 'Irritation / brûlure / intoxication'),
            ('Absence de fiche de données de sécurité', 'Intoxication'),
            ('Pas d\'EPI adapté (gants, lunettes, masque)', 'Brûlure / intoxication'),
        ]),
        ('Risques électriques', [
            ('Intervention sur installation électrique', 'Électrisation / brûlure'),
            ('Absence de vérification périodique de l\'installation', 'Électrisation'),
            ('Branchements multiples sur une même prise', 'Court-circuit / incendie'),
        ]),
    ],

    # ── INTERNAT ─────────────────────────────────────────────────────
    'internat': [
        ('Circulation des piétons', [
            ('Zone commune piétons / véhicules (livraison, parking)', 'Collision / heurt / chute de plain-pied'),
            ('Sol glissant (escalier extérieur, verglas, feuilles)', 'Chute de plain-pied'),
            ('Sol inégal ou irrégulier (trous, bosses)', 'Chute de plain-pied'),
            ('Manque d\'éclairage (intérieur, extérieur)', 'Chute / heurt'),
        ]),
        ('Déplacements routiers', [
            ('Déplacements avec des enfants / usagers', 'Accident de la route'),
            ('Destinations éloignées (transfert, formation)', 'Accident de la route / fatigue'),
            ('Contraintes horaires importantes (tôt / tard)', 'Fatigue / accident'),
        ]),
        ('Manutention des usagers', [
            ('Aide à la mobilité des usagers (transferts, lever)', 'Dorsalgie / troubles musculo-squelettiques'),
            ('Comportements difficiles des usagers', 'Agression / blessure'),
            ('Absence d\'aide technique à la manutention', 'Dorsalgie'),
        ]),
        ('Risques psychosociaux', [
            ('Charge émotionnelle liée à l\'accompagnement des usagers', 'Épuisement professionnel / burn-out'),
            ('Horaires atypiques (nuit, week-end)', 'Fatigue / stress'),
            ('Travail isolé la nuit', 'Agression / absence de secours'),
        ]),
        ('Incendie / sécurité nocturne', [
            ('Exercice incendie nocturne (1 fois/an)', 'Accident lors de l\'exercice'),
            ('Présence de personnes vulnérables (usagers)', 'Difficultés d\'évacuation'),
        ]),
    ],

    # ── PÉDAGOGIQUE ──────────────────────────────────────────────────
    'pedagogique': [
        ('Circulation des piétons', [
            ('Zone commune piétons / véhicules', 'Collision / heurt / chute'),
            ('Passages encombrés (cartables, matériel)', 'Chute / heurt'),
            ('Sol inégal (trous sur cour, escaliers)', 'Chute de plain-pied'),
        ]),
        ('Déplacements routiers', [
            ('Déplacements avec des jeunes (examens, inclusion, sorties)', 'Accident de la route'),
            ('Contraintes horaires (rencontres partenaires, familles)', 'Fatigue / accident'),
        ]),
        ('Postures et manutentions', [
            ('Position debout prolongée (enseignement)', 'Troubles musculo-squelettiques / troubles veineux'),
            ('Port de charges (matériel pédagogique)', 'Dorsalgie'),
        ]),
        ('Risques psychosociaux', [
            ('Gestion des comportements difficiles des élèves', 'Épuisement professionnel / agression'),
            ('Charge de travail (préparation, administratif)', 'Stress chronique'),
            ('Relations avec les familles', 'Stress / conflit'),
        ]),
        ('Risque d\'agression', [
            ('Contact avec des usagers au comportement difficile', 'Agression verbale / physique'),
            ('Absence de formation à la gestion des conflits', 'Agression'),
        ]),
    ],

    # ── THÉRAPEUTIQUE ────────────────────────────────────────────────
    'therapeutique': [
        ('Circulation des piétons', [
            ('Zone commune piétons / véhicules', 'Collision / heurt / chute'),
            ('Sol glissant (mousse, cour)', 'Chute de plain-pied'),
            ('Escaliers dangereux (marches étroites, portillon bas)', 'Chute de personne'),
            ('Manque d\'éclairage (salle sombre)', 'Fatigue visuelle / chute'),
        ]),
        ('Déplacements routiers', [
            ('Déplacements fréquents (0 à 500 km/semaine)', 'Accident de la route / fatigue'),
            ('Amplitudes horaires importantes / multi-sites', 'Fatigue / accident'),
        ]),
        ('Manutention / postures', [
            ('Porter les enfants blessés ou au comportement difficile', 'Dorsalgie / blessure'),
            ('Position assise prolongée (secrétaire médicale)', 'Troubles musculo-squelettiques'),
            ('Position à genoux / dos courbé (soins, psychomotricité)', 'Troubles musculo-squelettiques'),
        ]),
        ('Utilisation d\'outils de soins', [
            ('Utilisation de ciseaux, aiguilles, scalpels', 'Coupure / perforation / infection'),
            ('Gestion des déchets de soins (DASRI)', 'Infection / piqûre'),
        ]),
        ('Risques biologiques', [
            ('Contact avec des usagers malades', 'Contamination / infection'),
            ('Gestion de la pharmacie / médicaments', 'Erreur médicamenteuse / intoxication'),
        ]),
        ('Stockage en hauteur', [
            ('Archives stockées en hauteur (armoires hautes)', 'Chute d\'objets / chute de personne'),
        ]),
    ],

    # ── ABORDS IMMÉDIATS ─────────────────────────────────────────────
    'abords_immediats': [
        ('Circulation des véhicules', [
            ('Circulation et manœuvre de poids lourds', 'Collision / écrasement'),
            ('Voies de circulation communes (VL, PL, piétons)', 'Collision'),
            ('Manque de signalisation', 'Collision / confusion'),
            ('Éclairage insuffisant (entrée, parking)', 'Collision / chute nocturne'),
            ('Pas de limitation de vitesse à l\'intérieur du site', 'Collision'),
        ]),
        ('Circulation des piétons', [
            ('Zone commune piétons / véhicules (manœuvres PL)', 'Collision / écrasement / chute'),
            ('Présence de trous, bosses ou aspérités (cour, marches)', 'Chute de plain-pied'),
            ('Absence de garde-corps sur quais ou rampes', 'Chute de personne'),
        ]),
        ('Stockage extérieur', [
            ('Stockage d\'éléments en hauteur à l\'extérieur', 'Chute d\'objet / heurt'),
            ('Passages encombrés, parties saillantes', 'Heurt / chute'),
        ]),
    ],

    # ── RISQUE INCENDIE ──────────────────────────────────────────────
    'incendie': [
        ('Conception des bâtiments', [
            ('Absence de mur coupe-feu / compartimentage', 'Propagation rapide de l\'incendie'),
            ('Porte coupe-feu maintenue ouverte', 'Propagation rapide de l\'incendie'),
        ]),
        ('Évacuation', [
            ('Issue de secours inexistante ou bloquée', 'Difficulté d\'évacuation'),
            ('Voies de dégagement encombrées', 'Difficulté d\'évacuation / perte de temps'),
            ('Absence de bloc autonome d\'éclairage de sécurité (BAES)', 'Évacuation dans le noir'),
            ('Pas de point de rassemblement défini', 'Confusion lors de l\'évacuation'),
        ]),
        ('Équipements de lutte contre l\'incendie', [
            ('Absence d\'extincteur ou non contrôlé annuellement', 'Propagation de l\'incendie'),
            ('Absence de moyen de désenfumage', 'Intoxication / propagation'),
            ('Matériel non ou difficilement accessible', 'Retard d\'intervention'),
        ]),
        ('Formation incendie', [
            ('Pas de formation à l\'utilisation des extincteurs', 'Mauvaise gestion du sinistre'),
            ('Absence de guide ou serre-file', 'Difficulté d\'évacuation'),
            ('Exercices d\'évacuation incendie non réalisés', 'Comportement inadapté en cas d\'incendie'),
        ]),
        ('Présence de matières inflammables', [
            ('Matériaux combustibles (archives, bois, plastiques)', 'Développement rapide de l\'incendie'),
            ('Liquides inflammables (hydrocarbures, solvants)', 'Incendie / explosion'),
            ('Gaz inflammables sous pression (acétylène, butane)', 'Explosion / incendie'),
            ('Absence de confinement des produits inflammables', 'Propagation de l\'incendie'),
        ]),
        ('Sources d\'ignition', [
            ('Opérations par points chauds (soudure, meulage)', 'Départ d\'incendie'),
            ('Énergie électrique / accumulation électrostatique', 'Départ d\'incendie'),
            ('Flammes vives', 'Départ d\'incendie'),
        ]),
        ('Signalisation de sécurité', [
            ('Manque de signalisation du matériel incendie', 'Retard d\'intervention'),
            ('Issues de secours non signalées', 'Difficulté d\'évacuation'),
            ('Pas de plan d\'évacuation affiché', 'Confusion lors de l\'évacuation'),
        ]),
        ('Alarme et alerte', [
            ('Absence de détection automatique incendie', 'Retard d\'alerte / propagation'),
            ('Pas d\'alarme sonore dans les locaux', 'Retard d\'évacuation'),
            ('Coordination insuffisante entre bâtiments', 'Confusion / absence d\'alerte'),
        ]),
    ],

    # ── COVID-19 / RISQUE BIOLOGIQUE ─────────────────────────────────
    'covid': [
        ('Risques liés aux agents biologiques', [
            ('Contact direct rapproché et/ou prolongé entre individus', 'Contamination / propagation'),
            ('Contact direct éloigné et bref entre individus', 'Contamination'),
            ('Contact avec une personne présentant des symptômes', 'Contamination'),
            ('Absence de gestes barrières affichés', 'Propagation'),
            ('Absence de solution hydro-alcoolique à disposition', 'Contamination'),
            ('Locaux non aérés régulièrement', 'Contamination / propagation'),
            ('Absence d\'EPI adaptés aux tâches (masque, gants, surblouse)', 'Contamination'),
        ]),
    ],
}


class Command(BaseCommand):
    help = 'Pré-remplit les tables CategorieRisque et SourceDanger pour le module DUERP'

    def add_arguments(self, parser):
        parser.add_argument(
            '--reset',
            action='store_true',
            help='Efface toutes les données existantes avant de recharger',
        )

    def handle(self, *args, **options):
        if options['reset']:
            SourceDanger.objects.all().delete()
            CategorieRisque.objects.all().delete()
            self.stdout.write(self.style.WARNING('Données existantes effacées.'))

        total_cat = 0
        total_src = 0

        for type_unite, categories in MASTER_DATA.items():
            for ordre_cat, (nom_cat, sources) in enumerate(categories):
                cat, created = CategorieRisque.objects.get_or_create(
                    type_unite=type_unite,
                    nom=nom_cat,
                    defaults={'ordre': ordre_cat}
                )
                if created:
                    total_cat += 1

                for ordre_src, (description, risque) in enumerate(sources):
                    _, created = SourceDanger.objects.get_or_create(
                        categorie=cat,
                        description=description,
                        defaults={
                            'risque_potentiel': risque,
                            'ordre': ordre_src,
                        }
                    )
                    if created:
                        total_src += 1

        self.stdout.write(self.style.SUCCESS(
            f'Terminé : {total_cat} catégories et {total_src} sources de danger créées.'
        ))

"""
Commande Django : envoyer_alertes
==================================
Envoie des emails d'alerte aux responsables pour les contrôles dont l'échéance approche.

Seuils d'alerte :
  J-30  → "À planifier dans le mois"
  J-7   → "Urgent — à organiser cette semaine"
  J0+   → "En retard — échéance dépassée"

Utilisation manuelle :
  python manage.py envoyer_alertes
  python manage.py envoyer_alertes --dry-run   (simulation sans envoi)

Cron O2switch (chaque matin à 7h) :
  0 7 * * * /home/<user>/psm2s_securite/venv/bin/python /home/<user>/psm2s_securite/manage.py envoyer_alertes >> /home/<user>/psm2s_securite/logs/alertes.log 2>&1
"""

from django.core.management.base import BaseCommand
from django.core.mail import send_mail, EmailMultiAlternatives
from django.utils import timezone
from django.conf import settings
from django.template.loader import render_to_string

from registre.models import ControleEtablissement, Utilisateur, EtablissementUtilisateur

import datetime
import logging

logger = logging.getLogger(__name__)


# Délais d'alerte en jours avant l'échéance
SEUILS = [
    (30, 'J-30',  'À planifier',  '#D97706'),  # orange
    (7,  'J-7',   'Urgent',       '#DC2626'),  # rouge
    (0,  'J0',    'En retard',    '#991B1B'),  # rouge foncé
]


class Command(BaseCommand):
    help = "Envoie les emails d'alerte pour les contrôles dont l'échéance approche (J-30, J-7, J0)"

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help="Simule l'envoi sans envoyer réellement les emails",
        )

    def handle(self, *args, **options):
        dry_run = options['dry_run']
        aujourd_hui = timezone.now().date()

        self.stdout.write(f"\n{'='*60}")
        self.stdout.write(f"PSM2S — Alertes échéances — {aujourd_hui}")
        if dry_run:
            self.stdout.write(self.style.WARNING("  MODE DRY-RUN — aucun email ne sera envoyé"))
        self.stdout.write(f"{'='*60}\n")

        # Récupérer tous les contrôles avec une échéance définie
        # et dont le statut nécessite une alerte
        statuts_a_alerter = ('a_faire', 'a_remettre_a_jour', 'en_cours')
        controles = ControleEtablissement.objects.filter(
            prochaine_echeance__isnull=False,
            statut__in=statuts_a_alerter,
        ).select_related('etablissement', 'type_controle')

        if not controles.exists():
            self.stdout.write("Aucun contrôle avec échéance à vérifier.")
            return

        # Construire un dictionnaire : destinataire → liste d'alertes
        # Structure : {email: {nom_complet, etablissements: {etab_code: [alertes]}}}
        alertes_par_destinataire = {}

        for controle in controles:
            echeance = controle.prochaine_echeance
            delta = (echeance - aujourd_hui).days

            # Déterminer le niveau d'alerte
            niveau = None
            for jours, code, label, couleur in SEUILS:
                if jours == 0:
                    # J0 : échéance aujourd'hui ou dépassée
                    if delta <= 0:
                        niveau = (code, label, couleur, delta)
                        break
                else:
                    # J-X : exactement ce jour-là pour éviter les doublons
                    if delta == jours:
                        niveau = (code, label, couleur, delta)
                        break

            if niveau is None:
                continue

            code_alerte, label_alerte, couleur_alerte, jours_restants = niveau

            # Trouver les destinataires pour cet établissement
            destinataires = self._get_destinataires(controle.etablissement)

            if not destinataires:
                self.stdout.write(
                    self.style.WARNING(
                        f"  ⚠  Aucun destinataire pour {controle.etablissement.code} "
                        f"({controle.type_controle.nom})"
                    )
                )
                continue

            alerte_info = {
                'controle': controle,
                'echeance': echeance,
                'jours_restants': jours_restants,
                'code_alerte': code_alerte,
                'label_alerte': label_alerte,
                'couleur_alerte': couleur_alerte,
            }

            for user in destinataires:
                if not user.email:
                    continue
                if user.email not in alertes_par_destinataire:
                    alertes_par_destinataire[user.email] = {
                        'user': user,
                        'alertes': [],
                    }
                alertes_par_destinataire[user.email]['alertes'].append(alerte_info)

        if not alertes_par_destinataire:
            self.stdout.write("Aucune alerte à envoyer aujourd'hui.")
            return

        # Envoyer un email récapitulatif par destinataire
        total_envoyes = 0
        total_erreurs = 0

        for email, data in alertes_par_destinataire.items():
            user = data['user']
            alertes = data['alertes']

            # Trier par urgence (J0 en premier, puis J-7, puis J-30)
            alertes_triees = sorted(alertes, key=lambda a: a['jours_restants'])

            nb_retard   = sum(1 for a in alertes_triees if a['jours_restants'] <= 0)
            nb_urgent   = sum(1 for a in alertes_triees if 1 <= a['jours_restants'] <= 7)
            nb_planifier = sum(1 for a in alertes_triees if a['jours_restants'] > 7)

            sujet = self._construire_sujet(nb_retard, nb_urgent, nb_planifier)

            contexte = {
                'user': user,
                'alertes': alertes_triees,
                'nb_retard': nb_retard,
                'nb_urgent': nb_urgent,
                'nb_planifier': nb_planifier,
                'aujourd_hui': aujourd_hui,
                'base_url': getattr(settings, 'BASE_URL', 'https://psm2s.pbci-conseils.fr'),
            }

            self.stdout.write(
                f"  → {email} : {len(alertes)} alerte(s) "
                f"[{nb_retard} retard / {nb_urgent} urgent / {nb_planifier} à planifier]"
            )
            self.stdout.write(f"     Objet : {sujet}")

            if not dry_run:
                try:
                    html_content = render_to_string('registre/emails/alerte_echeance.html', contexte)
                    text_content = render_to_string('registre/emails/alerte_echeance.txt', contexte)

                    msg = EmailMultiAlternatives(
                        subject=sujet,
                        body=text_content,
                        from_email=settings.DEFAULT_FROM_EMAIL,
                        to=[email],
                    )
                    msg.attach_alternative(html_content, "text/html")
                    msg.send()
                    total_envoyes += 1
                    self.stdout.write(self.style.SUCCESS(f"     ✓ Envoyé"))
                except Exception as e:
                    total_erreurs += 1
                    self.stdout.write(self.style.ERROR(f"     ✗ Erreur : {e}"))
                    logger.error(f"Erreur envoi alerte à {email} : {e}")
            else:
                self.stdout.write(self.style.WARNING(f"     [dry-run] Non envoyé"))

        self.stdout.write(f"\n{'='*60}")
        if dry_run:
            self.stdout.write(f"Simulation terminée — {len(alertes_par_destinataire)} email(s) auraient été envoyés")
        else:
            self.stdout.write(
                f"Terminé — {total_envoyes} envoyé(s) / {total_erreurs} erreur(s)"
            )
        self.stdout.write(f"{'='*60}\n")

    def _get_destinataires(self, etablissement):
        """
        Retourne la liste des utilisateurs à alerter pour un établissement.
        Priorité : responsables_securite et directeurs rattachés à l'établissement.
        Si aucun rattachement, on prend tous les admin/responsables globaux.
        """
        # Utilisateurs rattachés à cet établissement avec un rôle de gestionnaire
        rattaches = Utilisateur.objects.filter(
            etablissements__etablissement=etablissement,
            role__in=('admin', 'responsable_securite', 'directeur'),
            is_active=True,
        ).distinct()

        if rattaches.exists():
            return list(rattaches)

        # Fallback : tous les responsables et admins actifs
        return list(Utilisateur.objects.filter(
            role__in=('admin', 'responsable_securite'),
            is_active=True,
        ))

    def _construire_sujet(self, nb_retard, nb_urgent, nb_planifier):
        """Construit un objet d'email clair selon le niveau d'urgence."""
        if nb_retard > 0:
            return f"🔴 PSM2S — {nb_retard} contrôle(s) EN RETARD à traiter d'urgence"
        elif nb_urgent > 0:
            return f"🟠 PSM2S — {nb_urgent} contrôle(s) urgent(s) cette semaine"
        else:
            return f"🔵 PSM2S — {nb_planifier} contrôle(s) à planifier dans le mois"

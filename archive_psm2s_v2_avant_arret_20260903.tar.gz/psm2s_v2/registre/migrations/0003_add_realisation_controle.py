from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('registre', '0002_etablissement_contact_email_and_more'),
    ]

    operations = [
        migrations.CreateModel(
            name='RealisationControle',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('annee', models.IntegerField(verbose_name='Année')),
                ('date_realisation', models.DateField(verbose_name='Date de réalisation')),
                ('statut', models.CharField(
                    choices=[
                        ('fait', '✅ Fait'),
                        ('a_remettre_a_jour', '🔄 À remettre à jour'),
                        ('a_faire', "⚠️ À faire"),
                        ('pas_obligation', "➖ Pas d'obligation réglementaire"),
                        ('non_concerne', '— Non concerné'),
                    ],
                    default='fait',
                    max_length=30,
                    verbose_name='Statut'
                )),
                ('organisme', models.CharField(blank=True, max_length=200, verbose_name='Organisme / Prestataire')),
                ('remarques', models.TextField(blank=True, verbose_name='Remarques / Observations')),
                ('document', models.FileField(blank=True, null=True, upload_to='realisations/%Y/%m/', verbose_name='Rapport / Justificatif')),
                ('nom_document', models.CharField(blank=True, max_length=255, verbose_name='Nom du document')),
                ('date_saisie', models.DateTimeField(auto_now_add=True)),
                ('controle', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='realisations',
                    to='registre.ControleEtablissement'
                )),
                ('saisie_par', models.ForeignKey(
                    blank=True,
                    null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='realisations_saisies',
                    to=settings.AUTH_USER_MODEL
                )),
            ],
            options={
                'verbose_name': 'Réalisation de contrôle',
                'verbose_name_plural': 'Réalisations de contrôles',
                'ordering': ['-annee', '-date_realisation'],
            },
        ),
        migrations.AddIndex(
            model_name='realisationcontrole',
            index=models.Index(fields=['controle', 'annee'], name='registre_re_control_idx'),
        ),
        migrations.AddIndex(
            model_name='realisationcontrole',
            index=models.Index(fields=['annee'], name='registre_re_annee_idx'),
        ),
    ]

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('registre', '0003_add_realisation_controle'),
    ]

    operations = [
        migrations.CreateModel(
            name='PieceJointeTicket',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nom_fichier', models.CharField(max_length=255, verbose_name='Nom du fichier')),
                ('fichier', models.FileField(upload_to='tickets/%Y/%m/', verbose_name='Fichier')),
                ('type_piece', models.CharField(
                    choices=[
                        ('devis', 'Devis'),
                        ('facture', 'Facture'),
                        ('photo', 'Photo avant/après'),
                        ('rapport', 'Rapport'),
                        ('autre', 'Autre'),
                    ],
                    default='autre', max_length=20, verbose_name='Type'
                )),
                ('note', models.CharField(blank=True, max_length=500, verbose_name='Note')),
                ('date_depot', models.DateTimeField(auto_now_add=True)),
                ('ticket', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='pieces_jointes',
                    to='registre.tickettravaux'
                )),
                ('depose_par', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='pieces_jointes_deposees',
                    to=settings.AUTH_USER_MODEL
                )),
            ],
            options={
                'verbose_name': 'Pièce jointe ticket',
                'verbose_name_plural': 'Pièces jointes tickets',
                'ordering': ['-date_depot'],
            },
        ),
    ]

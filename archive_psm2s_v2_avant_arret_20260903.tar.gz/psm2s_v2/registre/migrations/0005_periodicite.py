"""
Migration 0005 : Création du modèle Periodicite + données initiales
(les 7 valeurs qui étaient dans PERIODICITE_CHOICES).
"""
from django.db import migrations, models


PERIODICITES_INITIALES = [
    # (code, libelle, nb_jours)
    ('mensuel',        'Mensuel',                    30),
    ('semestriel',     'Semestriel',                180),
    ('annuel',         'Annuel',                    365),
    ('triennal',       'Tous les 3 ans',           1095),
    ('quinquennal',    'Tous les 5 ans',           1825),
    ('annee_scolaire', 'Année scolaire (2 fois/an)', 180),
    ('ponctuel',       'Ponctuel / À la demande',     0),
]


def inserer_periodicites(apps, schema_editor):
    Periodicite = apps.get_model('registre', 'Periodicite')
    for code, libelle, nb_jours in PERIODICITES_INITIALES:
        Periodicite.objects.get_or_create(
            code=code,
            defaults={'libelle': libelle, 'nb_jours': nb_jours, 'actif': True},
        )


def supprimer_periodicites(apps, schema_editor):
    Periodicite = apps.get_model('registre', 'Periodicite')
    Periodicite.objects.filter(code__in=[c for c, *_ in PERIODICITES_INITIALES]).delete()


class Migration(migrations.Migration):

    dependencies = [
        ('registre', '0004_add_piecejointe_ticket'),
    ]

    operations = [
        migrations.CreateModel(
            name='Periodicite',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code',     models.SlugField(max_length=50, unique=True, verbose_name='Code interne')),
                ('libelle',  models.CharField(max_length=100, verbose_name='Libellé affiché')),
                ('nb_jours', models.PositiveIntegerField(default=365, verbose_name='Nombre de jours entre deux réalisations')),
                ('actif',    models.BooleanField(default=True, verbose_name='Actif')),
            ],
            options={
                'verbose_name': 'Périodicité',
                'verbose_name_plural': 'Périodicités',
                'ordering': ['nb_jours'],
            },
        ),
        migrations.RunPython(inserer_periodicites, supprimer_periodicites),
    ]

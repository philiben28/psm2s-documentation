"""
Migration 0006 : Remplace TypeControle.periodicite (CharField) par une FK vers Periodicite.

Stratégie en 3 temps :
  1. Ajouter la colonne FK nullable (periodicite_fk_id)
  2. Data migration : copier la valeur de l'ancien CharField vers la FK
  3. Supprimer l'ancien CharField, renommer la FK en periodicite_id
"""
from django.db import migrations, models
import django.db.models.deletion


def copier_vers_fk(apps, schema_editor):
    TypeControle = apps.get_model('registre', 'TypeControle')
    Periodicite  = apps.get_model('registre', 'Periodicite')

    periodicites = {p.code: p for p in Periodicite.objects.all()}
    annuel = periodicites.get('annuel')  # valeur par défaut si code inconnu

    for tc in TypeControle.objects.all():
        old_code = tc.periodicite_ancien or 'annuel'
        tc.periodicite_fk = periodicites.get(old_code, annuel)
        tc.save(update_fields=['periodicite_fk'])


def retour_vers_char(apps, schema_editor):
    TypeControle = apps.get_model('registre', 'TypeControle')
    for tc in TypeControle.objects.select_related('periodicite_fk').all():
        if tc.periodicite_fk:
            tc.periodicite_ancien = tc.periodicite_fk.code
            tc.save(update_fields=['periodicite_ancien'])


class Migration(migrations.Migration):

    dependencies = [
        ('registre', '0005_periodicite'),
    ]

    operations = [
        # 1. Renommer l'ancien champ CharField pour libérer le nom 'periodicite'
        migrations.RenameField(
            model_name='typecontrole',
            old_name='periodicite',
            new_name='periodicite_ancien',
        ),

        # 2. Ajouter la nouvelle FK (temporairement nommée periodicite_fk)
        migrations.AddField(
            model_name='typecontrole',
            name='periodicite_fk',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='types_controle',
                to='registre.periodicite',
                verbose_name='Périodicité',
            ),
        ),

        # 3. Copier les données
        migrations.RunPython(copier_vers_fk, retour_vers_char),

        # 4. Supprimer l'ancien CharField
        migrations.RemoveField(
            model_name='typecontrole',
            name='periodicite_ancien',
        ),

        # 5. Renommer la FK vers son nom final
        migrations.RenameField(
            model_name='typecontrole',
            old_name='periodicite_fk',
            new_name='periodicite',
        ),
    ]

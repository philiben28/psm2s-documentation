from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('registre', '0006_typecontrole_periodicite_fk'),
    ]

    operations = [
        migrations.CreateModel(
            name='Contrat',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('prestataire',   models.CharField(max_length=200, verbose_name='Prestataire')),
                ('numero',        models.CharField(blank=True, max_length=100, verbose_name='Numéro de contrat')),
                ('date_debut',    models.DateField(blank=True, null=True, verbose_name='Date de début')),
                ('date_fin',      models.DateField(blank=True, null=True, verbose_name='Date de fin / échéance')),
                ('montant',       models.DecimalField(blank=True, decimal_places=2, max_digits=10, null=True, verbose_name='Montant annuel (€)')),
                ('document',      models.FileField(blank=True, null=True, upload_to='contrats/%Y/', verbose_name='Document PDF du contrat')),
                ('notes',         models.TextField(blank=True, verbose_name='Notes')),
                ('date_creation', models.DateTimeField(auto_now_add=True)),
                ('date_maj',      models.DateTimeField(auto_now=True)),
                ('etablissement', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='contrats',
                    to='registre.etablissement',
                    verbose_name='Établissement',
                )),
                ('type_controle', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='contrats',
                    to='registre.typecontrole',
                    verbose_name='Type de contrôle',
                )),
                ('cree_par', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='contrats_crees',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={
                'verbose_name': 'Contrat prestataire',
                'verbose_name_plural': 'Contrats prestataires',
                'ordering': ['etablissement', 'prestataire'],
            },
        ),
    ]

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('registre', '0007_contrat'),
    ]

    operations = [
        # ── VisiteCommission ──────────────────────────────────────────────
        migrations.CreateModel(
            name='VisiteCommission',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date_visite',   models.DateField(verbose_name='Date de la visite')),
                ('date_pv',       models.DateField(blank=True, null=True, verbose_name='Date de réception du PV')),
                ('document_pv',   models.FileField(blank=True, null=True, upload_to='commissions/%Y/', verbose_name='PV de la commission (PDF)')),
                ('observations',  models.TextField(blank=True, verbose_name='Observations générales')),
                ('date_creation', models.DateTimeField(auto_now_add=True)),
                ('etablissement', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='visites_commission',
                    to='registre.etablissement',
                    verbose_name='Établissement',
                )),
                ('cree_par', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='visites_creees',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={
                'verbose_name': 'Visite de commission',
                'verbose_name_plural': 'Visites de commission',
                'ordering': ['-date_visite'],
            },
        ),

        # ── Prescription ──────────────────────────────────────────────────
        migrations.CreateModel(
            name='Prescription',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('numero',        models.CharField(blank=True, max_length=20, verbose_name='N° prescription')),
                ('description',   models.TextField(verbose_name='Description de la non-conformité')),
                ('delai',         models.DateField(blank=True, null=True, verbose_name='Délai imposé par la commission')),
                ('statut',        models.CharField(
                    choices=[
                        ('en_cours', '🔄 En cours de traitement'),
                        ('levee',    '✅ Levée'),
                        ('reportee', '🔴 Reportée au prochain PV'),
                    ],
                    default='en_cours', max_length=20, verbose_name='Statut',
                )),
                ('date_creation', models.DateTimeField(auto_now_add=True)),
                ('date_maj',      models.DateTimeField(auto_now=True)),
                ('visite', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='prescriptions',
                    to='registre.visitecommission',
                    verbose_name='Visite',
                )),
                ('ticket', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='prescriptions',
                    to='registre.tickettravaux',
                )),
            ],
            options={
                'verbose_name': 'Prescription',
                'verbose_name_plural': 'Prescriptions',
                'ordering': ['numero', 'date_creation'],
            },
        ),

        # ── ActionPrescription ────────────────────────────────────────────
        migrations.CreateModel(
            name='ActionPrescription',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('type_action', models.CharField(
                    choices=[
                        ('devis_demande',    '📨 Demande de devis envoyée'),
                        ('devis_recu',       '📄 Devis reçu'),
                        ('rdv_artisan',      '🗓️ Rendez-vous artisan'),
                        ('travaux_realises', '🔧 Travaux réalisés'),
                        ('justificatif',     '📎 Justificatif joint'),
                        ('autre',            '💬 Autre'),
                    ],
                    default='autre', max_length=30, verbose_name="Type d'action",
                )),
                ('date',        models.DateField(verbose_name='Date')),
                ('note',        models.TextField(blank=True, verbose_name='Note / détail')),
                ('document',    models.FileField(blank=True, null=True, upload_to='prescriptions/%Y/', verbose_name='Document (facture, photo, devis…)')),
                ('date_saisie', models.DateTimeField(auto_now_add=True)),
                ('prescription', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='actions',
                    to='registre.prescription',
                    verbose_name='Prescription',
                )),
                ('saisie_par', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='actions_prescriptions',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={
                'verbose_name': 'Action sur prescription',
                'verbose_name_plural': 'Actions sur prescriptions',
                'ordering': ['-date'],
            },
        ),
    ]

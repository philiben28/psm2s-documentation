from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('registre', '0008_commission'),
    ]

    operations = [
        # ── ReseauEau ─────────────────────────────────────────────────────
        migrations.CreateModel(
            name='ReseauEau',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('type_reseau',   models.CharField(max_length=10, choices=[('ecs', 'Eau Chaude Sanitaire (ECS)'), ('ef', 'Eau Froide')], verbose_name='Type de reseau')),
                ('description',   models.CharField(blank=True, max_length=200, verbose_name='Description complementaire')),
                ('actif',         models.BooleanField(default=True, verbose_name='Actif')),
                ('date_creation', models.DateTimeField(auto_now_add=True)),
                ('etablissement', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='reseaux_eau',
                    to='registre.etablissement',
                    verbose_name='Etablissement',
                )),
            ],
            options={
                'verbose_name': "Reseau d'eau",
                'verbose_name_plural': "Reseaux d'eau",
                'ordering': ['etablissement', 'type_reseau'],
                'unique_together': {('etablissement', 'type_reseau')},
            },
        ),

        # ── PointPrelevement ──────────────────────────────────────────────
        migrations.CreateModel(
            name='PointPrelevement',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nom',          models.CharField(max_length=200, verbose_name='Nom du point')),
                ('localisation', models.CharField(blank=True, max_length=200, verbose_name='Localisation')),
                ('actif',        models.BooleanField(default=True, verbose_name='Actif')),
                ('reseau', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='points',
                    to='registre.reseaueau',
                    verbose_name='Reseau',
                )),
            ],
            options={
                'verbose_name': 'Point de prelevement',
                'verbose_name_plural': 'Points de prelevement',
                'ordering': ['reseau', 'nom'],
            },
        ),

        # ── AnalyseEau ────────────────────────────────────────────────────
        migrations.CreateModel(
            name='AnalyseEau',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date_analyse', models.DateField(verbose_name="Date de l'analyse")),
                ('parametre',    models.CharField(max_length=20, choices=[
                    ('temperature',  'Temperature (degC)'),
                    ('chlore_libre', 'Chlore libre (mg/L)'),
                    ('chlore_total', 'Chlore total (mg/L)'),
                    ('ph',           'pH'),
                    ('legionelles',  'Legionelles (UFC/L)'),
                    ('autre',        'Autre'),
                ], verbose_name='Parametre')),
                ('valeur',       models.DecimalField(max_digits=12, decimal_places=3, verbose_name='Valeur mesuree')),
                ('unite',        models.CharField(blank=True, max_length=20, verbose_name='Unite')),
                ('statut',       models.CharField(blank=True, max_length=20, choices=[
                    ('conforme',     'Conforme'),
                    ('vigilance',    'Vigilance'),
                    ('non_conforme', 'Non conforme'),
                ], verbose_name='Statut')),
                ('observations', models.TextField(blank=True, verbose_name='Observations')),
                ('laboratoire',  models.CharField(blank=True, max_length=200, verbose_name='Laboratoire / Prestataire')),
                ('document',     models.FileField(blank=True, null=True, upload_to='analyses_eau/%Y/', verbose_name="Rapport d'analyse")),
                ('date_saisie',  models.DateTimeField(auto_now_add=True)),
                ('point', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='analyses',
                    to='registre.pointprelevement',
                    verbose_name='Point de prelevement',
                )),
                ('saisie_par', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='analyses_saisies',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={
                'verbose_name': "Analyse d'eau",
                'verbose_name_plural': "Analyses d'eau",
                'ordering': ['-date_analyse', 'parametre'],
            },
        ),
    ]

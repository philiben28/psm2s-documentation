# Migration 0010 - Module DUERP
# Document Unique d'Evaluation des Risques Professionnels

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('registre', '0009_carnet_eau'),
    ]

    operations = [
        migrations.CreateModel(
            name='CategorieRisque',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('type_unite', models.CharField(choices=[('tertiaire_bureautique', 'Tertiaire / Bureautique'), ('maintenance_entretien', 'Maintenance & Entretien'), ('internat', 'Internat'), ('pedagogique', 'Pedagogique'), ('therapeutique', 'Therapeutique'), ('abords_immediats', 'Abords immediats'), ('incendie', 'Risque Incendie'), ('covid', 'COVID-19 / Risque biologique'), ('autre', 'Autre')], max_length=30, verbose_name="Type d'unite")),
                ('nom', models.CharField(max_length=200, verbose_name='Categorie')),
                ('ordre', models.PositiveSmallIntegerField(default=0)),
            ],
            options={
                'verbose_name': 'Categorie de risque',
                'verbose_name_plural': 'Categories de risque',
                'ordering': ['type_unite', 'ordre'],
            },
        ),
        migrations.CreateModel(
            name='DUERP',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('annee', models.PositiveIntegerField(verbose_name='Annee')),
                ('date_creation', models.DateField(auto_now_add=True)),
                ('date_validation', models.DateField(blank=True, null=True, verbose_name='Date de validation')),
                ('signataire', models.CharField(blank=True, max_length=200, verbose_name='Signataire')),
                ('statut', models.CharField(choices=[('brouillon', 'Brouillon'), ('valide', 'Valide'), ('archive', 'Archive')], default='brouillon', max_length=20)),
                ('observations_generales', models.TextField(blank=True, verbose_name='Observations generales')),
                ('etablissement', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='duerp_set', to='registre.etablissement', verbose_name='Etablissement')),
            ],
            options={
                'verbose_name': 'DUERP',
                'verbose_name_plural': 'DUERP',
                'ordering': ['-annee'],
                'unique_together': {('etablissement', 'annee')},
            },
        ),
        migrations.CreateModel(
            name='SourceDanger',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('description', models.CharField(max_length=500, verbose_name='Source de danger')),
                ('risque_potentiel', models.CharField(blank=True, max_length=300, verbose_name='Risque potentiel type')),
                ('ordre', models.PositiveSmallIntegerField(default=0)),
                ('categorie', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='sources_danger', to='registre.categorierisque')),
            ],
            options={
                'verbose_name': 'Source de danger',
                'verbose_name_plural': 'Sources de danger',
                'ordering': ['categorie', 'ordre'],
            },
        ),
        migrations.CreateModel(
            name='UniteTravail',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('type_unite', models.CharField(choices=[('tertiaire_bureautique', 'Tertiaire / Bureautique'), ('maintenance_entretien', 'Maintenance & Entretien'), ('internat', 'Internat'), ('pedagogique', 'Pedagogique'), ('therapeutique', 'Therapeutique'), ('abords_immediats', 'Abords immediats'), ('incendie', 'Risque Incendie'), ('covid', 'COVID-19 / Risque biologique'), ('autre', 'Autre')], max_length=30, verbose_name='Type')),
                ('nom_custom', models.CharField(blank=True, max_length=200, verbose_name='Nom personnalise')),
                ('ordre', models.PositiveSmallIntegerField(default=0)),
                ('duerp', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='unites_travail', to='registre.duerp')),
            ],
            options={
                'verbose_name': 'Unite de travail',
                'verbose_name_plural': 'Unites de travail',
                'ordering': ['ordre', 'type_unite'],
            },
        ),
        migrations.CreateModel(
            name='EvaluationRisque',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('present', models.BooleanField(default=False, verbose_name='Risque present')),
                ('risque_potentiel', models.CharField(blank=True, max_length=300, verbose_name='Risque potentiel')),
                ('niveau', models.CharField(blank=True, choices=[('', '--'), ('tres_faible', 'Tres faible'), ('faible', 'Faible'), ('moyen', 'Moyen'), ('important', 'Important'), ('tres_important', 'Tres important')], max_length=20, verbose_name='Niveau de risque')),
                ('observation', models.TextField(blank=True, verbose_name='Observation')),
                ('source_danger', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='evaluations', to='registre.sourcedanger')),
                ('unite_travail', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='evaluations', to='registre.unitetravail')),
            ],
            options={
                'verbose_name': 'Evaluation de risque',
                'verbose_name_plural': 'Evaluations de risque',
                'ordering': ['source_danger__categorie__ordre', 'source_danger__ordre'],
                'unique_together': {('unite_travail', 'source_danger')},
            },
        ),
        migrations.CreateModel(
            name='PlanActionDUERP',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('description_action', models.TextField(verbose_name='Action a mener')),
                ('responsable', models.CharField(blank=True, max_length=200, verbose_name='Responsable')),
                ('delai', models.DateField(blank=True, null=True, verbose_name='Delai')),
                ('avancement', models.CharField(choices=[('a_faire', 'A faire'), ('en_cours', 'En cours'), ('termine', 'Termine')], default='a_faire', max_length=20)),
                ('date_creation', models.DateTimeField(auto_now_add=True)),
                ('duerp', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='plan_actions', to='registre.duerp')),
                ('evaluation_risque', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='actions', to='registre.evaluationrisque')),
                ('ticket', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='actions_duerp', to='registre.tickettravaux')),
            ],
            options={
                'verbose_name': 'Action DUERP',
                'verbose_name_plural': 'Actions DUERP',
                'ordering': ['delai', 'avancement'],
            },
        ),
    ]

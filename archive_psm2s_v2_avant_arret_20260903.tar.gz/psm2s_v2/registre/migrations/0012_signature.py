from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('registre', '0011_accessibilite'),
    ]

    operations = [
        migrations.AddField(
            model_name='utilisateur',
            name='signature',
            field=models.ImageField(blank=True, null=True, upload_to='signatures/', verbose_name='Signature'),
        ),
    ]

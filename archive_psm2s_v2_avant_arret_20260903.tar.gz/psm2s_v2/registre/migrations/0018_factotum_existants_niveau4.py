"""
Data migration : les factotums déjà en base passent au niveau 4 (accès complet)
afin de ne pas rétrograder des utilisateurs existants lors de l'activation du système.
Les nouveaux factotums créés après cette migration démarrent au niveau 1 (défaut).
"""
from django.db import migrations


def set_factotums_niveau4(apps, schema_editor):
    Utilisateur = apps.get_model('registre', 'Utilisateur')
    Utilisateur.objects.filter(role='factotum').update(niveau_factotum=4)


def revert_factotums(apps, schema_editor):
    Utilisateur = apps.get_model('registre', 'Utilisateur')
    Utilisateur.objects.filter(role='factotum').update(niveau_factotum=1)


class Migration(migrations.Migration):

    dependencies = [
        ('registre', '0017_add_niveau_factotum'),
    ]

    operations = [
        migrations.RunPython(set_factotums_niveau4, revert_factotums),
    ]

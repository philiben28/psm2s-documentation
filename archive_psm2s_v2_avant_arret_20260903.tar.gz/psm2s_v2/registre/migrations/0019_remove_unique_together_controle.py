from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('registre', '0018_factotum_existants_niveau4'),
    ]

    operations = [
        migrations.AlterUniqueTogether(
            name='controleetablissement',
            unique_together=set(),
        ),
    ]

from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
 
 
# ─────────────────────────────────────────────
#  UTILISATEURS ET RÔLES
# ─────────────────────────────────────────────
 
class Utilisateur(AbstractUser):
    """
    Étend le modèle utilisateur Django standard.
    Trois rôles possibles, conformes à votre organisation.
    """
    ROLE_CHOICES = [
        ('admin',                'Administrateur'),
        ('responsable_securite', 'Responsable sécurité'),
        ('directeur',            'Directeur / Directrice'),
        ('factotum',             'Factotum'),
        ('prestataire',          'Prestataire'),
    ]
 
    NIVEAU_FACTOTUM_CHOICES = [
        (1, 'Niveau 1 — Consultation uniquement'),
        (2, 'Niveau 2 — Saisie interventions et tickets'),
        (3, 'Niveau 3 — Signature des interventions'),
        (4, 'Niveau 4 — Accès complet'),
    ]

    role = models.CharField(
        max_length=30,
        choices=ROLE_CHOICES,
        default='factotum',
        verbose_name="Rôle"
    )
    niveau_factotum = models.PositiveSmallIntegerField(
        choices=NIVEAU_FACTOTUM_CHOICES,
        default=1,
        verbose_name="Niveau d'habilitation (factotum uniquement)"
    )
    signature = models.ImageField(
        upload_to='signatures/',
        null=True, blank=True,
        verbose_name="Signature"
    )
    # Un utilisateur peut être rattaché à un ou plusieurs établissements
    # (relation gérée via EtablissementUtilisateur ci-dessous)
 
    class Meta:
        verbose_name = "Utilisateur"
        verbose_name_plural = "Utilisateurs"
 
    def __str__(self):
        return f"{self.get_full_name()} ({self.get_role_display()})"
 
    # Helpers de rôle utilisés dans les vues et templates
    @property
    def est_admin(self):
        return self.role == 'admin' or self.is_superuser

    @property
    def est_responsable(self):
        return self.role in ('admin', 'responsable_securite') or self.is_superuser

    @property
    def est_directeur(self):
        return self.role == 'directeur'

    @property
    def est_factotum(self):
        return self.role == 'factotum'

    @property
    def est_prestataire(self):
        return self.role == 'prestataire'

    @property
    def peut_tout_voir(self):
        """Admin, responsable et directeur voient tous les établissements."""
        return self.role in ('admin', 'responsable_securite', 'directeur') or self.is_superuser

    def peut_voir_etablissement(self, etab):
        """Prestataires ne voient que les établissements où ils ont un ticket confié."""
        if self.peut_tout_voir or self.role == 'factotum':
            return True
        if self.role == 'prestataire':
            # Accès dérivé des tickets : si au moins un ticket de cet établissement
            # lui est confié, il peut voir l'établissement
            from .models import TicketTravaux
            return TicketTravaux.objects.filter(
                etablissement=etab, responsable=self
            ).exists()
        return False
 
 
# ─────────────────────────────────────────────
#  ÉTABLISSEMENTS
# ─────────────────────────────────────────────
 
class Etablissement(models.Model):
    """
    Un site / bâtiment recevant du public.
    Correspond à un onglet de votre tableau de bord Excel.
    Exemples : CDLA, DAME-AF-SEES, CMPP-DREUX…
    """
    TYPE_ERP_CHOICES = [
        ('J', 'Type J – Structures d\'accueil pour personnes âgées/handicapées'),
        ('R', 'Type R – Établissements d\'enseignement'),
        ('U', 'Type U – Établissements de soins'),
        ('W', 'Type W – Administrations, banques, bureaux'),
        ('autre', 'Autre'),
    ]
 
    CATEGORIE_CHOICES = [
        ('1', 'Catégorie 1 (> 1500 personnes)'),
        ('2', 'Catégorie 2 (de 701 à 1500 personnes)'),
        ('3', 'Catégorie 3 (de 301 à 700 personnes)'),
        ('4', 'Catégorie 4 (≤ 300 personnes, sauf cat. 5)'),
        ('5', 'Catégorie 5 – Seuils inférieurs au règlement'),
    ]
 
    nom                      = models.CharField(max_length=200, verbose_name="Nom du site")
    code                     = models.CharField(max_length=50, unique=True, verbose_name="Code court (ex: CDLA)")
    type_erp                 = models.CharField(max_length=10, choices=TYPE_ERP_CHOICES, blank=True, verbose_name="Type ERP")
    categorie                = models.CharField(max_length=5, choices=CATEGORIE_CHOICES, blank=True, verbose_name="Catégorie ERP")
    adresse                  = models.TextField(blank=True, verbose_name="Adresse")
    ville                    = models.CharField(max_length=100, blank=True, verbose_name="Ville")
    obligation_reglementaire = models.BooleanField(default=True, verbose_name="Soumis aux obligations réglementaires ERP")
    note                     = models.TextField(blank=True, verbose_name="Notes générales")
    actif                    = models.BooleanField(default=True, verbose_name="Site actif")
    date_creation            = models.DateTimeField(auto_now_add=True)

    # Contact sur place
    contact_nom      = models.CharField(max_length=200, blank=True, verbose_name="Contact sur place (nom)")
    contact_telephone= models.CharField(max_length=30,  blank=True, verbose_name="Téléphone du contact")
    contact_email    = models.EmailField(blank=True, verbose_name="Email du contact")
 
    class Meta:
        verbose_name = "Établissement"
        verbose_name_plural = "Établissements"
        ordering = ['nom']
 
    def __str__(self):
        return f"{self.code} – {self.nom}"
 
 
class Batiment(models.Model):
    """
    Bâtiment ERP rattaché à un établissement.
    Chaque bâtiment actif possède son propre Registre de Sécurité (art. R.123-51 CCH).
    """
    TYPE_ERP_CHOICES = [
        ('J', 'Type J – Structures d\'accueil pour personnes âgées/handicapées'),
        ('R', 'Type R – Établissements d\'enseignement'),
        ('U', 'Type U – Établissements de soins'),
        ('W', 'Type W – Administrations, banques, bureaux'),
        ('autre', 'Autre'),
    ]

    CATEGORIE_CHOICES = [
        ('1', 'Catégorie 1 (> 1500 personnes)'),
        ('2', 'Catégorie 2 (de 701 à 1500 personnes)'),
        ('3', 'Catégorie 3 (de 301 à 700 personnes)'),
        ('4', 'Catégorie 4 (≤ 300 personnes, sauf cat. 5)'),
        ('5', 'Catégorie 5 – Seuils inférieurs au règlement'),
    ]

    etablissement    = models.ForeignKey(Etablissement, on_delete=models.CASCADE, related_name='batiments')
    nom              = models.CharField(max_length=200, verbose_name="Nom du bâtiment (ex: Bâtiment A, Gymnase)")
    type_erp         = models.CharField(max_length=10, choices=TYPE_ERP_CHOICES, blank=True, verbose_name="Type ERP")
    categorie        = models.CharField(max_length=5, choices=CATEGORIE_CHOICES, blank=True, verbose_name="Catégorie ERP")
    capacite_accueil = models.PositiveIntegerField(null=True, blank=True, verbose_name="Capacité d'accueil (personnes)")
    actif            = models.BooleanField(default=True, verbose_name="Bâtiment actif (registre facturable)")
    date_creation    = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Bâtiment"
        verbose_name_plural = "Bâtiments"
        ordering = ['etablissement', 'nom']

    def __str__(self):
        return f"{self.etablissement.code} – {self.nom}"


class EtablissementUtilisateur(models.Model):
    """
    Rattachement d'un utilisateur à un ou plusieurs établissements.
    Un responsable sécurité peut gérer tous les sites ;
    un directeur ou factotum est rattaché à son site.
    """
    etablissement = models.ForeignKey(Etablissement, on_delete=models.CASCADE, related_name='utilisateurs')
    utilisateur   = models.ForeignKey(Utilisateur,   on_delete=models.CASCADE, related_name='etablissements')
    principal     = models.BooleanField(default=True, verbose_name="Établissement principal")
 
    class Meta:
        verbose_name = "Rattachement utilisateur / site"
        unique_together = ('etablissement', 'utilisateur')
 
    def __str__(self):
        return f"{self.utilisateur} → {self.etablissement.code}"
 
 
# ─────────────────────────────────────────────
#  PÉRIODICITÉS PERSONNALISABLES
# ─────────────────────────────────────────────

class Periodicite(models.Model):
    """
    Périodicités personnalisables — complète la liste standard.
    Exemples : 'Bimensuel', 'Tous les 2 ans', 'Trimestriel'…
    nb_jours est utilisé par le CRON pour calculer les échéances.
    """
    code     = models.SlugField(max_length=50, unique=True, verbose_name="Code interne")
    libelle  = models.CharField(max_length=100, verbose_name="Libellé affiché")
    nb_jours = models.PositiveIntegerField(default=365, verbose_name="Nombre de jours entre deux réalisations")
    actif    = models.BooleanField(default=True, verbose_name="Actif")

    class Meta:
        verbose_name = "Périodicité"
        verbose_name_plural = "Périodicités"
        ordering = ['nb_jours']

    def __str__(self):
        return self.libelle


# ─────────────────────────────────────────────
#  TYPES DE CONTRÔLES
# ─────────────────────────────────────────────

class TypeControle(models.Model):
    """
    Catalogue des ~40 types de contrôles réglementaires.
    Exemples : Extincteurs / entretien, Alarme incendie / entretien,
               Exercices incendie, Formation SST, DUERP…
    """
    CATEGORIE_CHOICES = [
        ('incendie',      'Incendie / SSI'),
        ('electricite',   'Électricité'),
        ('ascenseur',     'Ascenseur / Élévateur'),
        ('gaz',           'Gaz / Chaufferie'),
        ('exercice',      'Exercices (incendie / PPMS)'),
        ('formation',     'Formations du personnel'),
        ('document',      'Documents réglementaires'),
        ('sanitaire',     'Sanitaire / Eau'),
        ('accessibilite', 'Accessibilité'),
        ('autre',         'Autre'),
    ]
 
    nom         = models.CharField(max_length=200, verbose_name="Libellé du contrôle")
    type_action = models.CharField(max_length=100, blank=True, verbose_name="Type d'action (ex: entretien, vérification…)")
    categorie   = models.CharField(max_length=20, choices=CATEGORIE_CHOICES, default='autre', verbose_name="Catégorie")
    periodicite = models.ForeignKey(
        'Periodicite',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name="Périodicité",
        related_name='types_controle',
    )
    obligatoire = models.BooleanField(default=True, verbose_name="Obligatoire réglementairement")
    description = models.TextField(blank=True, verbose_name="Description / texte réglementaire de référence")
 
    class Meta:
        verbose_name = "Type de contrôle"
        verbose_name_plural = "Types de contrôles"
        ordering = ['categorie', 'nom']
 
    def __str__(self):
        return f"{self.nom} ({self.type_action})" if self.type_action else self.nom
 
 
# ─────────────────────────────────────────────
#  REGISTRE : CONTRÔLES PAR ÉTABLISSEMENT
# ─────────────────────────────────────────────
 
class ControleEtablissement(models.Model):
    """
    Cœur du registre de sécurité numérique.
    Croise un établissement et un type de contrôle,
    avec la date de réalisation, le statut et les remarques.
    Correspond exactement aux cellules de votre tableau de bord Excel.
    """
    STATUT_CHOICES = [
        ('fait',              '✅ Fait'),
        ('a_remettre_a_jour', '🔄 À remettre à jour'),
        ('a_faire',           '⚠️ À faire'),
        ('pas_obligation',    '➖ Pas d\'obligation réglementaire'),
        ('non_concerne',      '— Non concerné'),
    ]
 
    PRIORITE_CHOICES = [
        ('critique', '🔴 Critique – Danger immédiat'),
        ('urgent',   '🟠 Urgent – À traiter rapidement'),
        ('normal',   '🟡 Normal'),
        ('faible',   '🟢 Faible'),
    ]
 
    etablissement    = models.ForeignKey(Etablissement, on_delete=models.CASCADE, related_name='controles')
    batiment         = models.ForeignKey('Batiment', on_delete=models.SET_NULL, null=True, blank=True, related_name='controles', verbose_name="Bâtiment concerné")
    type_controle    = models.ForeignKey(TypeControle,  on_delete=models.CASCADE, related_name='controles')
    statut           = models.CharField(max_length=30, choices=STATUT_CHOICES, default='a_faire', verbose_name="Statut")
    date_realisation = models.DateField(null=True, blank=True, verbose_name="Date de réalisation")
    prochaine_echeance = models.DateField(null=True, blank=True, verbose_name="Prochaine échéance")
    priorite         = models.CharField(max_length=10, choices=PRIORITE_CHOICES, default='normal', verbose_name="Priorité")
 
    # Deux niveaux de remarques, comme dans votre Excel
    remarques_responsable = models.TextField(blank=True, verbose_name="Remarques responsable sécurité")
    remarques_direction   = models.TextField(blank=True, verbose_name="État et commentaire de la direction")
 
    # Traçabilité
    mis_a_jour_par  = models.ForeignKey(Utilisateur, null=True, blank=True, on_delete=models.SET_NULL, related_name='controles_mis_a_jour')
    date_mise_a_jour = models.DateTimeField(auto_now=True)
    date_creation    = models.DateTimeField(auto_now_add=True)
 
    class Meta:
        verbose_name = "Contrôle d'établissement"
        verbose_name_plural = "Contrôles d'établissement"
        ordering = ['etablissement', 'type_controle__categorie']
 
    def __str__(self):
        return f"{self.etablissement.code} | {self.type_controle} | {self.get_statut_display()}"
 
    @property
    def est_en_retard(self):
        """Vrai si l'échéance est dépassée et le statut n'est pas 'fait'."""
        if self.prochaine_echeance and self.statut != 'fait':
            return self.prochaine_echeance < timezone.now().date()
        return False
 
    @property
    def necessite_action(self):
        return self.statut in ('a_faire', 'a_remettre_a_jour')
 
 
# ─────────────────────────────────────────────
#  HISTORIQUE ANNUEL DES RÉALISATIONS
# ─────────────────────────────────────────────

class RealisationControle(models.Model):
    """
    Enregistre chaque réalisation d'un contrôle dans le temps.
    Permet l'historique annuel du registre de sécurité :
    - une ligne par fois que le contrôle a été effectué
    - navigation par année dans la fiche établissement
    - le registre PDF peut être généré par année
    """
    controle         = models.ForeignKey(ControleEtablissement, on_delete=models.CASCADE, related_name='realisations')
    annee            = models.IntegerField(verbose_name="Année")
    date_realisation = models.DateField(verbose_name="Date de réalisation")
    statut           = models.CharField(
        max_length=30,
        choices=ControleEtablissement.STATUT_CHOICES,
        default='fait',
        verbose_name="Statut"
    )
    organisme        = models.CharField(max_length=200, blank=True, verbose_name="Organisme / Prestataire")
    remarques        = models.TextField(blank=True, verbose_name="Remarques / Observations")
    document         = models.FileField(upload_to='realisations/%Y/%m/', null=True, blank=True, verbose_name="Rapport / Justificatif")
    nom_document     = models.CharField(max_length=255, blank=True, verbose_name="Nom du document")
    saisie_par       = models.ForeignKey(
        Utilisateur, null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='realisations_saisies'
    )
    date_saisie      = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Réalisation de contrôle"
        verbose_name_plural = "Réalisations de contrôles"
        ordering = ['-annee', '-date_realisation']
        indexes = [
            models.Index(fields=['controle', 'annee']),
            models.Index(fields=['annee']),
        ]

    def __str__(self):
        return f"{self.controle.etablissement.code} | {self.controle.type_controle.nom} | {self.annee}"

    @classmethod
    def annees_disponibles(cls, etablissement):
        """Retourne la liste des années avec au moins une réalisation pour un établissement."""
        return list(
            cls.objects.filter(controle__etablissement=etablissement)
            .values_list('annee', flat=True)
            .distinct()
            .order_by('-annee')
        )


# ─────────────────────────────────────────────
#  DOCUMENTS
# ─────────────────────────────────────────────
 
class Document(models.Model):
    """
    Pièce jointe rattachée à un contrôle :
    rapport PDF, PV, attestation, facture, photo…
    """
    TYPE_DOC_CHOICES = [
        ('rapport',      'Rapport de contrôle'),
        ('pv',           'PV de commission'),
        ('attestation',  'Attestation de travaux'),
        ('facture',      'Facture'),
        ('photo',        'Photo avant/après'),
        ('procedure',    'Procédure'),
        ('plan',         'Plan'),
        ('formation',    'Liste d\'émargement / formation'),
        ('autre',        'Autre'),
    ]
 
    controle     = models.ForeignKey(ControleEtablissement, on_delete=models.CASCADE, related_name='documents')
    nom_fichier  = models.CharField(max_length=255, verbose_name="Nom du fichier")
    fichier      = models.FileField(upload_to='documents/%Y/%m/', verbose_name="Fichier")
    type_doc     = models.CharField(max_length=20, choices=TYPE_DOC_CHOICES, default='rapport', verbose_name="Type de document")
    date_depot   = models.DateTimeField(auto_now_add=True, verbose_name="Date de dépôt")
    depose_par   = models.ForeignKey(Utilisateur, null=True, on_delete=models.SET_NULL, related_name='documents_deposes')
    note         = models.CharField(max_length=500, blank=True, verbose_name="Note")
 
    class Meta:
        verbose_name = "Document"
        verbose_name_plural = "Documents"
        ordering = ['-date_depot']
 
    def __str__(self):
        return f"{self.nom_fichier} ({self.get_type_doc_display()})"
 
 
# ─────────────────────────────────────────────
#  TICKETS TRAVAUX
# ─────────────────────────────────────────────
 
class TicketTravaux(models.Model):
    """
    Généré automatiquement depuis une observation (ControleEtablissement)
    ou manuellement.
    Workflow : À traiter → Devis demandé → Validé → En cours → Contrôle réalisé → Clôturé
    """
    STATUT_CHOICES = [
        ('a_traiter',         '📋 À traiter'),
        ('devis_demande',     '📨 Devis demandé'),
        ('valide',            '✔️ Validé'),
        ('en_cours',          '🔧 En cours'),
        ('controle_realise',  '🔍 Contrôle réalisé'),
        ('cloture',           '✅ Clôturé'),
    ]
 
    PRIORITE_CHOICES = [
        ('critique', '🔴 Critique – Danger immédiat'),
        ('urgent',   '🟠 Urgent'),
        ('normal',   '🟡 Normal'),
        ('faible',   '🟢 Faible'),
    ]
 
    # Liens
    etablissement = models.ForeignKey(Etablissement, on_delete=models.CASCADE, related_name='tickets')
    controle      = models.ForeignKey(ControleEtablissement, null=True, blank=True, on_delete=models.SET_NULL, related_name='tickets')
 
    # Identification
    titre         = models.CharField(max_length=300, verbose_name="Titre")
    description   = models.TextField(verbose_name="Description de l'observation / travaux à réaliser")
    priorite      = models.CharField(max_length=10, choices=PRIORITE_CHOICES, default='normal')
    statut        = models.CharField(max_length=20, choices=STATUT_CHOICES, default='a_traiter')
 
    # Responsabilité et planning
    responsable   = models.ForeignKey(Utilisateur, null=True, blank=True, on_delete=models.SET_NULL, related_name='tickets_responsable')
    date_cible    = models.DateField(null=True, blank=True, verbose_name="Date cible de réalisation")
 
    # Budget
    cout_estime   = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Coût estimé (€)")
    cout_reel     = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Coût réel (€)")
 
    # Traçabilité
    cree_par      = models.ForeignKey(Utilisateur, null=True, on_delete=models.SET_NULL, related_name='tickets_crees')
    date_creation = models.DateTimeField(auto_now_add=True)
    date_cloture  = models.DateTimeField(null=True, blank=True, verbose_name="Date de clôture")
 
    class Meta:
        verbose_name = "Ticket travaux"
        verbose_name_plural = "Tickets travaux"
        ordering = ['-date_creation']
 
    def __str__(self):
        return f"[{self.get_priorite_display()}] {self.etablissement.code} – {self.titre}"
 
    def cloturer(self, utilisateur):
        """Clôture le ticket et met à jour la date."""
        self.statut = 'cloture'
        self.date_cloture = timezone.now()
        self.save()
 
 
# ─────────────────────────────────────────────
#  PIÈCES JOINTES TICKETS
# ─────────────────────────────────────────────

class PieceJointeTicket(models.Model):
    """
    Fichier attaché directement à un ticket travaux.
    Permet de joindre devis, factures, photos avant/après.
    """
    TYPE_CHOICES = [
        ('devis',       'Devis'),
        ('facture',     'Facture'),
        ('photo',       'Photo avant/après'),
        ('rapport',     'Rapport'),
        ('autre',       'Autre'),
    ]

    ticket       = models.ForeignKey(TicketTravaux, on_delete=models.CASCADE, related_name='pieces_jointes')
    nom_fichier  = models.CharField(max_length=255, verbose_name="Nom du fichier")
    fichier      = models.FileField(upload_to='tickets/%Y/%m/', verbose_name="Fichier")
    type_piece   = models.CharField(max_length=20, choices=TYPE_CHOICES, default='autre', verbose_name="Type")
    note         = models.CharField(max_length=500, blank=True, verbose_name="Note")
    date_depot   = models.DateTimeField(auto_now_add=True)
    depose_par   = models.ForeignKey(Utilisateur, null=True, on_delete=models.SET_NULL, related_name='pieces_jointes_deposees')

    class Meta:
        verbose_name = "Pièce jointe ticket"
        verbose_name_plural = "Pièces jointes tickets"
        ordering = ['-date_depot']

    def __str__(self):
        return f"{self.ticket} — {self.nom_fichier}"


# ─────────────────────────────────────────────
#  INTERVENTIONS
# ─────────────────────────────────────────────
 
class Intervention(models.Model):
    """
    Passage d'un prestataire ou d'un factotum sur un ticket.
    Chaque intervention peut avoir ses propres documents (facture, rapport…).
    """
    STATUT_CHOICES = [
        ('planifiee',  '📅 Planifiée'),
        ('realisee',   '✅ Réalisée'),
        ('annulee',    '❌ Annulée'),
    ]
 
    ticket             = models.ForeignKey(TicketTravaux, on_delete=models.CASCADE, related_name='interventions')
    prestataire        = models.CharField(max_length=200, blank=True, verbose_name="Prestataire (ex: EUROFEU, SOCOTEC…)")
    realise_en_interne = models.BooleanField(default=False, verbose_name="Réalisé en interne (factotum)")
    date_intervention  = models.DateField(verbose_name="Date d'intervention")
    description        = models.TextField(verbose_name="Description des travaux réalisés")
    statut             = models.CharField(max_length=15, choices=STATUT_CHOICES, default='planifiee')
    montant            = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Montant (€)")
 
    # Traçabilité
    saisie_par    = models.ForeignKey(Utilisateur, null=True, on_delete=models.SET_NULL, related_name='interventions_saisies')
    date_creation = models.DateTimeField(auto_now_add=True)
 
    class Meta:
        verbose_name = "Intervention"
        verbose_name_plural = "Interventions"
        ordering = ['-date_intervention']
 
    def __str__(self):
        who = self.prestataire if not self.realise_en_interne else "Interne"
        return f"{self.ticket.etablissement.code} | {who} | {self.date_intervention}"

# ─────────────────────────────────────────────
#  CONTRATS PRESTATAIRES
# ─────────────────────────────────────────────

class Contrat(models.Model):
    """
    Contrat prestataire rattaché à un établissement et un type de contrôle.
    Exemple : contrat SOCOTEC pour la vérification électrique annuelle du DITEP de Morencez.
    """
    etablissement = models.ForeignKey(
        Etablissement, on_delete=models.CASCADE,
        related_name='contrats', verbose_name="Établissement"
    )
    type_controle = models.ForeignKey(
        TypeControle, on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='contrats', verbose_name="Type de contrôle"
    )
    prestataire   = models.CharField(max_length=200, verbose_name="Prestataire")
    numero        = models.CharField(max_length=100, blank=True, verbose_name="Numéro de contrat")
    date_debut    = models.DateField(null=True, blank=True, verbose_name="Date de début")
    date_fin      = models.DateField(null=True, blank=True, verbose_name="Date de fin / échéance")
    montant       = models.DecimalField(
        max_digits=10, decimal_places=2,
        null=True, blank=True, verbose_name="Montant annuel (€)"
    )
    document      = models.FileField(
        upload_to='contrats/%Y/', null=True, blank=True,
        verbose_name="Document PDF du contrat"
    )
    notes         = models.TextField(blank=True, verbose_name="Notes")

    # Traçabilité
    cree_par      = models.ForeignKey(
        Utilisateur, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='contrats_crees'
    )
    date_creation = models.DateTimeField(auto_now_add=True)
    date_maj      = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Contrat prestataire"
        verbose_name_plural = "Contrats prestataires"
        ordering = ['etablissement', 'prestataire']

    def __str__(self):
        tc = self.type_controle.nom if self.type_controle else "—"
        return f"{self.etablissement.code} | {self.prestataire} | {tc}"

    @property
    def est_expire(self):
        if self.date_fin:
            return self.date_fin < timezone.now().date()
        return False

    @property
    def expire_bientot(self):
        """Vrai si le contrat expire dans moins de 60 jours."""
        if self.date_fin:
            from datetime import timedelta
            return self.date_fin <= timezone.now().date() + timedelta(days=60)
        return False


# ─────────────────────────────────────────────
#  COMMISSIONS DE SÉCURITÉ
# ─────────────────────────────────────────────

class VisiteCommission(models.Model):
    """
    Visite de la commission de sécurité sur un établissement.
    Contient le PV et la liste des prescriptions relevées.
    """
    etablissement   = models.ForeignKey(
        Etablissement, on_delete=models.CASCADE,
        related_name='visites_commission', verbose_name="Établissement"
    )
    date_visite     = models.DateField(verbose_name="Date de la visite")
    date_pv         = models.DateField(null=True, blank=True, verbose_name="Date de réception du PV")
    document_pv     = models.FileField(
        upload_to='commissions/%Y/', null=True, blank=True,
        verbose_name="PV de la commission (PDF)"
    )
    observations    = models.TextField(blank=True, verbose_name="Observations générales")
    cree_par        = models.ForeignKey(
        Utilisateur, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='visites_creees'
    )
    date_creation   = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Visite de commission"
        verbose_name_plural = "Visites de commission"
        ordering = ['-date_visite']

    def __str__(self):
        return f"{self.etablissement.code} — Commission {self.date_visite.strftime('%d/%m/%Y')}"

    @property
    def nb_prescriptions(self):
        return self.prescriptions.count()

    @property
    def nb_levees(self):
        return self.prescriptions.filter(statut='levee').count()

    @property
    def nb_en_cours(self):
        return self.prescriptions.filter(statut='en_cours').count()


class Prescription(models.Model):
    """
    Prescription relevée lors d'une visite de commission.
    Reste ouverte d'une visite à l'autre jusqu'à levée complète.
    """
    STATUT_CHOICES = [
        ('en_cours',  '🔄 En cours de traitement'),
        ('levee',     '✅ Levée'),
        ('reportee',  '🔴 Reportée au prochain PV'),
    ]

    visite      = models.ForeignKey(
        VisiteCommission, on_delete=models.CASCADE,
        related_name='prescriptions', verbose_name="Visite"
    )
    numero      = models.CharField(max_length=20, verbose_name="N° prescription", blank=True)
    description = models.TextField(verbose_name="Description de la non-conformité")
    delai       = models.DateField(null=True, blank=True, verbose_name="Délai imposé par la commission")
    statut      = models.CharField(
        max_length=20, choices=STATUT_CHOICES,
        default='en_cours', verbose_name="Statut"
    )
    # Lien vers le ticket travaux si un ticket a été créé pour cette prescription
    ticket      = models.ForeignKey(
        TicketTravaux, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='prescriptions'
    )
    date_creation = models.DateTimeField(auto_now_add=True)
    date_maj      = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Prescription"
        verbose_name_plural = "Prescriptions"
        ordering = ['numero', 'date_creation']

    def __str__(self):
        return f"Prescription {self.numero or '#'} — {self.description[:60]}"

    @property
    def derniere_action(self):
        return self.actions.order_by('-date').first()


class ActionPrescription(models.Model):
    """
    Journal de suivi d'une prescription : chaque étape prouve la prise en compte
    de la non-conformité (demande de devis, RDV artisan, travaux, justificatif…).
    """
    TYPE_CHOICES = [
        ('devis_demande',   '📨 Demande de devis envoyée'),
        ('devis_recu',      '📄 Devis reçu'),
        ('rdv_artisan',     '🗓️ Rendez-vous artisan'),
        ('travaux_realises','🔧 Travaux réalisés'),
        ('justificatif',    '📎 Justificatif joint'),
        ('autre',           '💬 Autre'),
    ]

    prescription = models.ForeignKey(
        Prescription, on_delete=models.CASCADE,
        related_name='actions', verbose_name="Prescription"
    )
    type_action  = models.CharField(
        max_length=30, choices=TYPE_CHOICES,
        default='autre', verbose_name="Type d'action"
    )
    date         = models.DateField(verbose_name="Date")
    note         = models.TextField(blank=True, verbose_name="Note / détail")
    document     = models.FileField(
        upload_to='prescriptions/%Y/', null=True, blank=True,
        verbose_name="Document (facture, photo, devis…)"
    )
    saisie_par   = models.ForeignKey(
        Utilisateur, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='actions_prescriptions'
    )
    date_saisie  = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Action sur prescription"
        verbose_name_plural = "Actions sur prescriptions"
        ordering = ['-date']

    def __str__(self):
        return f"{self.get_type_action_display()} — {self.date.strftime('%d/%m/%Y')}"




# ─────────────────────────────────────────────
#  CARNET SANITAIRE EAU
# ─────────────────────────────────────────────

class ReseauEau(models.Model):
    TYPE_CHOICES = [
        ('ecs', 'Eau Chaude Sanitaire (ECS)'),
        ('ef',  'Eau Froide'),
    ]
    etablissement = models.ForeignKey(
        Etablissement, on_delete=models.CASCADE,
        related_name='reseaux_eau', verbose_name="Etablissement"
    )
    type_reseau   = models.CharField(max_length=10, choices=TYPE_CHOICES, verbose_name="Type de reseau")
    description   = models.CharField(max_length=200, blank=True, verbose_name="Description complementaire")
    actif         = models.BooleanField(default=True, verbose_name="Actif")
    date_creation = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Reseau d'eau"
        verbose_name_plural = "Reseaux d'eau"
        ordering = ['etablissement', 'type_reseau']
        unique_together = ('etablissement', 'type_reseau')

    def __str__(self):
        return f"{self.etablissement.code} - {self.get_type_reseau_display()}"


class PointPrelevement(models.Model):
    reseau       = models.ForeignKey(ReseauEau, on_delete=models.CASCADE, related_name='points', verbose_name="Reseau")
    nom          = models.CharField(max_length=200, verbose_name="Nom du point")
    localisation = models.CharField(max_length=200, blank=True, verbose_name="Localisation")
    actif        = models.BooleanField(default=True, verbose_name="Actif")

    class Meta:
        verbose_name = "Point de prelevement"
        verbose_name_plural = "Points de prelevement"
        ordering = ['reseau', 'nom']

    def __str__(self):
        return f"{self.reseau.etablissement.code} | {self.reseau.get_type_reseau_display()} | {self.nom}"


class AnalyseEau(models.Model):
    PARAMETRE_CHOICES = [
        ('temperature',  'Temperature (degC)'),
        ('chlore_libre', 'Chlore libre (mg/L)'),
        ('chlore_total', 'Chlore total (mg/L)'),
        ('ph',           'pH'),
        ('legionelles',  'Legionelles (UFC/L)'),
        ('autre',        'Autre'),
    ]
    STATUT_CHOICES = [
        ('conforme',     'Conforme'),
        ('vigilance',    'Vigilance'),
        ('non_conforme', 'Non conforme'),
    ]
    SEUILS = {
        'temperature':  {'ecs_min': 50.0, 'ef_max': 25.0},
        'chlore_libre': {'min': 0.1, 'max': 0.5},
        'chlore_total': {'max': 1.0},
        'ph':           {'min': 6.5, 'max': 9.0},
        'legionelles':  {'vigilance': 1000.0, 'max': 100000.0},
    }
    UNITES = {
        'temperature':  'degC',
        'chlore_libre': 'mg/L',
        'chlore_total': 'mg/L',
        'ph':           '',
        'legionelles':  'UFC/L',
    }

    point        = models.ForeignKey(PointPrelevement, on_delete=models.CASCADE, related_name='analyses', verbose_name="Point de prelevement")
    date_analyse = models.DateField(verbose_name="Date de l'analyse")
    parametre    = models.CharField(max_length=20, choices=PARAMETRE_CHOICES, verbose_name="Parametre")
    valeur       = models.DecimalField(max_digits=12, decimal_places=3, verbose_name="Valeur mesuree")
    unite        = models.CharField(max_length=20, blank=True, verbose_name="Unite")
    statut       = models.CharField(max_length=20, choices=STATUT_CHOICES, blank=True, verbose_name="Statut")
    observations = models.TextField(blank=True, verbose_name="Observations")
    laboratoire  = models.CharField(max_length=200, blank=True, verbose_name="Laboratoire / Prestataire")
    document     = models.FileField(upload_to='analyses_eau/%Y/', null=True, blank=True, verbose_name="Rapport d'analyse")
    saisie_par   = models.ForeignKey(Utilisateur, null=True, blank=True, on_delete=models.SET_NULL, related_name='analyses_saisies')
    date_saisie  = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Analyse d'eau"
        verbose_name_plural = "Analyses d'eau"
        ordering = ['-date_analyse', 'parametre']

    def __str__(self):
        return f"{self.point} | {self.get_parametre_display()} | {self.date_analyse}"

    def calculer_statut(self):
        seuils = self.SEUILS.get(self.parametre)
        if not seuils:
            return 'conforme'
        v = float(self.valeur)
        type_reseau = self.point.reseau.type_reseau
        if self.parametre == 'temperature':
            if type_reseau == 'ecs':
                return 'conforme' if v >= seuils['ecs_min'] else 'non_conforme'
            return 'conforme' if v <= seuils['ef_max'] else 'vigilance'
        if self.parametre == 'legionelles':
            if v >= seuils['max']:
                return 'non_conforme'
            if v >= seuils['vigilance']:
                return 'vigilance'
            return 'conforme'
        if self.parametre in ('chlore_libre', 'ph'):
            if v < seuils['min'] or v > seuils['max']:
                return 'non_conforme'
            return 'conforme'
        if self.parametre == 'chlore_total':
            return 'non_conforme' if v > seuils['max'] else 'conforme'
        return 'conforme'

    def save(self, *args, **kwargs):
        self.statut = self.calculer_statut()
        if not self.unite:
            self.unite = self.UNITES.get(self.parametre, '')
        super().save(*args, **kwargs)


# ─────────────────────────────────────────────
#  MODULE DUERP
#  Document Unique d'Évaluation des Risques Professionnels
# ─────────────────────────────────────────────

class DUERP(models.Model):
    """
    Document Unique d'Évaluation des Risques Professionnels.
    Un DUERP par établissement par année civile.
    """
    STATUT_CHOICES = [
        ('brouillon', '✏️ Brouillon'),
        ('valide',    '✅ Validé'),
        ('archive',   '📦 Archivé'),
    ]

    etablissement  = models.ForeignKey(
        Etablissement, on_delete=models.CASCADE, related_name='duerp_set',
        verbose_name="Établissement"
    )
    annee          = models.PositiveIntegerField(verbose_name="Année")
    date_creation  = models.DateField(auto_now_add=True)
    date_validation = models.DateField(null=True, blank=True, verbose_name="Date de validation")
    signataire     = models.CharField(max_length=200, blank=True, verbose_name="Signataire (Chef d'établissement)")
    statut         = models.CharField(max_length=20, choices=STATUT_CHOICES, default='brouillon')
    observations_generales = models.TextField(blank=True, verbose_name="Observations générales")

    # Signatures permanentes
    signature_directeur       = models.ImageField(upload_to='signatures/duerp/', null=True, blank=True)
    nom_directeur             = models.CharField(max_length=200, blank=True)
    date_signature_directeur  = models.DateTimeField(null=True, blank=True)
    signature_responsable     = models.ImageField(upload_to='signatures/duerp/', null=True, blank=True)
    nom_responsable           = models.CharField(max_length=200, blank=True)
    date_signature_responsable = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "DUERP"
        verbose_name_plural = "DUERP"
        unique_together = ('etablissement', 'annee')
        ordering = ['-annee']

    def __str__(self):
        return f"DUERP {self.annee} – {self.etablissement}"


class UniteTravail(models.Model):
    """
    Unité de travail au sein d'un DUERP (ex : Internat, Pédagogique, Maintenance…).
    Chaque unité a sa propre liste d'évaluations de risques.
    """
    TYPE_CHOICES = [
        ('tertiaire_bureautique', 'Tertiaire / Bureautique'),
        ('maintenance_entretien', 'Maintenance & Entretien'),
        ('internat',             'Internat'),
        ('pedagogique',          'Pédagogique'),
        ('therapeutique',        'Thérapeutique'),
        ('abords_immediats',     'Abords immédiats'),
        ('incendie',             'Risque Incendie'),
        ('covid',                'COVID-19 / Risque biologique'),
        ('autre',                'Autre'),
    ]

    duerp       = models.ForeignKey(DUERP, on_delete=models.CASCADE, related_name='unites_travail')
    type_unite  = models.CharField(max_length=30, choices=TYPE_CHOICES, verbose_name="Type")
    nom_custom  = models.CharField(max_length=200, blank=True, verbose_name="Nom personnalisé (optionnel)")
    ordre       = models.PositiveSmallIntegerField(default=0, verbose_name="Ordre d'affichage")

    class Meta:
        verbose_name = "Unité de travail"
        verbose_name_plural = "Unités de travail"
        ordering = ['ordre', 'type_unite']

    def __str__(self):
        return self.nom_custom or self.get_type_unite_display()


class CategorieRisque(models.Model):
    """
    Catégorie de risque pré-définie (master data).
    Ex : 'Circulation des piétons', 'Déplacements', 'Travail en hauteur'…
    """
    type_unite  = models.CharField(
        max_length=30, choices=UniteTravail.TYPE_CHOICES,
        verbose_name="Type d'unité associé"
    )
    nom         = models.CharField(max_length=200, verbose_name="Catégorie")
    ordre       = models.PositiveSmallIntegerField(default=0)

    class Meta:
        verbose_name = "Catégorie de risque"
        verbose_name_plural = "Catégories de risque"
        ordering = ['type_unite', 'ordre']

    def __str__(self):
        return f"{self.get_type_unite_display()} → {self.nom}"


class SourceDanger(models.Model):
    """
    Source de danger pré-définie (master data, tirée des documents de référence).
    Ex : 'Sol glissant, produits répandus…'
    """
    categorie          = models.ForeignKey(
        CategorieRisque, on_delete=models.CASCADE, related_name='sources_danger'
    )
    description        = models.CharField(max_length=500, verbose_name="Source de danger")
    risque_potentiel   = models.CharField(max_length=300, blank=True, verbose_name="Risque potentiel type")
    ordre              = models.PositiveSmallIntegerField(default=0)

    class Meta:
        verbose_name = "Source de danger"
        verbose_name_plural = "Sources de danger"
        ordering = ['categorie', 'ordre']

    def __str__(self):
        return self.description[:80]


class EvaluationRisque(models.Model):
    """
    Évaluation d'une source de danger pour une unité de travail donnée.
    Correspond à une ligne de la checklist DUERP.
    """
    NIVEAU_CHOICES = [
        ('',             '—'),
        ('tres_faible',  'Très faible'),
        ('faible',       'Faible'),
        ('moyen',        'Moyen'),
        ('important',    'Important'),
        ('tres_important', 'Très important'),
    ]

    unite_travail      = models.ForeignKey(
        UniteTravail, on_delete=models.CASCADE, related_name='evaluations'
    )
    source_danger      = models.ForeignKey(
        SourceDanger, on_delete=models.PROTECT, related_name='evaluations'
    )
    present            = models.BooleanField(default=False, verbose_name="Risque présent")
    risque_potentiel   = models.CharField(
        max_length=300, blank=True,
        verbose_name="Risque potentiel (modifiable)"
    )
    niveau             = models.CharField(
        max_length=20, choices=NIVEAU_CHOICES, blank=True,
        verbose_name="Niveau de risque"
    )
    observation        = models.TextField(blank=True, verbose_name="Observation / Commentaire")

    class Meta:
        verbose_name = "Évaluation de risque"
        verbose_name_plural = "Évaluations de risque"
        unique_together = ('unite_travail', 'source_danger')
        ordering = ['source_danger__categorie__ordre', 'source_danger__ordre']

    def __str__(self):
        return f"{self.unite_travail} | {self.source_danger}"

    def save(self, *args, **kwargs):
        # Pré-remplir le risque potentiel depuis la source si vide
        if not self.risque_potentiel and self.source_danger_id:
            self.risque_potentiel = self.source_danger.risque_potentiel
        super().save(*args, **kwargs)


class PlanActionDUERP(models.Model):
    """
    Action corrective issue du DUERP.
    Peut être liée à une évaluation de risque et/ou à un ticket travaux.
    """
    AVANCEMENT_CHOICES = [
        ('a_faire',   '🔴 À faire'),
        ('en_cours',  '🟡 En cours'),
        ('termine',   '✅ Terminé'),
    ]

    duerp              = models.ForeignKey(
        DUERP, on_delete=models.CASCADE, related_name='plan_actions'
    )
    evaluation_risque  = models.ForeignKey(
        EvaluationRisque, null=True, blank=True, on_delete=models.SET_NULL,
        related_name='actions', verbose_name="Risque associé"
    )
    ticket             = models.ForeignKey(
        TicketTravaux, null=True, blank=True, on_delete=models.SET_NULL,
        related_name='actions_duerp', verbose_name="Ticket travaux lié"
    )

    description_action = models.TextField(verbose_name="Action à mener")
    responsable        = models.CharField(max_length=200, blank=True, verbose_name="Personne en charge")
    delai              = models.DateField(null=True, blank=True, verbose_name="Délai de réalisation")
    avancement         = models.CharField(
        max_length=20, choices=AVANCEMENT_CHOICES, default='a_faire',
        verbose_name="Avancement"
    )
    date_creation      = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Action du plan DUERP"
        verbose_name_plural = "Actions du plan DUERP"
        ordering = ['delai', 'avancement']

    def __str__(self):
        return f"{self.duerp} | {self.description_action[:60]}"


# ─────────────────────────────────────────────
#  MODULE DUERP
#  Document Unique d'Évaluation des Risques Professionnels
# ─────────────────────────────────────────────



# ─────────────────────────────────────────────
#  MODULE REGISTRE PUBLIC D'ACCESSIBILITÉ
#  Obligation légale depuis le 22 avril 2017
#  Décret n°2017-431 du 28 mars 2017
# ─────────────────────────────────────────────

class RegistreAccessibilite(models.Model):
    """
    Registre Public d'Accessibilité d'un établissement.
    Un registre par établissement, mis à jour en continu.
    """
    STATUT_CHOICES = [
        ('en_cours',  'En cours de complétion'),
        ('complet',   'Complet'),
        ('publie',    'Publié'),
    ]

    etablissement   = models.OneToOneField(
        Etablissement, on_delete=models.CASCADE,
        related_name='registre_accessibilite',
        verbose_name="Établissement"
    )
    statut          = models.CharField(max_length=20, choices=STATUT_CHOICES, default='en_cours')
    date_creation   = models.DateField(auto_now_add=True)
    date_mise_a_jour = models.DateField(auto_now=True)
    observations_generales = models.TextField(blank=True, verbose_name="Observations générales")

    # Signatures permanentes
    signature_directeur        = models.ImageField(upload_to='signatures/accessibilite/', null=True, blank=True)
    nom_directeur              = models.CharField(max_length=200, blank=True)
    date_signature_directeur   = models.DateTimeField(null=True, blank=True)
    signature_responsable      = models.ImageField(upload_to='signatures/accessibilite/', null=True, blank=True)
    nom_responsable            = models.CharField(max_length=200, blank=True)
    date_signature_responsable = models.DateTimeField(null=True, blank=True)

    # Informations Ad'AP (Agenda d'Accessibilité Programmée)
    adap_reference  = models.CharField(max_length=200, blank=True, verbose_name="Référence Ad'AP")
    adap_date_depot = models.DateField(null=True, blank=True, verbose_name="Date de dépôt Ad'AP")
    adap_date_fin   = models.DateField(null=True, blank=True, verbose_name="Date de fin Ad'AP")

    class Meta:
        verbose_name = "Registre d'accessibilité"
        verbose_name_plural = "Registres d'accessibilité"

    def __str__(self):
        return f"Registre Accessibilité — {self.etablissement}"

    def taux_conformite(self):
        """Retourne le % de zones conformes (hors sans objet)."""
        evals = self.evaluations.exclude(statut_moteur='so', statut_visuel='so',
                                          statut_auditif='so', statut_mental='so')
        if not evals.exists():
            return 0
        conformes = sum(1 for e in evals if e.est_conforme)
        return round(conformes / evals.count() * 100)


class EvaluationZone(models.Model):
    """
    Évaluation de l'accessibilité d'une zone pour les 4 types de handicap.
    Une ligne par zone (10 zones au total, pré-définies).
    """
    ZONE_CHOICES = [
        ('stationnement',        '🅿 Stationnement'),
        ('cheminement_ext',      '🚶 Cheminement extérieur'),
        ('entree',               '🚪 Entrée principale'),
        ('accueil',              '🏥 Accueil'),
        ('circulation_horiz',    '➡ Circulations horizontales'),
        ('circulation_vert',     '🪜 Circulations verticales'),
        ('sanitaires',           '🚻 Sanitaires'),
        ('equipements',          '🔘 Équipements et commandes'),
        ('eclairage',            '💡 Éclairage'),
        ('signalétique',         '🪧 Signalétique'),
    ]

    STATUT_CHOICES = [
        ('conforme',      'Conforme'),
        ('non_conforme',  'Non conforme'),
        ('so',            'Sans objet'),
        ('en_cours',      'Travaux en cours'),
    ]

    registre        = models.ForeignKey(
        RegistreAccessibilite, on_delete=models.CASCADE, related_name='evaluations'
    )
    zone            = models.CharField(max_length=30, choices=ZONE_CHOICES, verbose_name="Zone")
    ordre           = models.PositiveSmallIntegerField(default=0)

    # Statut par type de handicap
    statut_moteur   = models.CharField(max_length=15, choices=STATUT_CHOICES, default='so', verbose_name="Handicap moteur")
    statut_visuel   = models.CharField(max_length=15, choices=STATUT_CHOICES, default='so', verbose_name="Handicap visuel")
    statut_auditif  = models.CharField(max_length=15, choices=STATUT_CHOICES, default='so', verbose_name="Handicap auditif")
    statut_mental   = models.CharField(max_length=15, choices=STATUT_CHOICES, default='so', verbose_name="Handicap mental/cognitif")

    observation     = models.TextField(blank=True, verbose_name="Observations / détails")

    class Meta:
        verbose_name = "Évaluation de zone"
        verbose_name_plural = "Évaluations de zones"
        unique_together = ('registre', 'zone')
        ordering = ['ordre']

    def __str__(self):
        return f"{self.registre.etablissement.code} — {self.get_zone_display()}"

    @property
    def est_conforme(self):
        statuts = [self.statut_moteur, self.statut_visuel, self.statut_auditif, self.statut_mental]
        return all(s in ('conforme', 'so') for s in statuts)

    @property
    def a_non_conforme(self):
        return 'non_conforme' in [self.statut_moteur, self.statut_visuel, self.statut_auditif, self.statut_mental]


class FormationPersonnel(models.Model):
    """Formation du personnel à l'accueil des personnes handicapées."""
    TYPE_CHOICES = [
        ('sensibilisation', 'Sensibilisation au handicap'),
        ('accueil_pmr',     'Accueil des PMR'),
        ('lsf',             'Langue des signes française (LSF)'),
        ('braille',         'Communication en braille'),
        ('autre',           'Autre formation'),
    ]

    registre        = models.ForeignKey(
        RegistreAccessibilite, on_delete=models.CASCADE, related_name='formations'
    )
    type_formation  = models.CharField(max_length=30, choices=TYPE_CHOICES, verbose_name="Type de formation")
    intitule        = models.CharField(max_length=300, verbose_name="Intitulé de la formation")
    organisme       = models.CharField(max_length=200, blank=True, verbose_name="Organisme de formation")
    date_formation  = models.DateField(verbose_name="Date de formation")
    nb_personnes    = models.PositiveSmallIntegerField(default=1, verbose_name="Nombre de personnes formées")
    observations    = models.TextField(blank=True)

    class Meta:
        verbose_name = "Formation personnel"
        verbose_name_plural = "Formations personnel"
        ordering = ['-date_formation']

    def __str__(self):
        return f"{self.intitule} — {self.date_formation}"


class PieceAdministrative(models.Model):
    """Pièces justificatives du registre (Ad'AP, attestations, arrêtés...)."""
    TYPE_CHOICES = [
        ('adap',            "Agenda d'Accessibilité Programmée (Ad'AP)"),
        ('attestation',     'Attestation de conformité'),
        ('arrete_travaux',  'Arrêté de travaux'),
        ('autorisation',    'Autorisation de construire / ERP'),
        ('derogation',      'Dérogation préfectorale'),
        ('autre',           'Autre document'),
    ]

    registre        = models.ForeignKey(
        RegistreAccessibilite, on_delete=models.CASCADE, related_name='pieces_administratives'
    )
    type_piece      = models.CharField(max_length=30, choices=TYPE_CHOICES, verbose_name="Type de document")
    intitule        = models.CharField(max_length=300, verbose_name="Intitulé")
    date_document   = models.DateField(null=True, blank=True, verbose_name="Date du document")
    fichier         = models.FileField(upload_to='accessibilite/pieces/', null=True, blank=True, verbose_name="Fichier")
    observations    = models.TextField(blank=True)

    class Meta:
        verbose_name = "Pièce administrative"
        verbose_name_plural = "Pièces administratives"
        ordering = ['-date_document']

    def __str__(self):
        return f"{self.get_type_piece_display()} — {self.intitule}"


class ActionMiseConformite(models.Model):
    """Action de mise en conformité accessibilité, liée à une zone non conforme."""
    AVANCEMENT_CHOICES = [
        ('prevu',    'Prévu'),
        ('en_cours', 'En cours'),
        ('realise',  'Réalisé'),
    ]

    registre        = models.ForeignKey(
        RegistreAccessibilite, on_delete=models.CASCADE, related_name='actions'
    )
    evaluation_zone = models.ForeignKey(
        EvaluationZone, null=True, blank=True, on_delete=models.SET_NULL,
        related_name='actions', verbose_name="Zone concernée"
    )
    ticket          = models.ForeignKey(
        TicketTravaux, null=True, blank=True, on_delete=models.SET_NULL,
        related_name='actions_accessibilite', verbose_name="Ticket travaux lié"
    )
    description     = models.TextField(verbose_name="Travaux / action à mener")
    responsable     = models.CharField(max_length=200, blank=True, verbose_name="Responsable")
    delai_prevu     = models.DateField(null=True, blank=True, verbose_name="Délai prévu")
    cout_estime     = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Coût estimé (€)")
    avancement      = models.CharField(max_length=20, choices=AVANCEMENT_CHOICES, default='prevu')
    date_realisation = models.DateField(null=True, blank=True, verbose_name="Date de réalisation effective")

    class Meta:
        verbose_name = "Action de mise en conformité"
        verbose_name_plural = "Actions de mise en conformité"
        ordering = ['delai_prevu']

    def __str__(self):
        return f"{self.registre.etablissement.code} — {self.description[:60]}"


# ─────────────────────────────────────────────
#  DROITS DE SIGNATURE
# ─────────────────────────────────────────────

class DroitSignature(models.Model):
    """
    Définit quel utilisateur peut signer quel type de document,
    sur quel établissement (null = tous les établissements).
    """
    DOCUMENT_CHOICES = [
        ('duerp',          'DUERP'),
        ('accessibilite',  "Registre d'Accessibilité"),
        ('intervention',   "Bon d'intervention"),
        ('contrat',        'Contrat prestataire'),
    ]

    utilisateur   = models.ForeignKey(
        Utilisateur, on_delete=models.CASCADE,
        related_name='droits_signature',
        verbose_name="Utilisateur"
    )
    etablissement = models.ForeignKey(
        Etablissement, on_delete=models.CASCADE,
        null=True, blank=True,
        related_name='droits_signature',
        verbose_name="Établissement (vide = tous)"
    )
    document      = models.CharField(
        max_length=20, choices=DOCUMENT_CHOICES,
        verbose_name="Type de document"
    )

    class Meta:
        verbose_name = "Droit de signature"
        verbose_name_plural = "Droits de signature"
        unique_together = ('utilisateur', 'etablissement', 'document')
        ordering = ['utilisateur', 'etablissement', 'document']

    def __str__(self):
        etab = self.etablissement.code if self.etablissement else "Tous les établissements"
        return f"{self.utilisateur.get_full_name()} | {etab} | {self.get_document_display()}"

    @classmethod
    @classmethod
    def peut_signer(cls, utilisateur, etablissement, document):
        """Vérifie si un utilisateur peut signer un document pour un établissement donné."""
        if utilisateur.is_superuser or utilisateur.role in ('admin', 'responsable_securite'):
            return True
        return cls.objects.filter(
            utilisateur=utilisateur,
            document=document,
        ).filter(
            models.Q(etablissement=etablissement) | models.Q(etablissement__isnull=True)
        ).exists()

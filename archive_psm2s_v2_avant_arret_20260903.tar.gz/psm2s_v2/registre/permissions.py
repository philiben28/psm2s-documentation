"""
Décorateurs de contrôle d'accès par rôle pour PSM2S.

Hiérarchie des droits :
  admin              → tout
  responsable_securite → gestion complète sauf admin système
  directeur          → idem responsable (vue globale + lecture)
  factotum           → documents, tickets, interventions en lecture/écriture
  prestataire        → idem factotum mais limité à ses établissements rattachés
"""
from functools import wraps
from django.shortcuts import redirect


def acces_requis(*roles):
    """
    Décorateur de vue : autorise seulement les rôles listés.
    Les superusers Django ont toujours accès.
    Redirection vers le dashboard si accès refusé.
    """
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect(f'/connexion/?next={request.path}')
            if request.user.is_superuser or request.user.role in roles:
                return view_func(request, *args, **kwargs)
            return redirect('registre:dashboard')
        return wrapper
    return decorator


# Raccourcis prêts à l'emploi
def admin_requis(view_func):
    return acces_requis('admin')(view_func)

def gestionnaire_requis(view_func):
    """Admin + Responsable sécurité + Directeur."""
    return acces_requis('admin', 'responsable_securite', 'directeur')(view_func)

def operateur_requis(view_func):
    """Tous sauf prestataire."""
    return acces_requis('admin', 'responsable_securite', 'directeur', 'factotum')(view_func)


def factotum_niveau_requis(niveau_min):
    """
    Restreint une vue aux factotums ayant au moins le niveau donné.
    Admin, responsable et directeur passent toujours.
    Les autres rôles sont bloqués.

    Usage :
        @factotum_niveau_requis(2)   # saisie interventions/tickets
        def nouvelle_intervention(request, ...):
    """
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect(f'/connexion/?next={request.path}')
            user = request.user
            # Superuser et rôles supérieurs : accès libre
            if user.is_superuser or user.role in ('admin', 'responsable_securite', 'directeur'):
                return view_func(request, *args, **kwargs)
            # Factotum : vérifier le niveau
            if user.role == 'factotum' and user.niveau_factotum >= niveau_min:
                return view_func(request, *args, **kwargs)
            # Tout le reste : dashboard
            return redirect('registre:dashboard')
        return wrapper
    return decorator

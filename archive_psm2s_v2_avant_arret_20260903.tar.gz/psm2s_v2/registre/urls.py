from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = 'registre'

urlpatterns = [
    # Connexion / Déconnexion PSM2S
    path('connexion/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='connexion'),

    # Tableau de bord principal
    path('', views.dashboard, name='dashboard'),

    # Tableau de bord multi-sites
    path('tableau-de-bord/', views.tableau_de_bord, name='tableau_de_bord'),

    # Nouvel établissement
    path('etablissement/nouveau/', views.nouveau_etablissement, name='nouveau_etablissement'),

    # Nouveau contrôle pour un établissement
    path('etablissement/<int:etab_pk>/controle/nouveau/', views.nouveau_controle, name='nouveau_controle'),

    # Détail d'un établissement
    path('etablissement/<int:pk>/', views.detail_etablissement, name='detail_etablissement'),

    # Modifier un établissement
    path('etablissement/<int:pk>/modifier/', views.modifier_etablissement, name='modifier_etablissement'),
    path('etablissement/<int:pk>/archiver/', views.archiver_etablissement, name='archiver_etablissement'),

    # Vue globale des contrôles
    path('controles/', views.controles_global, name='controles'),

    # Modifier un contrôle
    path('controles/<int:pk>/modifier/', views.modifier_controle, name='modifier_controle'),

    # Tickets (kanban global)
    path('tickets/', views.tickets_global, name='tickets'),

    # Nouveau ticket (formulaire intégré dans PSM2S)
    path('tickets/nouveau/', views.nouveau_ticket, name='nouveau_ticket'),

    # Modifier / supprimer un ticket
    path('tickets/<int:pk>/modifier/', views.modifier_ticket, name='modifier_ticket'),
    path('tickets/<int:pk>/supprimer/', views.supprimer_ticket, name='supprimer_ticket'),

    # Pièces jointes tickets
    path('tickets/<int:ticket_pk>/piece-jointe/ajouter/', views.ajouter_piece_jointe, name='ajouter_piece_jointe'),
    path('piece-jointe/<int:pk>/supprimer/', views.supprimer_piece_jointe, name='supprimer_piece_jointe'),

    # Interventions
    path('interventions/', views.interventions, name='interventions'),
    path('interventions/nouvelle/', views.nouvelle_intervention, name='nouvelle_intervention'),
    path('interventions/<int:pk>/modifier/', views.modifier_intervention, name='modifier_intervention'),

    # Nouveau document (upload intégré dans PSM2S)
    path('etablissement/<int:etab_pk>/document/nouveau/', views.nouveau_document, name='nouveau_document'),

    # Modifier / supprimer un document
    path('document/<int:pk>/modifier/', views.modifier_document, name='modifier_document'),
    path('document/<int:pk>/supprimer/', views.supprimer_document, name='supprimer_document'),

    # Registre de sécurité — vue impression / export PDF
    path('etablissement/<int:pk>/registre/', views.registre_pdf, name='registre_pdf'),

    # Bâtiments ERP
    path('etablissement/<int:etab_pk>/batiment/nouveau/', views.nouveau_batiment, name='nouveau_batiment'),
    path('batiment/<int:pk>/modifier/', views.modifier_batiment, name='modifier_batiment'),
    path('batiment/<int:pk>/supprimer/', views.supprimer_batiment, name='supprimer_batiment'),

    # Réalisations — historique annuel
    path('controle/<int:controle_pk>/realisation/nouvelle/', views.nouvelle_realisation, name='nouvelle_realisation'),
    path('controle/<int:controle_pk>/historique/', views.historique_controle, name='historique_controle'),

    # Déconnexion
    path('deconnexion/', auth_views.LogoutView.as_view(next_page='/connexion/'), name='deconnexion'),

    # Test email (admin seulement)
    path('test-email/', views.test_email, name='test_email'),

    # Lancer les alertes manuellement (admin seulement)
    path('alertes/lancer/', views.lancer_alertes, name='lancer_alertes'),

    # Manuel d'utilisation
    path('manuel/', views.manuel, name='manuel'),

    # Administration PSM2S
    path('administration/', views.administration, name='administration'),

    # Groupes
    path('administration/groupes/', views.liste_groupes, name='liste_groupes'),
    path('administration/groupes/nouveau/', views.nouveau_groupe, name='nouveau_groupe'),
    path('administration/groupes/<int:pk>/modifier/', views.modifier_groupe, name='modifier_groupe'),
    path('administration/groupes/<int:pk>/supprimer/', views.supprimer_groupe, name='supprimer_groupe'),

    # Utilisateurs
    path('administration/utilisateurs/', views.liste_utilisateurs, name='liste_utilisateurs'),
    path('administration/utilisateurs/nouveau/', views.nouvel_utilisateur, name='nouvel_utilisateur'),
    path('administration/utilisateurs/<int:pk>/modifier/', views.modifier_utilisateur, name='modifier_utilisateur'),
    path('administration/utilisateurs/<int:pk>/supprimer/', views.supprimer_utilisateur, name='supprimer_utilisateur'),
    path('administration/utilisateurs/<int:pk>/niveau/', views.modifier_niveau_factotum, name='modifier_niveau_factotum'),

    # Types de contrôle
    path('administration/types-controle/', views.liste_types_controle, name='liste_types_controle'),
    path('administration/types-controle/nouveau/', views.nouveau_type_controle, name='nouveau_type_controle'),
    path('administration/types-controle/<int:pk>/modifier/', views.modifier_type_controle, name='modifier_type_controle'),


    # Carnet sanitaire eau
    path('etablissement/<int:etab_pk>/eau/', views.carnet_eau, name='carnet_eau'),
    path('etablissement/<int:etab_pk>/eau/reseau/nouveau/', views.nouveau_reseau_eau, name='nouveau_reseau_eau'),
    path('eau/reseau/<int:reseau_pk>/point/nouveau/', views.nouveau_point_prelevement, name='nouveau_point_prelevement'),
    path('etablissement/<int:etab_pk>/eau/analyse/nouvelle/', views.nouvelle_analyse_eau, name='nouvelle_analyse_eau'),
    path('eau/analyse/<int:pk>/modifier/', views.modifier_analyse_eau, name='modifier_analyse_eau'),
    path('eau/analyse/<int:pk>/supprimer/', views.supprimer_analyse_eau, name='supprimer_analyse_eau'),

    # Commissions de sécurité
    path('etablissement/<int:etab_pk>/commission/nouvelle/', views.nouvelle_visite_commission, name='nouvelle_visite_commission'),
    path('commission/<int:pk>/', views.detail_visite_commission, name='detail_visite_commission'),
    path('commission/<int:pk>/modifier/', views.modifier_visite_commission, name='modifier_visite_commission'),
    path('commission/<int:pk>/supprimer/', views.supprimer_visite_commission, name='supprimer_visite_commission'),
    path('commission/<int:visite_pk>/prescription/nouvelle/', views.nouvelle_prescription, name='nouvelle_prescription'),
    path('prescription/<int:pk>/modifier/', views.modifier_prescription, name='modifier_prescription'),
    path('prescription/<int:prescription_pk>/action/nouvelle/', views.nouvelle_action_prescription, name='nouvelle_action_prescription'),
    path('action/<int:pk>/supprimer/', views.supprimer_action_prescription, name='supprimer_action_prescription'),

    # Contrats prestataires
    path('etablissement/<int:etab_pk>/contrat/nouveau/', views.nouveau_contrat, name='nouveau_contrat'),
    path('contrat/<int:pk>/modifier/', views.modifier_contrat, name='modifier_contrat'),
    path('contrat/<int:pk>/supprimer/', views.supprimer_contrat, name='supprimer_contrat'),

    # Périodicités
    path('administration/periodicites/', views.liste_periodicites, name='liste_periodicites'),
    path('administration/periodicites/nouvelle/', views.nouvelle_periodicite, name='nouvelle_periodicite'),
    path('administration/periodicites/<int:pk>/modifier/', views.modifier_periodicite, name='modifier_periodicite'),
    path('administration/periodicites/<int:pk>/supprimer/', views.supprimer_periodicite, name='supprimer_periodicite'),

    # DUERP
    path('duerp/', views.duerp_liste, name='duerp_liste'),
    path('etablissement/<int:etab_pk>/duerp/nouveau/', views.duerp_nouveau, name='duerp_nouveau'),
    path('duerp/<int:pk>/', views.duerp_detail, name='duerp_detail'),
    path('duerp/unite/<int:unite_pk>/checklist/', views.duerp_checklist, name='duerp_checklist'),
    path('duerp/<int:pk>/plan-action/', views.duerp_plan_action, name='duerp_plan_action'),
    path('duerp/<int:duerp_pk>/action/creer/', views.duerp_action_creer, name='duerp_action_creer'),
    path('duerp/action/<int:pk>/modifier/', views.duerp_action_modifier, name='duerp_action_modifier'),
    path('duerp/action/<int:action_pk>/creer-ticket/', views.duerp_creer_ticket, name='duerp_creer_ticket'),
    path('duerp/<int:pk>/modifier/', views.duerp_modifier, name='duerp_modifier'),
    path('duerp/<int:pk>/imprimer/', views.duerp_imprimer, name='duerp_imprimer'),

    # Registre Public d'Accessibilité
    path('etablissement/<int:etab_pk>/accessibilite/', views.accessibilite_detail, name='accessibilite_detail'),
    path('etablissement/<int:etab_pk>/accessibilite/grille/', views.accessibilite_grille, name='accessibilite_grille'),
    path('etablissement/<int:etab_pk>/accessibilite/formation/', views.accessibilite_formation_ajouter, name='accessibilite_formation_ajouter'),
    path('etablissement/<int:etab_pk>/accessibilite/piece/', views.accessibilite_piece_ajouter, name='accessibilite_piece_ajouter'),
    path('etablissement/<int:etab_pk>/accessibilite/action/', views.accessibilite_action_ajouter, name='accessibilite_action_ajouter'),
    path('accessibilite/action/<int:action_pk>/ticket/', views.accessibilite_creer_ticket, name='accessibilite_creer_ticket'),
    path('etablissement/<int:etab_pk>/accessibilite/imprimer/', views.accessibilite_imprimer, name='accessibilite_imprimer'),

    # Profil utilisateur
    path('mon-profil/', views.mon_profil, name='mon_profil'),

    # Signatures documents
    path('administration/droits-signature/', views.droits_signature_liste, name='droits_signature_liste'),
    path('duerp/<int:pk>/signer/', views.duerp_signer, name='duerp_signer'),
    path('duerp/<int:pk>/supprimer-signature/', views.duerp_supprimer_signature, name='duerp_supprimer_signature'),
    path('etablissement/<int:etab_pk>/accessibilite/signer/', views.accessibilite_signer, name='accessibilite_signer'),
]

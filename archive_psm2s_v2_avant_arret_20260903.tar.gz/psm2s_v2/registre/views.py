from datetime import timedelta

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .models import (
    Etablissement, Batiment, ControleEtablissement, TicketTravaux,
    Intervention, Document, TypeControle, RealisationControle, PieceJointeTicket,
    Periodicite, Contrat, VisiteCommission, Prescription, ActionPrescription,
    ReseauEau, PointPrelevement, AnalyseEau,
    Utilisateur, EtablissementUtilisateur,
)
from .forms import (TicketTravauxForm, DocumentForm, EtablissementForm,
                    ControleEtablissementForm, GroupeForm, UtilisateurForm, TypeControleForm,
                    RealisationControleForm, PieceJointeTicketForm, PeriodiciteForm,
                    ContratForm, VisiteCommissionForm, PrescriptionForm, ActionPrescriptionForm,
                    ReseauEauForm, PointPrelevementForm, AnalyseEauForm)
from django.contrib.auth.models import Group
from .models import TypeControle as TypeControleModel
from .permissions import acces_requis, admin_requis, gestionnaire_requis, operateur_requis, factotum_niveau_requis


def _get_etab_ids_autorises(user):
    """
    Retourne la liste des IDs d'établissements accessibles pour un utilisateur,
    selon son rôle. Retourne None si l'utilisateur a accès à tout.

    - admin / responsable_securite / superuser → None (pas de filtre)
    - directeur → ses établissements rattachés (EtablissementUtilisateur)
    - factotum → ses établissements rattachés + ceux où il a un ticket/intervention assigné
    - prestataire → établissements de ses tickets assignés

    Pour ajouter un nouveau rôle restreint : l'ajouter dans le elif approprié.
    """
    if user.is_superuser or user.role in ('admin', 'responsable_securite'):
        return None  # Accès total

    # Établissements rattachés (EtablissementUtilisateur)
    rattaches = set(user.etablissements.values_list('etablissement_id', flat=True))

    if user.role == 'directeur':
        return rattaches if rattaches else set()

    if user.role == 'factotum':
        # + établissements où il a un ticket ou une intervention assignée
        via_tickets = set(
            TicketTravaux.objects.filter(responsable=user)
            .values_list('etablissement_id', flat=True)
        )
        via_interventions = set(
            Intervention.objects.filter(saisie_par=user)
            .values_list('ticket__etablissement_id', flat=True)
        )
        return rattaches | via_tickets | via_interventions

    if user.role == 'prestataire':
        # Établissements rattachés manuellement + ceux via tickets assignés
        via_tickets = set(
            TicketTravaux.objects.filter(responsable=user)
            .values_list('etablissement_id', flat=True)
        )
        return rattaches | via_tickets

    return rattaches  # Tout autre rôle futur : établissements rattachés par défaut


def _calculer_prochaine_echeance(date_realisation, periodicite):
    """
    Retourne la prochaine échéance à partir de la date de réalisation
    et de la périodicité (nb_jours). Retourne None si ponctuel (nb_jours=0).
    """
    if date_realisation and periodicite and periodicite.nb_jours:
        return date_realisation + timedelta(days=periodicite.nb_jours)
    return None


# ─────────────────────────────────────────────
#  TABLEAU DE BORD — liste des établissements
# ─────────────────────────────────────────────

@login_required
def dashboard(request):
    # Rôles qui ne voient que leurs établissements rattachés
    # → ajouter ici tout nouveau rôle à restreindre
    ROLES_RESTREINTS = ['directeur', 'factotum', 'prestataire']

    if not request.user.is_superuser and request.user.role in ROLES_RESTREINTS:
        if request.user.role == 'prestataire':
            # Prestataires : établissements rattachés manuellement + ceux via tickets
            rattaches = set(request.user.etablissements.values_list('etablissement_id', flat=True))
            via_tickets = set(
                TicketTravaux.objects.filter(responsable=request.user)
                .values_list('etablissement_id', flat=True)
            )
            etab_ids = rattaches | via_tickets
        else:
            # Directeurs, factotums : leurs établissements rattachés
            etab_ids = request.user.etablissements.values_list('etablissement_id', flat=True)
        etablissements = Etablissement.objects.filter(actif=True, pk__in=etab_ids).prefetch_related('controles', 'tickets')
    else:
        # Admin, responsable_securite : tous les établissements
        etablissements = Etablissement.objects.filter(actif=True).prefetch_related(
            'controles', 'tickets'
        )

    today = timezone.now().date()

    # Enrichit chaque établissement avec des compteurs
    etab_list = []
    nb_a_jour = nb_a_planifier = nb_en_retard = 0

    for etab in etablissements:
        controles = etab.controles.all()
        en_retard  = sum(1 for c in controles if c.est_en_retard)
        a_faire    = sum(1 for c in controles if c.statut in ('a_faire', 'a_remettre_a_jour') and not c.est_en_retard)
        tickets_ouverts = etab.tickets.exclude(statut='cloture').count()

        if en_retard:
            statut_global = 'danger'
            nb_en_retard += 1
        elif a_faire:
            statut_global = 'warn'
            nb_a_planifier += 1
        else:
            statut_global = 'ok'
            nb_a_jour += 1

        etab_list.append({
            'obj': etab,
            'statut_global': statut_global,
            'en_retard': en_retard,
            'a_faire': a_faire,
            'tickets_ouverts': tickets_ouverts,
            'nb_documents': Document.objects.filter(controle__etablissement=etab).count(),
        })

    context = {
        'etab_list': etab_list,
        'total': len(etab_list),
        'nb_a_jour': nb_a_jour,
        'nb_a_planifier': nb_a_planifier,
        'nb_en_retard': nb_en_retard,
        'tickets_urgents': TicketTravaux.objects.filter(
            priorite__in=('critique', 'urgent')
        ).exclude(statut='cloture').count(),
    }
    return render(request, 'registre/dashboard.html', context)


# ─────────────────────────────────────────────
#  DÉTAIL D'UN ÉTABLISSEMENT
# ─────────────────────────────────────────────

@login_required
def detail_etablissement(request, pk):
    etab = get_object_or_404(Etablissement, pk=pk, actif=True)
    if request.user.role == 'prestataire' and not request.user.is_superuser:
        if not TicketTravaux.objects.filter(responsable=request.user, etablissement=etab).exists():
            return redirect('registre:dashboard')

    # ── Sélecteur d'année pour l'historique ──────────────────────────
    annee_courante = timezone.now().year
    # Inclut années avec réalisations + années importées depuis l'Excel
    annees_realisations = set(RealisationControle.annees_disponibles(etab))
    annees_importees = set(
        ControleEtablissement.objects
        .filter(etablissement=etab, date_realisation__isnull=False)
        .values_list('date_realisation__year', flat=True)
        .distinct()
    )
    annees_dispo = sorted(annees_realisations | annees_importees | {annee_courante}, reverse=True)
    try:
        annee_selectionnee = int(request.GET.get('annee', annee_courante))
    except (ValueError, TypeError):
        annee_selectionnee = annee_courante
    mode_historique = (annee_selectionnee != annee_courante)

    # ── Contrôles groupés par catégorie ──────────────────────────────
    controles = (
        ControleEtablissement.objects
        .filter(etablissement=etab)
        .select_related('type_controle')
        .prefetch_related('realisations')
        .order_by('type_controle__categorie', 'type_controle__nom')
    )

    # Réalisations de l'année sélectionnée, indexées par controle_id
    realisations_annee = {
        r.controle_id: r
        for r in RealisationControle.objects.filter(
            controle__etablissement=etab,
            annee=annee_selectionnee,
        ).order_by('-date_realisation')
    }

    categories_map = {}
    for c in controles:
        cat = c.type_controle.get_categorie_display()
        cat_key = c.type_controle.categorie
        if cat_key not in categories_map:
            categories_map[cat_key] = {
                'label': cat, 'key': cat_key,
                'controles': [], 'nb_fait': 0, 'nb_a_faire': 0, 'nb_retard': 0, 'nb_neutre': 0,
            }
        # Attacher la réalisation de l'année au contrôle
        c.realisation_annee = realisations_annee.get(c.pk)
        categories_map[cat_key]['controles'].append(c)

        if c.statut in ('pas_obligation', 'non_concerne'):
            categories_map[cat_key]['nb_neutre'] += 1
        elif mode_historique:
            # En mode historique : statut basé sur la réalisation de l'année
            if c.realisation_annee and c.realisation_annee.statut == 'fait':
                categories_map[cat_key]['nb_fait'] += 1
            else:
                categories_map[cat_key]['nb_a_faire'] += 1
        else:
            if c.est_en_retard:
                categories_map[cat_key]['nb_retard'] += 1
            elif c.statut == 'fait':
                categories_map[cat_key]['nb_fait'] += 1
            elif c.statut in ('a_faire', 'a_remettre_a_jour'):
                categories_map[cat_key]['nb_a_faire'] += 1

    # ── Documents ────────────────────────────────────────────────────
    documents = Document.objects.filter(
        controle__etablissement=etab
    ).select_related('controle__type_controle', 'depose_par').order_by('-date_depot')

    # ── Tickets / Interventions ───────────────────────────────────────
    tickets = etab.tickets.select_related('responsable').order_by('-date_creation')
    interventions = Intervention.objects.filter(
        ticket__etablissement=etab
    ).select_related('ticket').order_by('-date_intervention')[:10]

    # ── Stats ─────────────────────────────────────────────────────────
    nb_fait    = sum(1 for c in controles if c.statut == 'fait' and not c.est_en_retard)
    nb_a_faire = sum(1 for c in controles if c.statut in ('a_faire', 'a_remettre_a_jour') and not c.est_en_retard)
    nb_retard  = sum(1 for c in controles if c.est_en_retard)
    nb_neutre  = sum(1 for c in controles if c.statut in ('pas_obligation', 'non_concerne'))

    context = {
        'etab': etab,
        'categories': list(categories_map.values()),
        'documents': documents,
        'tickets': tickets,
        'interventions': interventions,
        'nb_fait': nb_fait,
        'nb_a_faire': nb_a_faire,
        'nb_retard': nb_retard,
        'nb_neutre': nb_neutre,
        'tickets_ouverts': tickets.exclude(statut='cloture').count(),
        # Historique annuel
        'annee_selectionnee': annee_selectionnee,
        'annee_courante': annee_courante,
        'annees_dispo': annees_dispo,
        'mode_historique': mode_historique,
        'contrats': Contrat.objects.filter(etablissement=etab).select_related('type_controle').order_by('prestataire'),
        'visites_commission': VisiteCommission.objects.filter(etablissement=etab).prefetch_related('prescriptions').order_by('-date_visite'),
        'reseaux_eau': ReseauEau.objects.filter(etablissement=etab, actif=True).prefetch_related('points__analyses').order_by('type_reseau'),
        'duerps': DUERP.objects.filter(etablissement=etab).order_by('-annee'),
        'duerp_actions_a_faire': PlanActionDUERP.objects.filter(
            duerp__etablissement=etab,
            avancement__in=['a_faire', 'en_cours']
        ).count(),
        'batiments': Batiment.objects.filter(etablissement=etab).order_by('nom'),
    }
    return render(request, 'registre/detail_etablissement.html', context)


# ─────────────────────────────────────────────
#  CONTRÔLES — vue globale tous établissements
# ─────────────────────────────────────────────

@acces_requis('admin', 'responsable_securite', 'directeur', 'factotum')
def controles_global(request):
    filtre = request.GET.get('filtre', 'tous')
    categorie = request.GET.get('categorie', '')

    etab_ids = _get_etab_ids_autorises(request.user)
    qs_base = ControleEtablissement.objects.select_related(
        'etablissement', 'type_controle'
    ).order_by('type_controle__categorie', 'etablissement__nom')
    if etab_ids is not None:
        qs_base = qs_base.filter(etablissement_id__in=etab_ids)

    qs = qs_base
    if filtre == 'a_faire':
        qs = [c for c in qs if c.statut in ('a_faire', 'a_remettre_a_jour')]
    elif filtre == 'retard':
        qs = [c for c in qs if c.est_en_retard]
    else:
        qs = list(qs)

    if categorie:
        qs = [c for c in qs if c.type_controle.categorie == categorie]

    nb_fait    = qs_base.filter(statut='fait').count()
    nb_a_faire = qs_base.filter(statut__in=('a_faire', 'a_remettre_a_jour')).count()
    nb_retard  = sum(1 for c in qs_base if c.est_en_retard)

    # CATEGORIE_CHOICES peut être défini sur le modèle ou sur le champ
    try:
        categories = TypeControle.CATEGORIE_CHOICES
    except AttributeError:
        try:
            categories = TypeControle._meta.get_field('categorie').choices
        except Exception:
            categories = []

    context = {
        'controles': qs,
        'filtre': filtre,
        'categorie': categorie,
        'categories': categories,
        'nb_fait': nb_fait,
        'nb_a_faire': nb_a_faire,
        'nb_retard': nb_retard,
    }
    return render(request, 'registre/controles.html', context)


# ─────────────────────────────────────────────
#  TICKETS — kanban global
# ─────────────────────────────────────────────

@login_required
def tickets_global(request):
    COLONNES = [
        ('a_traiter',        'À traiter'),
        ('devis_demande',    'Devis demandé'),
        ('valide',           'Validé'),
        ('en_cours',         'En cours'),
        ('controle_realise', 'Contrôlé'),
        ('cloture',          'Clôturé'),
    ]

    etab_ids = _get_etab_ids_autorises(request.user)

    colonnes = []
    for statut_key, statut_label in COLONNES:
        qs_base = TicketTravaux.objects.filter(statut=statut_key).select_related('etablissement', 'responsable')
        if etab_ids is not None:
            qs_base = qs_base.filter(etablissement_id__in=etab_ids)
        qs = list(qs_base.order_by('-date_creation'))
        colonnes.append({
            'key': statut_key,
            'label': statut_label,
            'tickets': qs,
            'count': len(qs),
        })

    base_qs = TicketTravaux.objects
    if etab_ids is not None:
        base_qs = base_qs.filter(etablissement_id__in=etab_ids)
    nb_ouverts  = base_qs.exclude(statut='cloture').count()
    nb_urgents  = base_qs.filter(priorite__in=('critique', 'urgent')).exclude(statut='cloture').count()
    nb_clotures = base_qs.filter(statut='cloture').count()

    context = {
        'colonnes': colonnes,
        'nb_ouverts': nb_ouverts,
        'nb_urgents': nb_urgents,
        'nb_clotures': nb_clotures,
    }
    return render(request, 'registre/tickets.html', context)


# ─────────────────────────────────────────────
#  RÉALISATIONS — HISTORIQUE ANNUEL
# ─────────────────────────────────────────────

@factotum_niveau_requis(2)
def nouvelle_realisation(request, controle_pk):
    """Enregistre une nouvelle réalisation pour un contrôle (historique annuel)."""
    controle = get_object_or_404(ControleEtablissement, pk=controle_pk)
    etab = controle.etablissement
    annee_courante = timezone.now().year

    if request.method == 'POST':
        form = RealisationControleForm(request.POST, request.FILES)
        if form.is_valid():
            realisation = form.save(commit=False)
            realisation.controle = controle
            realisation.annee = realisation.date_realisation.year
            realisation.saisie_par = request.user
            # Nom du document auto si non renseigné
            if realisation.document and not realisation.nom_document:
                realisation.nom_document = realisation.document.name.split('/')[-1]
            realisation.save()
            # Mettre à jour le statut et calculer la prochaine échéance
            if realisation.annee == annee_courante:
                controle.statut = realisation.statut
                controle.date_realisation = realisation.date_realisation
                controle.mis_a_jour_par = request.user
                # Calcul automatique de la prochaine échéance
                nouvelle_echeance = _calculer_prochaine_echeance(
                    realisation.date_realisation,
                    controle.type_controle.periodicite,
                )
                if nouvelle_echeance is not None:
                    controle.prochaine_echeance = nouvelle_echeance
                controle.save()
            from django.urls import reverse
            return redirect(reverse('registre:detail_etablissement', kwargs={'pk': etab.pk}) + f'?annee={realisation.annee}')
    else:
        form = RealisationControleForm()

    return render(request, 'registre/nouvelle_realisation.html', {
        'form': form,
        'controle': controle,
        'etab': etab,
    })


@login_required
def historique_controle(request, controle_pk):
    """Affiche toutes les réalisations d'un contrôle sur toutes les années."""
    controle = get_object_or_404(ControleEtablissement, pk=controle_pk)
    realisations = controle.realisations.order_by('-annee', '-date_realisation')
    return render(request, 'registre/historique_controle.html', {
        'controle': controle,
        'etab': controle.etablissement,
        'realisations': realisations,
    })


# ─────────────────────────────────────────────
#  NOUVEAU CONTRÔLE
# ─────────────────────────────────────────────

@gestionnaire_requis
def nouveau_controle(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk, actif=True)
    if request.method == 'POST':
        form = ControleEtablissementForm(request.POST, etab_pk=etab_pk)
        if form.is_valid():
            controle = form.save(commit=False)
            controle.etablissement = etab
            controle.save()
            return redirect('registre:detail_etablissement', pk=etab_pk)
    else:
        form = ControleEtablissementForm(etab_pk=etab_pk)
    return render(request, 'registre/nouveau_controle.html', {
        'form': form,
        'etab': etab,
    })


# ─────────────────────────────────────────────
#  MODIFIER CONTRÔLE
# ─────────────────────────────────────────────

@gestionnaire_requis
def modifier_controle(request, pk):
    controle = get_object_or_404(ControleEtablissement, pk=pk)
    etab = controle.etablissement
    if request.method == 'POST':
        form = ControleEtablissementForm(request.POST, instance=controle, etab_pk=etab.pk)
        if form.is_valid():
            ctrl = form.save(commit=False)
            # Recalcul automatique si date_realisation renseignée
            nouvelle_echeance = _calculer_prochaine_echeance(
                ctrl.date_realisation,
                ctrl.type_controle.periodicite,
            )
            if nouvelle_echeance is not None:
                ctrl.prochaine_echeance = nouvelle_echeance
            ctrl.save()
            return redirect('registre:detail_etablissement', pk=etab.pk)
    else:
        form = ControleEtablissementForm(instance=controle, etab_pk=etab.pk)
    return render(request, 'registre/modifier_controle.html', {
        'form': form,
        'controle': controle,
        'etab': etab,
    })


# ─────────────────────────────────────────────
#  NOUVEL ÉTABLISSEMENT
# ─────────────────────────────────────────────

@gestionnaire_requis
def nouveau_etablissement(request):
    if request.method == 'POST':
        form = EtablissementForm(request.POST)
        if form.is_valid():
            etab = form.save()
            return redirect('registre:detail_etablissement', pk=etab.pk)
    else:
        form = EtablissementForm()
    return render(request, 'registre/nouveau_etablissement.html', {'form': form})


# ─────────────────────────────────────────────
#  MODIFIER ÉTABLISSEMENT
# ─────────────────────────────────────────────

@gestionnaire_requis
def modifier_etablissement(request, pk):
    etab = get_object_or_404(Etablissement, pk=pk)
    if request.method == 'POST':
        form = EtablissementForm(request.POST, instance=etab)
        if form.is_valid():
            form.save()
            return redirect('registre:detail_etablissement', pk=pk)
    else:
        form = EtablissementForm(instance=etab)
    return render(request, 'registre/modifier_etablissement.html', {
        'form': form,
        'etab': etab,
    })


@admin_requis
def archiver_etablissement(request, pk):
    etab = get_object_or_404(Etablissement, pk=pk)
    if request.method == 'POST':
        etab.actif = False
        etab.save()
        return redirect('registre:dashboard')
    return render(request, 'registre/archiver_etablissement.html', {'etab': etab})


# ─────────────────────────────────────────────
#  BÂTIMENTS ERP
# ─────────────────────────────────────────────

@gestionnaire_requis
def nouveau_batiment(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk, actif=True)
    if request.method == 'POST':
        nom = request.POST.get('nom', '').strip()
        if nom:
            Batiment.objects.create(
                etablissement=etab,
                nom=nom,
                type_erp=request.POST.get('type_erp', ''),
                categorie=request.POST.get('categorie', ''),
                capacite_accueil=request.POST.get('capacite_accueil') or None,
                actif=True,
            )
    return redirect('registre:detail_etablissement', pk=etab_pk)


@gestionnaire_requis
def modifier_batiment(request, pk):
    batiment = get_object_or_404(Batiment, pk=pk)
    etab = batiment.etablissement
    if request.method == 'POST':
        batiment.nom = request.POST.get('nom', batiment.nom).strip()
        batiment.type_erp = request.POST.get('type_erp', '')
        batiment.categorie = request.POST.get('categorie', '')
        batiment.capacite_accueil = request.POST.get('capacite_accueil') or None
        batiment.actif = 'actif' in request.POST
        batiment.save()
        return redirect('registre:detail_etablissement', pk=etab.pk)
    return render(request, 'registre/modifier_batiment.html', {
        'batiment': batiment,
        'etab': etab,
        'TYPE_ERP_CHOICES': Batiment.TYPE_ERP_CHOICES,
        'CATEGORIE_CHOICES': Batiment.CATEGORIE_CHOICES,
    })


@gestionnaire_requis
def supprimer_batiment(request, pk):
    batiment = get_object_or_404(Batiment, pk=pk)
    etab_pk = batiment.etablissement_id
    if request.method == 'POST':
        batiment.delete()
    return redirect('registre:detail_etablissement', pk=etab_pk)


# ─────────────────────────────────────────────
#  NOUVEAU TICKET — formulaire intégré
# ─────────────────────────────────────────────

@login_required
def manuel(request):
    return render(request, 'registre/manuel.html')


@admin_requis
def lancer_alertes(request):
    """
    Vue admin-only : déclenche manuellement la commande envoyer_alertes.
    Accessible via /alertes/lancer/ — utile pour tester sans attendre le cron.
    Paramètre ?dry_run=1 pour simuler sans envoyer.
    """
    from django.core.management import call_command
    from io import StringIO

    dry_run = request.GET.get('dry_run', '0') == '1'
    out = StringIO()
    erreur = None

    try:
        if dry_run:
            call_command('envoyer_alertes', dry_run=True, stdout=out, stderr=out)
        else:
            call_command('envoyer_alertes', stdout=out, stderr=out)
    except Exception as e:
        erreur = str(e)

    return render(request, 'registre/lancer_alertes.html', {
        'log': out.getvalue(),
        'erreur': erreur,
        'dry_run': dry_run,
    })


@admin_requis
def test_email(request):
    """Vue de diagnostic : envoie un email de test et affiche le résultat."""
    from django.core.mail import send_mail
    from django.conf import settings as dj_settings
    dest = request.GET.get('dest', request.user.email or '')
    resultat = None
    erreur = None
    if dest:
        try:
            send_mail(
                '[PSM2S] Email de test',
                'Si vous recevez ce message, la configuration email fonctionne correctement.',
                dj_settings.DEFAULT_FROM_EMAIL,
                [dest],
                fail_silently=False,
            )
            resultat = f'Email envoyé avec succès à {dest}'
        except Exception as e:
            erreur = str(e)
    config = {
        'HOST': dj_settings.EMAIL_HOST,
        'PORT': dj_settings.EMAIL_PORT,
        'TLS': dj_settings.EMAIL_USE_TLS,
        'USER': dj_settings.EMAIL_HOST_USER,
        'FROM': dj_settings.DEFAULT_FROM_EMAIL,
    }
    html = f"""
    <html><body style="font-family:sans-serif;padding:30px;max-width:600px;">
    <h2>Test email PSM2S</h2>
    <h3>Configuration actuelle</h3>
    <ul>{''.join(f'<li><b>{k}</b> : {v}</li>' for k,v in config.items())}</ul>
    <h3>Envoyer un test</h3>
    <form><input name="dest" value="{dest}" placeholder="adresse@email.fr" style="padding:6px;width:300px;border:1px solid #ccc;border-radius:4px;">
    <button type="submit" style="padding:6px 16px;background:#185FA5;color:#fff;border:none;border-radius:4px;cursor:pointer;">Envoyer</button></form>
    {'<p style="color:green;font-weight:bold;">✅ ' + resultat + '</p>' if resultat else ''}
    {'<p style="color:red;font-weight:bold;">❌ Erreur : ' + erreur + '</p>' if erreur else ''}
    <p><a href="/">Retour</a></p>
    </body></html>"""
    from django.http import HttpResponse
    return HttpResponse(html)


def _notifier_responsable(ticket, request):
    """Envoie un email au chargé de travaux si il a une adresse email."""
    responsable = ticket.responsable
    if not responsable or not responsable.email:
        return
    try:
        from django.core.mail import send_mail
        from django.conf import settings
        prenom = responsable.first_name or responsable.username
        etab = ticket.etablissement

        # Adresse de l'établissement
        adresse_lignes = []
        if etab.adresse:
            adresse_lignes.append(etab.adresse)
        if etab.ville:
            adresse_lignes.append(etab.ville)
        adresse_str = '\n              '.join(adresse_lignes) if adresse_lignes else 'Non renseignée'

        # Contact sur place : champ dédié de la fiche établissement
        contact_parts = []
        if etab.contact_nom:
            contact_parts.append(etab.contact_nom)
        if etab.contact_telephone:
            contact_parts.append(etab.contact_telephone)
        if etab.contact_email:
            contact_parts.append(etab.contact_email)
        contact_str = ' — '.join(contact_parts) if contact_parts else 'Non renseigné'

        sujet = f"[PSM2S] Ticket confié : {ticket.titre}"
        message = f"""Bonjour {prenom},

Un ticket vous a été confié dans le registre de sécurité PSM2S.

Établissement : {etab}
Adresse       : {adresse_str}
Contact/place : {contact_str}

Ticket        : {ticket.titre}
Priorité      : {ticket.get_priorite_display()}
Statut        : {ticket.get_statut_display()}
{"Date cible   : " + ticket.date_cible.strftime("%d/%m/%Y") if ticket.date_cible else ""}

Connectez-vous sur {settings.BASE_URL}/tickets/ pour consulter ce ticket.

—
PSM2S Securite – ADPEP28
"""
        send_mail(
            sujet,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [responsable.email],
            fail_silently=True,
        )
    except Exception:
        pass  # Ne pas bloquer la création du ticket si l'email échoue


@factotum_niveau_requis(2)
def nouveau_ticket(request):
    etab_pk = request.GET.get('etab')
    if request.method == 'POST':
        form = TicketTravauxForm(request.POST, etab_pk=etab_pk)
        if form.is_valid():
            ticket = form.save(commit=False)
            ticket.cree_par = request.user
            ticket.save()
            form.save_m2m()
            _notifier_responsable(ticket, request)
            # Retour vers la fiche établissement si on venait de là
            if etab_pk:
                return redirect('registre:detail_etablissement', pk=etab_pk)
            return redirect('registre:tickets')
    else:
        form = TicketTravauxForm(etab_pk=etab_pk)
    return render(request, 'registre/nouveau_ticket.html', {
        'form': form,
        'etab_pk': etab_pk,
    })


@factotum_niveau_requis(2)
def modifier_ticket(request, pk):
    ticket = get_object_or_404(TicketTravaux, pk=pk)
    if request.method == 'POST':
        form = TicketTravauxForm(request.POST, instance=ticket, etab_pk=ticket.etablissement_id)
        if form.is_valid():
            ticket = form.save()
            _notifier_responsable(ticket, request)
            return redirect('registre:tickets')
    else:
        form = TicketTravauxForm(instance=ticket, etab_pk=ticket.etablissement_id)
    pieces_jointes = ticket.pieces_jointes.all()
    return render(request, 'registre/modifier_ticket.html', {
        'form': form,
        'ticket': ticket,
        'pieces_jointes': pieces_jointes,
    })

@login_required
def ajouter_piece_jointe(request, ticket_pk):
    """Ajoute une pièce jointe (devis, facture, photo) à un ticket."""
    ticket = get_object_or_404(TicketTravaux, pk=ticket_pk)
    if request.method == 'POST':
        form = PieceJointeTicketForm(request.POST, request.FILES)
        if form.is_valid():
            pj = form.save(commit=False)
            pj.ticket = ticket
            pj.depose_par = request.user
            if not pj.nom_fichier and pj.fichier:
                pj.nom_fichier = pj.fichier.name.split('/')[-1]
            pj.save()
            return redirect('registre:modifier_ticket', pk=ticket_pk)
    else:
        form = PieceJointeTicketForm()
    return render(request, 'registre/ajouter_piece_jointe.html', {
        'form': form, 'ticket': ticket,
    })


@login_required
def supprimer_piece_jointe(request, pk):
    """Supprime une pièce jointe d'un ticket."""
    pj = get_object_or_404(PieceJointeTicket, pk=pk)
    ticket_pk = pj.ticket_id
    if request.method == 'POST':
        if pj.fichier:
            try:
                pj.fichier.delete(save=False)
            except Exception:
                pass
        pj.delete()
        return redirect('registre:modifier_ticket', pk=ticket_pk)
    return render(request, 'registre/supprimer_piece_jointe.html', {'pj': pj})


@acces_requis('admin', 'responsable_securite', 'directeur')
def supprimer_ticket(request, pk):
    ticket = get_object_or_404(TicketTravaux, pk=pk)
    if request.method == 'POST':
        ticket.delete()
        return redirect('registre:tickets')
    return render(request, 'registre/supprimer_ticket.html', {'ticket': ticket})

@login_required
def nouveau_document(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk, actif=True)
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES, etab_pk=etab_pk)
        if form.is_valid():
            fichiers = request.FILES.getlist('fichier')
            if not fichiers:
                fichiers = [form.cleaned_data.get('fichier')]

            for fichier in fichiers:
                if not fichier:
                    continue
                doc = form.save(commit=False)
                doc.pk = None  # Créer un nouvel objet pour chaque fichier
                doc.fichier = fichier
                if not doc.nom_fichier or len(fichiers) > 1:
                    doc.nom_fichier = fichier.name
                doc.depose_par = request.user
                doc.save()
                _notifier_nouveau_document(doc, etab, request.user)

            return redirect('registre:detail_etablissement', pk=etab_pk)
    else:
        form = DocumentForm(etab_pk=etab_pk)
    return render(request, 'registre/nouveau_document.html', {
        'form': form,
        'etab': etab,
    })


def _notifier_nouveau_document(doc, etab, depose_par):
    """Envoie un email de notification aux responsables lors de l'import d'un document."""
    from django.core.mail import send_mail
    from django.conf import settings as dj_settings
    try:
        # Destinataires : responsables_securite et admins actifs
        destinataires = list(
            Utilisateur.objects.filter(
                role__in=('admin', 'responsable_securite'),
                is_active=True,
                email__isnull=False,
            ).exclude(email='').values_list('email', flat=True).distinct()
        )
        if not destinataires:
            return
        base_url = getattr(dj_settings, 'BASE_URL', 'https://psm2s.pbci-conseils.fr')
        deposant = depose_par.get_full_name() or depose_par.username
        type_doc = doc.get_type_doc_display() if hasattr(doc, 'get_type_doc_display') else ''
        sujet = f"[PSM2S] Nouveau document importé — {etab.code}"
        message = f"""Un nouveau document a été importé dans PSM2S.

Établissement : {etab.nom} ({etab.code})
Document      : {doc.nom_fichier}
Type          : {type_doc}
Importé par   : {deposant}

Connectez-vous sur {base_url}/etablissement/{etab.pk}/ pour consulter ce document.

—
PSM2S Sécurité – ADPEP28
"""
        send_mail(
            sujet,
            message,
            dj_settings.DEFAULT_FROM_EMAIL,
            destinataires,
            fail_silently=True,
        )
    except Exception:
        pass


@login_required
def supprimer_document(request, pk):
    doc = get_object_or_404(Document, pk=pk)
    etab = doc.controle.etablissement if doc.controle else None
    etab_pk = etab.pk if etab else None
    if request.method == 'POST':
        if doc.fichier:
            try:
                doc.fichier.delete(save=False)
            except Exception:
                pass
        doc.delete()
        if etab_pk:
            return redirect('registre:detail_etablissement', pk=etab_pk)
        return redirect('registre:dashboard')
    return render(request, 'registre/supprimer_document.html', {
        'doc': doc,
        'etab': etab,
    })


@login_required
def modifier_document(request, pk):
    doc = get_object_or_404(Document, pk=pk)
    etab = doc.controle.etablissement if doc.controle else None
    etab_pk = etab.pk if etab else None
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES, instance=doc, etab_pk=etab_pk)
        if form.is_valid():
            form.save()
            if etab_pk:
                return redirect('registre:detail_etablissement', pk=etab_pk)
            return redirect('registre:dashboard')
    else:
        form = DocumentForm(instance=doc, etab_pk=etab_pk)
    return render(request, 'registre/modifier_document.html', {
        'form': form,
        'doc': doc,
        'etab': etab,
    })


@login_required
def registre_pdf(request, pk):
    etab = get_object_or_404(Etablissement, pk=pk, actif=True)

    # Bâtiment optionnel — si ?batiment=X, registre filtré par bâtiment
    batiment_pk = request.GET.get('batiment')
    batiment = None
    if batiment_pk:
        batiment = get_object_or_404(Batiment, pk=batiment_pk, etablissement=etab)

    # Sélection de l'année — par défaut année courante
    annee_courante = timezone.now().year
    try:
        annee = int(request.GET.get('annee', annee_courante))
    except (ValueError, TypeError):
        annee = annee_courante

    # Années disponibles pour le sélecteur dans le PDF
    # Inclut : années avec réalisations + années issues des date_realisation importées
    annees_realisations = set(RealisationControle.annees_disponibles(etab))
    annees_importees = set(
        ControleEtablissement.objects
        .filter(etablissement=etab, date_realisation__isnull=False)
        .values_list('date_realisation__year', flat=True)
        .distinct()
    )
    annees_dispo = sorted(annees_realisations | annees_importees | {annee_courante}, reverse=True)

    controles_qs = ControleEtablissement.objects.filter(etablissement=etab)
    if batiment:
        # Contrôles du bâtiment + contrôles sans bâtiment (communs à tout l'établissement)
        from django.db.models import Q
        controles_qs = controles_qs.filter(Q(batiment=batiment) | Q(batiment__isnull=True))

    controles = (
        controles_qs
        .select_related('type_controle')
        .order_by('type_controle__categorie', 'type_controle__nom')
    )

    # Réalisations de l'année sélectionnée indexées par controle_id
    realisations_annee = {
        r.controle_id: r
        for r in RealisationControle.objects.filter(
            controle__etablissement=etab,
            annee=annee,
        ).order_by('-date_realisation')
    }

    # Groupement par catégorie
    categories_map = {}
    for c in controles:
        cat_key = c.type_controle.categorie
        if cat_key not in categories_map:
            categories_map[cat_key] = {
                'label': c.type_controle.get_categorie_display(),
                'controles': [],
            }
        c.realisation_annee = realisations_annee.get(c.pk)
        categories_map[cat_key]['controles'].append(c)

    documents = Document.objects.filter(
        controle__etablissement=etab
    ).select_related('controle__type_controle').order_by('controle__type_controle__categorie', '-date_depot')

    # Stats basées sur les réalisations de l'année sélectionnée
    nb_fait    = sum(1 for c in controles if realisations_annee.get(c.pk) and realisations_annee[c.pk].statut == 'fait')
    nb_a_faire = sum(1 for c in controles if not realisations_annee.get(c.pk) and c.statut not in ('pas_obligation', 'non_concerne'))
    nb_retard  = sum(1 for c in controles if c.est_en_retard and annee == annee_courante)

    context = {
        'etab': etab,
        'batiment': batiment,
        'categories': list(categories_map.values()),
        'documents': documents,
        'today': timezone.now().date(),
        'annee': annee,
        'annee_courante': annee_courante,
        'annees_dispo': annees_dispo,
        'nb_fait': nb_fait,
        'nb_retard': nb_retard,
        'nb_a_faire': nb_a_faire,
    }
    return render(request, 'registre/registre_pdf.html', context)


# ─────────────────────────────────────────────
#  ADMINISTRATION PSM2S
# ─────────────────────────────────────────────

@admin_requis
def administration(request):
    from django.contrib.auth import get_user_model
    User = get_user_model()
    context = {
        'nb_utilisateurs':     User.objects.filter(is_active=True).count(),
        'nb_groupes':          Group.objects.count(),
        'nb_types_controle':   TypeControleModel.objects.count(),
        'nb_periodicites':     Periodicite.objects.filter(actif=True).count(),
    }
    return render(request, 'registre/administration.html', context)


# ── Groupes ───────────────────────────────────────────────────────────────

@admin_requis
def liste_groupes(request):
    groupes = Group.objects.prefetch_related('user_set').order_by('name')
    return render(request, 'registre/admin_groupes.html', {'groupes': groupes})

@admin_requis
def nouveau_groupe(request):
    if request.method == 'POST':
        form = GroupeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('registre:liste_groupes')
    else:
        form = GroupeForm()
    return render(request, 'registre/admin_groupe_form.html', {'form': form, 'mode': 'nouveau'})

@admin_requis
def modifier_groupe(request, pk):
    groupe = get_object_or_404(Group, pk=pk)
    if request.method == 'POST':
        form = GroupeForm(request.POST, instance=groupe)
        if form.is_valid():
            form.save()
            return redirect('registre:liste_groupes')
    else:
        form = GroupeForm(instance=groupe)
    membres = groupe.user_set.all()
    return render(request, 'registre/admin_groupe_form.html', {
        'form': form, 'groupe': groupe, 'mode': 'modifier', 'membres': membres
    })

@admin_requis
def supprimer_groupe(request, pk):
    groupe = get_object_or_404(Group, pk=pk)
    if request.method == 'POST':
        groupe.delete()
        return redirect('registre:liste_groupes')
    return render(request, 'registre/admin_groupe_supprimer.html', {'groupe': groupe})


# ── Utilisateurs ──────────────────────────────────────────────────────────

@acces_requis('admin', 'responsable_securite', 'directeur')
def liste_utilisateurs(request):
    from django.contrib.auth import get_user_model
    User = get_user_model()
    if request.user.est_directeur:
        # Le directeur voit uniquement les utilisateurs de ses établissements
        etab_ids = EtablissementUtilisateur.objects.filter(
            utilisateur=request.user
        ).values_list('etablissement_id', flat=True)
        utilisateurs = User.objects.filter(
            etablissements__etablissement_id__in=etab_ids
        ).distinct().prefetch_related('groups').order_by('last_name', 'first_name')
    else:
        utilisateurs = User.objects.prefetch_related('groups').order_by('last_name', 'first_name')
    return render(request, 'registre/admin_utilisateurs.html', {
        'utilisateurs': utilisateurs,
        'NIVEAU_CHOICES': Utilisateur.NIVEAU_FACTOTUM_CHOICES,
    })

@acces_requis('admin', 'responsable_securite', 'directeur')
def modifier_niveau_factotum(request, pk):
    from django.contrib.auth import get_user_model
    User = get_user_model()
    utilisateur = get_object_or_404(User, pk=pk, role='factotum')
    if request.method == 'POST':
        niveau = request.POST.get('niveau_factotum')
        if niveau and niveau.isdigit() and 1 <= int(niveau) <= 4:
            utilisateur.niveau_factotum = int(niveau)
            utilisateur.save(update_fields=['niveau_factotum'])
    return redirect('registre:liste_utilisateurs')

@acces_requis('admin', 'responsable_securite', 'directeur')
def nouvel_utilisateur(request):
    from .models import EtablissementUtilisateur, Etablissement as Etab
    if request.user.est_directeur:
        etab_ids = EtablissementUtilisateur.objects.filter(
            utilisateur=request.user
        ).values_list('etablissement_id', flat=True)
        etablissements = Etab.objects.filter(pk__in=etab_ids, actif=True).order_by('code')
    else:
        etablissements = Etab.objects.filter(actif=True).order_by('code')
    if request.method == 'POST':
        form = UtilisateurForm(request.POST, directeur=request.user.est_directeur)
        if form.is_valid():
            utilisateur = form.save()
            _sauvegarder_rattachements(utilisateur, request.POST)
            return redirect('registre:liste_utilisateurs')
    else:
        form = UtilisateurForm(directeur=request.user.est_directeur)
    return render(request, 'registre/admin_utilisateur_form.html', {
        'form': form, 'mode': 'nouveau',
        'etablissements': etablissements,
        'rattachements_ids': [], 'principal_id': None,
    })

@acces_requis('admin', 'responsable_securite', 'directeur')
def modifier_utilisateur(request, pk):
    from django.contrib.auth import get_user_model
    from .models import EtablissementUtilisateur, Etablissement as Etab
    User = get_user_model()
    utilisateur = get_object_or_404(User, pk=pk)
    if request.user.est_directeur:
        etab_ids = EtablissementUtilisateur.objects.filter(
            utilisateur=request.user
        ).values_list('etablissement_id', flat=True)
        etablissements = Etab.objects.filter(pk__in=etab_ids, actif=True).order_by('code')
    else:
        etablissements = Etab.objects.filter(actif=True).order_by('code')
    peut_definir_niveau = request.user.est_responsable or request.user.est_directeur
    if request.method == 'POST':
        form = UtilisateurForm(request.POST, instance=utilisateur, directeur=request.user.est_directeur)
        if form.is_valid():
            utilisateur_sauve = form.save()
            # Niveau factotum — modifiable uniquement par directeur / responsable
            if peut_definir_niveau and utilisateur_sauve.role == 'factotum':
                niveau = request.POST.get('niveau_factotum')
                if niveau and niveau.isdigit() and 1 <= int(niveau) <= 4:
                    utilisateur_sauve.niveau_factotum = int(niveau)
                    utilisateur_sauve.save(update_fields=['niveau_factotum'])
            _sauvegarder_rattachements(utilisateur, request.POST)
            return redirect('registre:liste_utilisateurs')
    else:
        form = UtilisateurForm(instance=utilisateur, directeur=request.user.est_directeur)
    rattachements = EtablissementUtilisateur.objects.filter(utilisateur=utilisateur)
    rattachements_ids = [r.etablissement_id for r in rattachements]
    principal = rattachements.filter(principal=True).first()
    principal_id = principal.etablissement_id if principal else None
    return render(request, 'registre/admin_utilisateur_form.html', {
        'form': form, 'utilisateur': utilisateur, 'mode': 'modifier',
        'etablissements': etablissements,
        'rattachements_ids': rattachements_ids,
        'principal_id': principal_id,
        'peut_definir_niveau': peut_definir_niveau,
        'NIVEAU_CHOICES': utilisateur.NIVEAU_FACTOTUM_CHOICES,
    })

def _sauvegarder_rattachements(utilisateur, post_data):
    """Supprime et recrée les rattachements établissement/utilisateur depuis les données POST."""
    from .models import EtablissementUtilisateur
    etab_ids = post_data.getlist('rattachements')
    principal_id = post_data.get('principal')
    EtablissementUtilisateur.objects.filter(utilisateur=utilisateur).delete()
    for etab_id in etab_ids:
        EtablissementUtilisateur.objects.create(
            utilisateur=utilisateur,
            etablissement_id=etab_id,
            principal=(str(etab_id) == str(principal_id)),
        )

@admin_requis
def supprimer_utilisateur(request, pk):
    from django.contrib.auth import get_user_model
    User = get_user_model()
    utilisateur = get_object_or_404(User, pk=pk)
    if utilisateur == request.user:
        return redirect('registre:liste_utilisateurs')
    if request.method == 'POST':
        utilisateur.delete()
        return redirect('registre:liste_utilisateurs')
    return render(request, 'registre/admin_utilisateur_supprimer.html', {'utilisateur': utilisateur})


# ── Types de contrôle ─────────────────────────────────────────────────────

@gestionnaire_requis
def liste_types_controle(request):
    types = TypeControleModel.objects.order_by('categorie', 'nom')
    return render(request, 'registre/admin_types_controle.html', {'types': types})

@gestionnaire_requis
def nouveau_type_controle(request):
    if request.method == 'POST':
        form = TypeControleForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('registre:liste_types_controle')
    else:
        form = TypeControleForm()
    return render(request, 'registre/admin_type_controle_form.html', {'form': form, 'mode': 'nouveau'})

@gestionnaire_requis
def modifier_type_controle(request, pk):
    tc = get_object_or_404(TypeControleModel, pk=pk)
    if request.method == 'POST':
        form = TypeControleForm(request.POST, instance=tc)
        if form.is_valid():
            form.save()
            return redirect('registre:liste_types_controle')
    else:
        form = TypeControleForm(instance=tc)
    return render(request, 'registre/admin_type_controle_form.html', {'form': form, 'tc': tc, 'mode': 'modifier'})


# ── Périodicités ──────────────────────────────────────────────────────────────

@admin_requis
def liste_periodicites(request):
    periodicites = Periodicite.objects.order_by('nb_jours')
    return render(request, 'registre/admin_periodicites.html', {'periodicites': periodicites})

@admin_requis
def nouvelle_periodicite(request):
    if request.method == 'POST':
        form = PeriodiciteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('registre:liste_periodicites')
    else:
        form = PeriodiciteForm()
    return render(request, 'registre/admin_periodicite_form.html', {'form': form, 'mode': 'nouveau'})

@admin_requis
def modifier_periodicite(request, pk):
    periodicite = get_object_or_404(Periodicite, pk=pk)
    if request.method == 'POST':
        form = PeriodiciteForm(request.POST, instance=periodicite)
        if form.is_valid():
            form.save()
            return redirect('registre:liste_periodicites')
    else:
        form = PeriodiciteForm(instance=periodicite)
    return render(request, 'registre/admin_periodicite_form.html', {
        'form': form, 'periodicite': periodicite, 'mode': 'modifier'
    })

@admin_requis
def supprimer_periodicite(request, pk):
    periodicite = get_object_or_404(Periodicite, pk=pk)
    if request.method == 'POST':
        if periodicite.types_controle.exists():
            nb = periodicite.types_controle.count()
            return render(request, 'registre/admin_periodicite_supprimer.html', {
                'periodicite': periodicite,
                'erreur': f"Impossible : {nb} type(s) de contrôle utilisent cette périodicité.",
            })
        periodicite.delete()
        return redirect('registre:liste_periodicites')
    return render(request, 'registre/admin_periodicite_supprimer.html', {'periodicite': periodicite})






# ─────────────────────────────────────────────
#  TABLEAU DE BORD MULTI-SITES
# ─────────────────────────────────────────────

@acces_requis('admin', 'responsable_securite')
def tableau_de_bord(request):
    """
    Tableau de bord multi-sites — vue consolidée du patrimoine ADPEP28.
    """
    from datetime import timedelta
    today = timezone.now().date()
    filtre = request.GET.get('filtre', 'tous')

    etablissements = (
        Etablissement.objects.filter(actif=True)
        .prefetch_related('controles__type_controle', 'tickets')
        .order_by('nom')
    )

    etab_data = []
    total_conformes = total_a_faire = total_en_retard = 0
    total_prescriptions_ouvertes = total_contrats_expirants = 0
    total_controles_a_jour = total_non_renseignes = 0

    # Statistiques par catégorie
    stats_categories = {}

    # Alertes urgentes (retards + échéances proches < 7 jours)
    alertes = []

    for etab in etablissements:
        controles = list(etab.controles.select_related('type_controle').all())
        controles_actifs = [c for c in controles if c.statut not in ('pas_obligation', 'non_concerne')]

        nb_total  = len(controles_actifs)
        nb_retard = sum(1 for c in controles_actifs if c.est_en_retard)
        nb_a_faire= sum(1 for c in controles_actifs if c.statut in ('a_faire', 'a_remettre_a_jour') and not c.est_en_retard)
        nb_fait   = sum(1 for c in controles_actifs if c.statut == 'fait' and not c.est_en_retard)
        nb_non_renseigne = sum(1 for c in controles_actifs if not c.prochaine_echeance and c.statut != 'fait')
        tickets_ouverts = etab.tickets.exclude(statut='cloture').count()

        # Prochain contrôle le plus urgent
        prochains = [c for c in controles_actifs if c.prochaine_echeance and not c.est_en_retard]
        prochain = min(prochains, key=lambda c: c.prochaine_echeance) if prochains else None

        # Prescriptions ouvertes
        prescriptions_ouvertes = Prescription.objects.filter(
            visite__etablissement=etab, statut='en_cours'
        ).count()

        # Contrats expirants
        contrats_expirants = Contrat.objects.filter(
            etablissement=etab,
            date_fin__isnull=False,
            date_fin__lte=today + timedelta(days=60),
            date_fin__gte=today,
        ).count()

        # Statut global
        if nb_retard:
            statut = 'red'
        elif nb_a_faire:
            statut = 'amber'
        else:
            statut = 'green'

        taux = round(nb_fait * 100 / nb_total) if nb_total else 0

        # Alertes urgentes : contrôles en retard
        for c in controles_actifs:
            if c.est_en_retard and c.prochaine_echeance:
                jours = (today - c.prochaine_echeance).days
                alertes.append({
                    'type': 'retard',
                    'texte': c.type_controle.nom,
                    'etab': etab.code,
                    'jours': jours,
                    'urgence': 0,
                })
            elif c.prochaine_echeance and 0 <= (c.prochaine_echeance - today).days <= 7:
                jours = (c.prochaine_echeance - today).days
                alertes.append({
                    'type': 'proche',
                    'texte': c.type_controle.nom,
                    'etab': etab.code,
                    'jours': jours,
                    'urgence': 1,
                })

        # Contrats expirant bientôt
        for contrat in Contrat.objects.filter(
            etablissement=etab,
            date_fin__isnull=False,
            date_fin__lte=today + timedelta(days=30),
            date_fin__gte=today,
        ).select_related('type_controle'):
            alertes.append({
                'type': 'contrat',
                'texte': f"Contrat {contrat.prestataire}" + (f" — {contrat.type_controle.nom}" if contrat.type_controle else ""),
                'etab': etab.code,
                'jours': (contrat.date_fin - today).days,
                'urgence': 2,
            })

        # Stats par catégorie
        for c in controles_actifs:
            cat = c.type_controle.get_categorie_display()
            cat_key = c.type_controle.categorie
            if cat_key not in stats_categories:
                stats_categories[cat_key] = {'label': cat, 'fait': 0, 'total': 0}
            stats_categories[cat_key]['total'] += 1
            if c.statut == 'fait' and not c.est_en_retard:
                stats_categories[cat_key]['fait'] += 1

        etab_data.append({
            'etab': etab,
            'statut': statut,
            'nb_total': nb_total,
            'nb_fait': nb_fait,
            'nb_retard': nb_retard,
            'nb_a_faire': nb_a_faire,
            'tickets_ouverts': tickets_ouverts,
            'prescriptions_ouvertes': prescriptions_ouvertes,
            'contrats_expirants': contrats_expirants,
            'prochain': prochain,
            'taux': taux,
            'nb_non_renseigne': nb_non_renseigne,
        })

        if nb_retard:
            total_en_retard += 1
        elif nb_a_faire:
            total_a_faire += 1
        else:
            total_conformes += 1
        total_prescriptions_ouvertes += prescriptions_ouvertes
        total_contrats_expirants += contrats_expirants
        total_controles_a_jour += nb_fait
        total_non_renseignes += nb_non_renseigne

    # Score global
    total_etabs = len(etab_data)
    score_global = round(total_conformes * 100 / total_etabs) if total_etabs else 0

    # Trier alertes par urgence puis jours
    alertes.sort(key=lambda a: (a['urgence'], -a.get('jours', 0) if a['type'] == 'retard' else a.get('jours', 0)))
    alertes = alertes[:6]

    # Trier établissements par urgence
    ordre = {'red': 0, 'amber': 1, 'green': 2}
    etab_data.sort(key=lambda e: (ordre[e['statut']], -e['nb_retard']))

    # Filtres
    if filtre == 'retard':
        etab_data_filtre = [e for e in etab_data if e['statut'] == 'red']
    elif filtre == 'prescriptions':
        etab_data_filtre = [e for e in etab_data if e['prescriptions_ouvertes'] > 0]
    elif filtre == 'contrats':
        etab_data_filtre = [e for e in etab_data if e['contrats_expirants'] > 0]
    else:
        etab_data_filtre = etab_data

    # Stats catégories triées par taux croissant
    cats = []
    for key, v in stats_categories.items():
        taux = round(v['fait'] * 100 / v['total']) if v['total'] else 0
        cats.append({'label': v['label'], 'taux': taux, 'fait': v['fait'], 'total': v['total']})
    cats.sort(key=lambda c: c['taux'])

    # Données pour la vue opérationnelle
    qs_retard = (
        ControleEtablissement.objects
        .filter(prochaine_echeance__lt=today)
        .exclude(statut__in=('fait', 'pas_obligation', 'non_concerne'))
        .select_related('type_controle', 'etablissement')
        .order_by('prochaine_echeance')
    )
    controles_retard = [
        {'controle': c, 'jours': (today - c.prochaine_echeance).days}
        for c in qs_retard
    ]

    qs_ech = (
        ControleEtablissement.objects
        .filter(prochaine_echeance__gte=today, prochaine_echeance__lte=today + timedelta(days=30))
        .exclude(statut__in=('fait', 'pas_obligation', 'non_concerne'))
        .select_related('type_controle', 'etablissement')
        .order_by('prochaine_echeance')
    )
    echeances_30j = [
        {'controle': c, 'jours': (c.prochaine_echeance - today).days}
        for c in qs_ech
    ]

    tickets_urgents_tdb = (
        TicketTravaux.objects
        .filter(priorite__in=('critique', 'urgent'))
        .exclude(statut='cloture')
        .select_related('etablissement')
        .order_by('priorite', '-date_creation')
    )

    from django.conf import settings as django_settings
    context = {
        'NOM_ORGANISATION': getattr(django_settings, 'NOM_ORGANISATION', ''),
        'etab_data': etab_data_filtre,
        'filtre': filtre,
        'total_etabs': total_etabs,
        'total_conformes': total_conformes,
        'total_a_faire': total_a_faire,
        'total_en_retard': total_en_retard,
        'total_prescriptions_ouvertes': total_prescriptions_ouvertes,
        'total_contrats_expirants': total_contrats_expirants,
        'score_global': score_global,
        'alertes': alertes,
        'categories': cats,
        'today': today,
        'total_controles_a_jour': total_controles_a_jour,
        'total_non_renseignes': total_non_renseignes,
        'controles_retard': controles_retard,
        'echeances_30j': echeances_30j,
        'tickets_urgents_tdb': tickets_urgents_tdb,
    }
    return render(request, 'registre/tableau_de_bord.html', context)


# ─────────────────────────────────────────────
#  CONTRATS PRESTATAIRES
# ─────────────────────────────────────────────

@gestionnaire_requis
def nouveau_contrat(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk, actif=True)
    if request.method == 'POST':
        form = ContratForm(request.POST, request.FILES, etab_pk=etab_pk)
        if form.is_valid():
            contrat = form.save(commit=False)
            contrat.etablissement = etab
            contrat.cree_par = request.user
            contrat.save()
            return redirect('registre:detail_etablissement', pk=etab_pk)
    else:
        form = ContratForm(etab_pk=etab_pk)
    return render(request, 'registre/contrat_form.html', {
        'form': form, 'etab': etab, 'mode': 'nouveau',
    })

@gestionnaire_requis
def modifier_contrat(request, pk):
    contrat = get_object_or_404(Contrat, pk=pk)
    etab = contrat.etablissement
    if request.method == 'POST':
        form = ContratForm(request.POST, request.FILES, instance=contrat, etab_pk=etab.pk)
        if form.is_valid():
            form.save()
            return redirect('registre:detail_etablissement', pk=etab.pk)
    else:
        form = ContratForm(instance=contrat, etab_pk=etab.pk)
    return render(request, 'registre/contrat_form.html', {
        'form': form, 'etab': etab, 'contrat': contrat, 'mode': 'modifier',
    })

@gestionnaire_requis
def supprimer_contrat(request, pk):
    contrat = get_object_or_404(Contrat, pk=pk)
    etab_pk = contrat.etablissement_id
    if request.method == 'POST':
        if contrat.document:
            try:
                contrat.document.delete(save=False)
            except Exception:
                pass
        contrat.delete()
        return redirect('registre:detail_etablissement', pk=etab_pk)
    return render(request, 'registre/contrat_supprimer.html', {'contrat': contrat})


# ─────────────────────────────────────────────
#  INTERVENTIONS
# ─────────────────────────────────────────────

@factotum_niveau_requis(2)
def modifier_intervention(request, pk):
    interv = get_object_or_404(Intervention, pk=pk)
    from .forms import InterventionEditForm
    if request.method == 'POST':
        form = InterventionEditForm(request.POST, instance=interv)
        if form.is_valid():
            interv = form.save()
            if interv.statut == 'realisee':
                ticket = TicketTravaux.objects.filter(pk=interv.ticket_id).first()
                if ticket and ticket.statut not in ('controle_realise', 'cloture'):
                    ticket.statut = 'controle_realise'
                    ticket.save()
            return redirect('registre:interventions')
    else:
        form = InterventionEditForm(instance=interv)
    return render(request, 'registre/modifier_intervention.html', {
        'form': form,
        'interv': interv,
    })

@factotum_niveau_requis(2)
def nouvelle_intervention(request):
    from .forms import InterventionForm
    if request.method == 'POST':
        form = InterventionForm(request.POST)
        if form.is_valid():
            interv = form.save(commit=False)
            interv.saisie_par = request.user
            interv.save()
            return redirect('registre:interventions')
    else:
        ticket_pk = request.GET.get('ticket')
        form = InterventionForm(initial={'ticket': ticket_pk} if ticket_pk else {})
    return render(request, 'registre/nouvelle_intervention.html', {'form': form})

@login_required
def interventions(request):
    today = timezone.now().date()
    etab_ids = _get_etab_ids_autorises(request.user)

    qs_a_venir = Intervention.objects.filter(
        statut='planifiee', date_intervention__gte=today
    ).select_related('ticket__etablissement').order_by('date_intervention')

    qs_realisees = Intervention.objects.filter(
        statut='realisee'
    ).select_related('ticket__etablissement').order_by('-date_intervention')

    qs_urgentes = TicketTravaux.objects.filter(priorite='critique').exclude(statut='cloture')

    if etab_ids is not None:
        qs_a_venir   = qs_a_venir.filter(ticket__etablissement_id__in=etab_ids)
        qs_realisees = qs_realisees.filter(ticket__etablissement_id__in=etab_ids)
        qs_urgentes  = qs_urgentes.filter(etablissement_id__in=etab_ids)

    context = {
        'a_venir': qs_a_venir,
        'realisees': qs_realisees[:20],
        'nb_urgentes': qs_urgentes.count(),
    }
    return render(request, 'registre/interventions.html', context)


# ─────────────────────────────────────────────
#  CARNET SANITAIRE EAU
# ─────────────────────────────────────────────

@login_required
def carnet_eau(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk, actif=True)
    reseaux = ReseauEau.objects.filter(
        etablissement=etab, actif=True
    ).prefetch_related('points__analyses').order_by('type_reseau')
    return render(request, 'registre/eau_carnet.html', {
        'etab': etab,
        'reseaux': reseaux,
    })


@gestionnaire_requis
def nouveau_reseau_eau(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk, actif=True)
    if request.method == 'POST':
        form = ReseauEauForm(request.POST)
        if form.is_valid():
            reseau = form.save(commit=False)
            reseau.etablissement = etab
            reseau.save()
            return redirect('registre:carnet_eau', etab_pk=etab_pk)
    else:
        form = ReseauEauForm()
    return render(request, 'registre/eau_reseau_form.html', {
        'form': form, 'etab': etab,
    })


@gestionnaire_requis
def nouveau_point_prelevement(request, reseau_pk):
    reseau = get_object_or_404(ReseauEau, pk=reseau_pk)
    etab = reseau.etablissement
    if request.method == 'POST':
        form = PointPrelevementForm(request.POST)
        if form.is_valid():
            point = form.save(commit=False)
            point.reseau = reseau
            point.save()
            return redirect('registre:carnet_eau', etab_pk=etab.pk)
    else:
        form = PointPrelevementForm()
    return render(request, 'registre/eau_point_form.html', {
        'form': form, 'reseau': reseau, 'etab': etab,
    })


@login_required
def nouvelle_analyse_eau(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk, actif=True)
    if request.method == 'POST':
        form = AnalyseEauForm(request.POST, request.FILES, etab_pk=etab_pk)
        if form.is_valid():
            analyse = form.save(commit=False)
            analyse.saisie_par = request.user
            analyse.save()
            return redirect('registre:carnet_eau', etab_pk=etab_pk)
    else:
        form = AnalyseEauForm(etab_pk=etab_pk)
    return render(request, 'registre/eau_analyse_form.html', {
        'form': form, 'etab': etab, 'mode': 'nouveau',
    })


@login_required
def modifier_analyse_eau(request, pk):
    analyse = get_object_or_404(AnalyseEau, pk=pk)
    etab = analyse.point.reseau.etablissement
    if request.method == 'POST':
        form = AnalyseEauForm(request.POST, request.FILES, instance=analyse, etab_pk=etab.pk)
        if form.is_valid():
            form.save()
            return redirect('registre:carnet_eau', etab_pk=etab.pk)
    else:
        form = AnalyseEauForm(instance=analyse, etab_pk=etab.pk)
    return render(request, 'registre/eau_analyse_form.html', {
        'form': form, 'etab': etab, 'analyse': analyse, 'mode': 'modifier',
    })


@gestionnaire_requis
def supprimer_analyse_eau(request, pk):
    analyse = get_object_or_404(AnalyseEau, pk=pk)
    etab = analyse.point.reseau.etablissement
    if request.method == 'POST':
        if analyse.document:
            try:
                analyse.document.delete(save=False)
            except Exception:
                pass
        analyse.delete()
        return redirect('registre:carnet_eau', etab_pk=etab.pk)
    return render(request, 'registre/eau_analyse_supprimer.html', {
        'analyse': analyse, 'etab': etab,
    })


# ─────────────────────────────────────────────
#  COMMISSIONS DE SECURITE
# ─────────────────────────────────────────────

@gestionnaire_requis
def nouvelle_visite_commission(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk, actif=True)
    if request.method == 'POST':
        form = VisiteCommissionForm(request.POST, request.FILES)
        if form.is_valid():
            visite = form.save(commit=False)
            visite.etablissement = etab
            visite.cree_par = request.user
            visite.save()
            return redirect('registre:detail_visite_commission', pk=visite.pk)
    else:
        form = VisiteCommissionForm()
    return render(request, 'registre/commission_visite_form.html', {
        'form': form, 'etab': etab, 'mode': 'nouveau',
    })


@login_required
def detail_visite_commission(request, pk):
    visite = get_object_or_404(VisiteCommission, pk=pk)
    etab = visite.etablissement
    prescriptions = visite.prescriptions.prefetch_related(
        'actions'
    ).order_by('numero', 'date_creation')
    return render(request, 'registre/commission_detail.html', {
        'visite': visite,
        'etab': etab,
        'prescriptions': prescriptions,
    })


@gestionnaire_requis
def modifier_visite_commission(request, pk):
    visite = get_object_or_404(VisiteCommission, pk=pk)
    etab = visite.etablissement
    if request.method == 'POST':
        form = VisiteCommissionForm(request.POST, request.FILES, instance=visite)
        if form.is_valid():
            form.save()
            return redirect('registre:detail_visite_commission', pk=pk)
    else:
        form = VisiteCommissionForm(instance=visite)
    return render(request, 'registre/commission_visite_form.html', {
        'form': form, 'etab': etab, 'visite': visite, 'mode': 'modifier',
    })


@admin_requis
def supprimer_visite_commission(request, pk):
    visite = get_object_or_404(VisiteCommission, pk=pk)
    etab_pk = visite.etablissement_id
    if request.method == 'POST':
        if visite.document_pv:
            try:
                visite.document_pv.delete(save=False)
            except Exception:
                pass
        visite.delete()
        return redirect('registre:detail_etablissement', pk=etab_pk)
    return render(request, 'registre/commission_visite_supprimer.html', {'visite': visite})


@gestionnaire_requis
def nouvelle_prescription(request, visite_pk):
    visite = get_object_or_404(VisiteCommission, pk=visite_pk)
    etab = visite.etablissement
    if request.method == 'POST':
        form = PrescriptionForm(request.POST, etab_pk=etab.pk)
        if form.is_valid():
            prescription = form.save(commit=False)
            prescription.visite = visite
            prescription.save()
            return redirect('registre:detail_visite_commission', pk=visite_pk)
    else:
        form = PrescriptionForm(etab_pk=etab.pk)
    return render(request, 'registre/commission_prescription_form.html', {
        'form': form, 'visite': visite, 'etab': etab, 'mode': 'nouveau',
    })


@gestionnaire_requis
def modifier_prescription(request, pk):
    prescription = get_object_or_404(Prescription, pk=pk)
    visite = prescription.visite
    etab = visite.etablissement
    if request.method == 'POST':
        form = PrescriptionForm(request.POST, instance=prescription, etab_pk=etab.pk)
        if form.is_valid():
            form.save()
            return redirect('registre:detail_visite_commission', pk=visite.pk)
    else:
        form = PrescriptionForm(instance=prescription, etab_pk=etab.pk)
    return render(request, 'registre/commission_prescription_form.html', {
        'form': form, 'visite': visite, 'etab': etab,
        'prescription': prescription, 'mode': 'modifier',
    })


@login_required
def nouvelle_action_prescription(request, prescription_pk):
    prescription = get_object_or_404(Prescription, pk=prescription_pk)
    visite = prescription.visite
    if request.method == 'POST':
        form = ActionPrescriptionForm(request.POST, request.FILES)
        if form.is_valid():
            action = form.save(commit=False)
            action.prescription = prescription
            action.saisie_par = request.user
            action.save()
            return redirect('registre:detail_visite_commission', pk=visite.pk)
    else:
        form = ActionPrescriptionForm()
    return render(request, 'registre/commission_action_form.html', {
        'form': form, 'prescription': prescription,
        'visite': visite, 'etab': visite.etablissement,
    })


@gestionnaire_requis
def supprimer_action_prescription(request, pk):
    action = get_object_or_404(ActionPrescription, pk=pk)
    visite_pk = action.prescription.visite_id
    if request.method == 'POST':
        if action.document:
            try:
                action.document.delete(save=False)
            except Exception:
                pass
        action.delete()
        return redirect('registre:detail_visite_commission', pk=visite_pk)
    return render(request, 'registre/commission_action_supprimer.html', {'action': action})


# ─────────────────────────────────────────────
#  MODULE DUERP
# ─────────────────────────────────────────────

from .models import (
    DUERP, UniteTravail, CategorieRisque, SourceDanger,
    EvaluationRisque, PlanActionDUERP,
)
from django.db import transaction


@login_required
def duerp_liste(request):
    """Liste des DUERP — tous établissements ou filtré."""
    if request.user.peut_tout_voir:
        duerps = DUERP.objects.select_related('etablissement').all()
    else:
        etabs = [eu.etablissement for eu in request.user.etablissements.all()]
        duerps = DUERP.objects.filter(etablissement__in=etabs).select_related('etablissement')
    return render(request, 'registre/duerp_liste.html', {'duerps': duerps})


@login_required
def duerp_nouveau(request, etab_pk):
    """Créer un nouveau DUERP pour un établissement."""
    etab = get_object_or_404(Etablissement, pk=etab_pk)
    annee_courante = timezone.now().year

    if request.method == 'POST':
        annee = int(request.POST.get('annee', annee_courante))
        signataire = request.POST.get('signataire', '')

        if DUERP.objects.filter(etablissement=etab, annee=annee).exists():
            from django.contrib import messages
            messages.error(request, f'Un DUERP {annee} existe déjà pour cet établissement.')
            return redirect('registre:duerp_liste')

        with transaction.atomic():
            duerp = DUERP.objects.create(
                etablissement=etab,
                annee=annee,
                signataire=signataire,
            )
            # Créer les unités de travail par défaut
            types_defaut = [
                ('tertiaire_bureautique', 0),
                ('maintenance_entretien', 1),
                ('internat', 2),
                ('pedagogique', 3),
                ('therapeutique', 4),
                ('abords_immediats', 5),
                ('incendie', 6),
            ]
            for type_unite, ordre in types_defaut:
                unite = UniteTravail.objects.create(
                    duerp=duerp, type_unite=type_unite, ordre=ordre
                )
                # Pré-remplir les évaluations depuis les sources de danger
                for source in SourceDanger.objects.filter(categorie__type_unite=type_unite):
                    EvaluationRisque.objects.create(
                        unite_travail=unite,
                        source_danger=source,
                        risque_potentiel=source.risque_potentiel,
                    )

        return redirect('registre:duerp_detail', pk=duerp.pk)

    return render(request, 'registre/duerp_form.html', {
        'etab': etab,
        'annee_courante': annee_courante,
    })


@login_required
def duerp_detail(request, pk):
    """Vue principale d'un DUERP — liste des unités de travail."""
    duerp = get_object_or_404(DUERP, pk=pk)
    unites = duerp.unites_travail.prefetch_related('evaluations').all()

    # Statistiques par unité
    stats = {}
    for unite in unites:
        evals = unite.evaluations.all()
        presentes = evals.filter(present=True)
        stats[unite.pk] = {
            'total': evals.count(),
            'presentes': presentes.count(),
            'important': presentes.filter(niveau__in=['important', 'tres_important']).count(),
        }

    from .models import DroitSignature
    peut_signer = DroitSignature.peut_signer(request.user, duerp.etablissement, 'duerp')

    return render(request, 'registre/duerp_detail.html', {
        'duerp': duerp,
        'unites': unites,
        'stats': stats,
        'peut_signer': peut_signer,
    })


@login_required
def duerp_checklist(request, unite_pk):
    """Édition de la checklist d'une unité de travail."""
    unite = get_object_or_404(UniteTravail, pk=unite_pk)
    duerp = unite.duerp

    # Regrouper les évaluations par catégorie
    categories = CategorieRisque.objects.filter(
        type_unite=unite.type_unite
    ).prefetch_related('sources_danger__evaluations')

    evaluations_by_source = {
        ev.source_danger_id: ev
        for ev in unite.evaluations.all()
    }

    if request.method == 'POST':
        with transaction.atomic():
            for source in SourceDanger.objects.filter(categorie__type_unite=unite.type_unite):
                ev = evaluations_by_source.get(source.pk)
                if ev is None:
                    ev = EvaluationRisque(unite_travail=unite, source_danger=source)

                ev.present = bool(request.POST.get(f'present_{source.pk}'))
                ev.niveau = request.POST.get(f'niveau_{source.pk}', '')
                ev.observation = request.POST.get(f'observation_{source.pk}', '')
                if not ev.risque_potentiel:
                    ev.risque_potentiel = source.risque_potentiel
                ev.save()

        return redirect('registre:duerp_detail', pk=duerp.pk)

    return render(request, 'registre/duerp_checklist.html', {
        'duerp': duerp,
        'unite': unite,
        'categories': categories,
        'evaluations_by_source': evaluations_by_source,
        'niveau_choices': EvaluationRisque.NIVEAU_CHOICES,
    })


@login_required
def duerp_plan_action(request, pk):
    """Plan d'action global d'un DUERP."""
    duerp = get_object_or_404(DUERP, pk=pk)

    # Risques importants sans action
    risques_sans_action = EvaluationRisque.objects.filter(
        unite_travail__duerp=duerp,
        present=True,
        niveau__in=['important', 'tres_important'],
        actions__isnull=True,
    ).select_related('source_danger', 'unite_travail')

    actions = duerp.plan_actions.select_related(
        'evaluation_risque__source_danger', 'ticket'
    ).all()

    return render(request, 'registre/duerp_plan_action.html', {
        'duerp': duerp,
        'actions': actions,
        'risques_sans_action': risques_sans_action,
    })


@login_required
def duerp_action_creer(request, duerp_pk):
    """Créer une action dans le plan d'action."""
    duerp = get_object_or_404(DUERP, pk=duerp_pk)
    eval_pk = request.GET.get('risque')
    evaluation = get_object_or_404(EvaluationRisque, pk=eval_pk) if eval_pk else None

    if request.method == 'POST':
        PlanActionDUERP.objects.create(
            duerp=duerp,
            evaluation_risque=evaluation,
            description_action=request.POST.get('description_action', ''),
            responsable=request.POST.get('responsable', ''),
            delai=request.POST.get('delai') or None,
            avancement=request.POST.get('avancement', 'a_faire'),
        )
        return redirect('registre:duerp_plan_action', pk=duerp.pk)

    return render(request, 'registre/duerp_action_form.html', {
        'duerp': duerp,
        'evaluation': evaluation,
        'avancement_choices': PlanActionDUERP.AVANCEMENT_CHOICES,
    })


@login_required
def duerp_action_modifier(request, pk):
    """Modifier une action du plan."""
    action = get_object_or_404(PlanActionDUERP, pk=pk)
    duerp = action.duerp

    if request.method == 'POST':
        action.description_action = request.POST.get('description_action', '')
        action.responsable = request.POST.get('responsable', '')
        action.delai = request.POST.get('delai') or None
        action.avancement = request.POST.get('avancement', 'a_faire')
        action.save()
        return redirect('registre:duerp_plan_action', pk=duerp.pk)

    return render(request, 'registre/duerp_action_form.html', {
        'duerp': duerp,
        'action': action,
        'evaluation': action.evaluation_risque,
        'avancement_choices': PlanActionDUERP.AVANCEMENT_CHOICES,
    })


@login_required
def duerp_creer_ticket(request, action_pk):
    """Crée un ticket travaux depuis une action DUERP."""
    action = get_object_or_404(PlanActionDUERP, pk=action_pk)
    duerp = action.duerp

    if not action.ticket:
        ticket = TicketTravaux.objects.create(
            etablissement=duerp.etablissement,
            titre=f"[DUERP {duerp.annee}] {action.description_action[:200]}",
            description=action.description_action,
            priorite='normal',
            cree_par=request.user,
        )
        action.ticket = ticket
        action.save()
        from django.contrib import messages
        messages.success(request, f'Ticket #{ticket.pk} créé et lié à l\'action DUERP.')

    return redirect('registre:duerp_plan_action', pk=duerp.pk)


@login_required
def duerp_modifier(request, pk):
    """Modifier les infos générales d'un DUERP (signataire, statut, observations)."""
    duerp = get_object_or_404(DUERP, pk=pk)

    if request.method == 'POST':
        duerp.signataire = request.POST.get('signataire', '')
        duerp.statut = request.POST.get('statut', 'brouillon')
        duerp.observations_generales = request.POST.get('observations_generales', '')
        date_val = request.POST.get('date_validation', '')
        duerp.date_validation = date_val if date_val else None
        duerp.save()
        return redirect('registre:duerp_detail', pk=duerp.pk)

    return render(request, 'registre/duerp_modifier.html', {
        'duerp': duerp,
        'statut_choices': DUERP.STATUT_CHOICES,
    })


@login_required
def duerp_imprimer(request, pk):
    """Vue impression/PDF du DUERP complet."""
    duerp = get_object_or_404(DUERP, pk=pk)
    unites = duerp.unites_travail.prefetch_related(
        'evaluations__source_danger__categorie'
    ).all()

    # Pour chaque unité, regrouper les évaluations présentes par catégorie
    unites_data = []
    for unite in unites:
        categories = {}
        for ev in unite.evaluations.filter(present=True).order_by(
            'source_danger__categorie__ordre', 'source_danger__ordre'
        ):
            cat_nom = ev.source_danger.categorie.nom
            if cat_nom not in categories:
                categories[cat_nom] = []
            categories[cat_nom].append(ev)
        if categories:
            unites_data.append({'unite': unite, 'categories': categories})

    actions = duerp.plan_actions.select_related(
        'evaluation_risque__source_danger', 'ticket'
    ).all()

    from django.utils import timezone as tz
    from .models import Utilisateur
    etab = duerp.etablissement
    directeur = Utilisateur.objects.filter(
        etablissements__etablissement=etab, role='directeur'
    ).first()
    responsable = Utilisateur.objects.filter(
        etablissements__etablissement=etab, role='responsable_securite'
    ).first()

    return render(request, 'registre/duerp_imprimer.html', {
        'duerp': duerp,
        'unites_data': unites_data,
        'actions': actions,
        'today': tz.now().date(),
        'directeur': directeur,
        'responsable': responsable,
    })


# ─────────────────────────────────────────────
#  MODULE REGISTRE PUBLIC D'ACCESSIBILITÉ
# ─────────────────────────────────────────────

from .models import (
    RegistreAccessibilite, EvaluationZone,
    FormationPersonnel, PieceAdministrative, ActionMiseConformite,
)

ZONES_ORDRE = [
    'stationnement', 'cheminement_ext', 'entree', 'accueil',
    'circulation_horiz', 'circulation_vert', 'sanitaires',
    'equipements', 'eclairage', 'signalétique',
]


def _get_or_create_registre(etab):
    """Crée le registre + les 10 zones si inexistants."""
    registre, created = RegistreAccessibilite.objects.get_or_create(etablissement=etab)
    if created or not registre.evaluations.exists():
        for i, zone in enumerate(ZONES_ORDRE):
            EvaluationZone.objects.get_or_create(
                registre=registre, zone=zone, defaults={'ordre': i}
            )
    return registre


@login_required
def accessibilite_detail(request, etab_pk):
    """Vue principale du registre d'accessibilité d'un établissement."""
    etab = get_object_or_404(Etablissement, pk=etab_pk)
    registre = _get_or_create_registre(etab)
    evaluations = registre.evaluations.order_by('ordre')
    formations  = registre.formations.order_by('-date_formation')
    pieces      = registre.pieces_administratives.order_by('-date_document')
    actions     = registre.actions.order_by('delai_prevu')

    from .models import DroitSignature
    peut_signer = DroitSignature.peut_signer(request.user, etab, 'accessibilite')

    return render(request, 'registre/accessibilite_detail.html', {
        'etab': etab,
        'registre': registre,
        'evaluations': evaluations,
        'formations': formations,
        'pieces': pieces,
        'actions': actions,
        'peut_signer': peut_signer,
    })


@login_required
def accessibilite_grille(request, etab_pk):
    """Édition de la grille d'évaluation par zone et type de handicap."""
    etab = get_object_or_404(Etablissement, pk=etab_pk)
    registre = _get_or_create_registre(etab)
    evaluations = registre.evaluations.order_by('ordre')

    if request.method == 'POST':
        with transaction.atomic():
            for ev in evaluations:
                ev.statut_moteur  = request.POST.get(f'moteur_{ev.pk}', 'so')
                ev.statut_visuel  = request.POST.get(f'visuel_{ev.pk}', 'so')
                ev.statut_auditif = request.POST.get(f'auditif_{ev.pk}', 'so')
                ev.statut_mental  = request.POST.get(f'mental_{ev.pk}', 'so')
                ev.observation    = request.POST.get(f'obs_{ev.pk}', '')
                ev.save()
            registre.observations_generales = request.POST.get('observations_generales', '')
            registre.save()
        return redirect('registre:accessibilite_detail', etab_pk=etab.pk)

    # Enrichir chaque évaluation avec ses données par handicap
    HANDICAPS = [
        ('moteur',  '🦽 Handicap moteur'),
        ('visuel',  '👁 Handicap visuel'),
        ('auditif', '👂 Handicap auditif'),
        ('mental',  '🧠 Mental / Cognitif'),
    ]
    for ev in evaluations:
        ev.handicaps_data = [
            ('moteur',  '🦽 Handicap moteur',    ev.statut_moteur),
            ('visuel',  '👁 Handicap visuel',     ev.statut_visuel),
            ('auditif', '👂 Handicap auditif',    ev.statut_auditif),
            ('mental',  '🧠 Mental / Cognitif',   ev.statut_mental),
        ]

    return render(request, 'registre/accessibilite_grille.html', {
        'etab': etab,
        'registre': registre,
        'evaluations': evaluations,
    })


@login_required
def accessibilite_formation_ajouter(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk)
    registre = _get_or_create_registre(etab)

    if request.method == 'POST':
        FormationPersonnel.objects.create(
            registre=registre,
            type_formation=request.POST.get('type_formation', 'sensibilisation'),
            intitule=request.POST.get('intitule', ''),
            organisme=request.POST.get('organisme', ''),
            date_formation=request.POST.get('date_formation'),
            nb_personnes=int(request.POST.get('nb_personnes', 1)),
            observations=request.POST.get('observations', ''),
        )
        return redirect('registre:accessibilite_detail', etab_pk=etab.pk)

    return render(request, 'registre/accessibilite_formation_form.html', {
        'etab': etab,
        'registre': registre,
        'type_choices': FormationPersonnel.TYPE_CHOICES,
    })


@login_required
def accessibilite_piece_ajouter(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk)
    registre = _get_or_create_registre(etab)

    if request.method == 'POST':
        piece = PieceAdministrative(
            registre=registre,
            type_piece=request.POST.get('type_piece', 'autre'),
            intitule=request.POST.get('intitule', ''),
            observations=request.POST.get('observations', ''),
        )
        date_doc = request.POST.get('date_document', '')
        piece.date_document = date_doc if date_doc else None
        if request.FILES.get('fichier'):
            piece.fichier = request.FILES['fichier']
        piece.save()
        return redirect('registre:accessibilite_detail', etab_pk=etab.pk)

    return render(request, 'registre/accessibilite_piece_form.html', {
        'etab': etab,
        'registre': registre,
        'type_choices': PieceAdministrative.TYPE_CHOICES,
    })


@login_required
def accessibilite_action_ajouter(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk)
    registre = _get_or_create_registre(etab)
    zone_pk = request.GET.get('zone')
    zone = get_object_or_404(EvaluationZone, pk=zone_pk) if zone_pk else None

    if request.method == 'POST':
        action = ActionMiseConformite(
            registre=registre,
            evaluation_zone=zone,
            description=request.POST.get('description', ''),
            responsable=request.POST.get('responsable', ''),
            avancement=request.POST.get('avancement', 'prevu'),
        )
        delai = request.POST.get('delai_prevu', '')
        action.delai_prevu = delai if delai else None
        cout = request.POST.get('cout_estime', '')
        action.cout_estime = cout if cout else None
        action.save()
        return redirect('registre:accessibilite_detail', etab_pk=etab.pk)

    return render(request, 'registre/accessibilite_action_form.html', {
        'etab': etab,
        'registre': registre,
        'zone': zone,
        'avancement_choices': ActionMiseConformite.AVANCEMENT_CHOICES,
    })


@login_required
def accessibilite_creer_ticket(request, action_pk):
    action = get_object_or_404(ActionMiseConformite, pk=action_pk)
    etab = action.registre.etablissement
    if not action.ticket:
        ticket = TicketTravaux.objects.create(
            etablissement=etab,
            titre=f"[Accessibilité] {action.description[:200]}",
            description=action.description,
            priorite='normal',
            cree_par=request.user,
        )
        action.ticket = ticket
        action.save()
        from django.contrib import messages
        messages.success(request, f'Ticket #{ticket.pk} créé.')
    return redirect('registre:accessibilite_detail', etab_pk=etab.pk)


@login_required
def accessibilite_imprimer(request, etab_pk):
    etab = get_object_or_404(Etablissement, pk=etab_pk)
    registre = _get_or_create_registre(etab)
    evaluations = registre.evaluations.order_by('ordre')
    formations  = registre.formations.order_by('-date_formation')
    pieces      = registre.pieces_administratives.order_by('-date_document')
    actions     = registre.actions.order_by('delai_prevu')

    from django.utils import timezone as tz
    return render(request, 'registre/accessibilite_imprimer.html', {
        'etab': etab,
        'registre': registre,
        'evaluations': evaluations,
        'formations': formations,
        'pieces': pieces,
        'actions': actions,
        'today': tz.now().date(),
    })


# ─────────────────────────────────────────────
#  PROFIL UTILISATEUR — SIGNATURE
# ─────────────────────────────────────────────

@login_required
def mon_profil(request):
    """Page de profil : gestion de la signature."""
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'upload_signature' and request.FILES.get('signature'):
            request.user.signature = request.FILES['signature']
            request.user.save()
            from django.contrib import messages
            messages.success(request, 'Signature enregistrée avec succès.')
        elif action == 'supprimer_signature':
            if request.user.signature:
                request.user.signature.delete(save=True)
            from django.contrib import messages
            messages.success(request, 'Signature supprimée.')
        return redirect('registre:mon_profil')

    return render(request, 'registre/mon_profil.html', {'user': request.user})


# ─────────────────────────────────────────────
#  SIGNATURES DOCUMENTS
# ─────────────────────────────────────────────

import shutil, os
from django.utils import timezone as tz_now

def _copier_signature(user, dest_field):
    """Copie la signature de l'utilisateur vers un nouveau fichier lié au document."""
    if not user.signature:
        return False
    src = user.signature.path
    ext = os.path.splitext(src)[1]
    dest_name = f"{dest_field}/{user.username}_{tz_now.now().strftime('%Y%m%d%H%M%S')}{ext}"
    dest_path = os.path.join('media', dest_name)
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    shutil.copy2(src, dest_path)
    return dest_name


@login_required
def duerp_signer(request, pk):
    """Signe le DUERP avec la signature de l'utilisateur connecté."""
    duerp = get_object_or_404(DUERP, pk=pk)
    user = request.user
    from django.contrib import messages
    from .models import DroitSignature

    if not user.signature:
        messages.error(request, "Vous n'avez pas encore enregistré votre signature dans votre profil.")
        return redirect('registre:duerp_detail', pk=pk)

    # Vérifier le droit de signature via DroitSignature
    if not user.is_superuser and not DroitSignature.peut_signer(user, duerp.etablissement, 'duerp'):
        messages.error(request, "Vous n'avez pas le droit de signer ce document.")
        return redirect('registre:duerp_detail', pk=pk)

    # Déterminer si directeur ou responsable selon droits configurés
    droit_directeur = DroitSignature.objects.filter(
        utilisateur=user, document='duerp'
    ).filter(
        models.Q(etablissement=duerp.etablissement) | models.Q(etablissement__isnull=True)
    ).first()

    # On signe selon le rôle de l'utilisateur
    if user.role in ('directeur',) or (user.role == 'admin' and not duerp.signature_directeur):
        sig_name = _copier_signature(user, 'signatures/duerp')
        duerp.signature_directeur = sig_name
        duerp.nom_directeur = user.get_full_name() or user.username
        duerp.date_signature_directeur = tz_now.now()
        duerp.save()
        messages.success(request, f"DUERP signé par {duerp.nom_directeur}.")
    else:
        sig_name = _copier_signature(user, 'signatures/duerp')
        duerp.signature_responsable = sig_name
        duerp.nom_responsable = user.get_full_name() or user.username
        duerp.date_signature_responsable = tz_now.now()
        duerp.save()
        messages.success(request, f"DUERP signé par {duerp.nom_responsable}.")

    return redirect('registre:duerp_detail', pk=pk)


@login_required
def duerp_supprimer_signature(request, pk):
    """Supprime la signature de l'utilisateur connecté sur le DUERP."""
    duerp = get_object_or_404(DUERP, pk=pk)
    user = request.user
    user = request.user
    from django.contrib import messages

    # Supprimer selon le nom stocké
    if duerp.nom_directeur == (user.get_full_name() or user.username):
        if duerp.signature_directeur:
            duerp.signature_directeur.delete(save=False)
        duerp.signature_directeur = None
        duerp.nom_directeur = ''
        duerp.date_signature_directeur = None
        duerp.save()
        messages.success(request, "Signature retirée.")
    elif duerp.nom_responsable == (user.get_full_name() or user.username):
        if duerp.signature_responsable:
            duerp.signature_responsable.delete(save=False)
        duerp.signature_responsable = None
        duerp.nom_responsable = ''
        duerp.date_signature_responsable = None
        duerp.save()
        messages.success(request, "Signature retirée.")
    else:
        messages.error(request, "Vous ne pouvez pas retirer cette signature.")

    return redirect('registre:duerp_detail', pk=pk)


@login_required
def accessibilite_signer(request, etab_pk):
    """Signe le registre d'accessibilité."""
    etab = get_object_or_404(Etablissement, pk=etab_pk)
    registre = _get_or_create_registre(etab)
    user = request.user
    from django.contrib import messages

    if not user.signature:
        messages.error(request, "Vous n'avez pas encore enregistré votre signature dans votre profil.")
        return redirect('registre:accessibilite_detail', etab_pk=etab_pk)

    if user.role == 'directeur':
        sig_name = _copier_signature(user, 'signatures/accessibilite')
        registre.signature_directeur = sig_name
        registre.nom_directeur = user.get_full_name() or user.username
        registre.date_signature_directeur = tz_now.now()
        registre.save()
        messages.success(request, f"Registre signé par {registre.nom_directeur} (Directeur).")

    elif user.role == 'responsable_securite':
        sig_name = _copier_signature(user, 'signatures/accessibilite')
        registre.signature_responsable = sig_name
        registre.nom_responsable = user.get_full_name() or user.username
        registre.date_signature_responsable = tz_now.now()
        registre.save()
        messages.success(request, f"Registre signé par {registre.nom_responsable} (Responsable sécurité).")

    else:
        messages.error(request, "Seul le Directeur ou le Responsable sécurité peut signer ce document.")

    return redirect('registre:accessibilite_detail', etab_pk=etab_pk)


# ─────────────────────────────────────────────
#  GESTION DES DROITS DE SIGNATURE
# ─────────────────────────────────────────────

from .models import DroitSignature as DroitSig

@login_required
def droits_signature_liste(request):
    """Liste et gestion des droits de signature."""
    from .models import DroitSignature, Utilisateur as Util, Etablissement as Etab
    droits = DroitSignature.objects.select_related('utilisateur', 'etablissement').order_by('utilisateur__last_name', 'etablissement__nom')
    utilisateurs = Util.objects.filter(is_active=True).order_by('last_name')
    etablissements = Etab.objects.filter(actif=True).order_by('nom')

    if request.method == 'POST':
        action = request.POST.get('action')
        from django.contrib import messages

        if action == 'ajouter':
            user_id = request.POST.get('utilisateur')
            etablissements_ids = request.POST.getlist('etablissements')
            documents = request.POST.getlist('documents')

            if not etablissements_ids:
                messages.error(request, 'Cochez au moins un établissement.')
            elif not documents:
                messages.error(request, 'Cochez au moins un document.')
            else:
                count = 0
                for etab_id in etablissements_ids:
                    etab_id_clean = etab_id or None  # "" -> None = tous
                    for doc in documents:
                        _, created = DroitSignature.objects.get_or_create(
                            utilisateur_id=user_id,
                            etablissement_id=etab_id_clean,
                            document=doc,
                        )
                        if created:
                            count += 1
                messages.success(request, f'{count} droit(s) de signature ajouté(s).')

        elif action == 'supprimer':
            droit_id = request.POST.get('droit_id')
            DroitSignature.objects.filter(pk=droit_id).delete()
            messages.success(request, 'Droit de signature supprimé.')

        return redirect('registre:droits_signature_liste')

    return render(request, 'registre/droits_signature.html', {
        'droits': droits,
        'utilisateurs': utilisateurs,
        'etablissements': etablissements,
        'document_choices': DroitSignature.DOCUMENT_CHOICES,
    })
